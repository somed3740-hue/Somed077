import { 
  DriverProfile, 
  LocationPoint, 
  PassengerProfile, 
  PaymentMethod, 
  Ride, 
  RideCategory, 
  RideStatus, 
  UserRole,
  DeliveryOrder,
  WalletTransaction,
  SavedCard,
  SavedLocationItem,
  NotificationPreferences,
  DriverBankInfo,
  DriverTransaction,
  DriverDocumentStatus,
  BusinessProfile,
  BusinessProduct,
  BusinessCategory,
  BusinessDaySchedule,
  BusinessTransaction,
  CourierRequest,
  AppNotification,
  NotificationCategory,
  NotificationAction,
  SystemPermissionStatus,
  SupportTicket
} from '../types/vtc';
import { 
  calculateDistanceKm, 
  calculateFare, 
  estimateDurationMinutes, 
  generateRoutePoints, 
  fetchRealRoadRoute,
  PRESET_LOCATIONS 
} from '../utils/geo';
import { soundEffects } from '../utils/audio';
import { db } from './firebase';
import { collection, doc, setDoc, onSnapshot } from 'firebase/firestore';

const STORAGE_KEY_RIDES = 'vtc_connect_rides_v1';
const STORAGE_KEY_DRIVERS = 'vtc_connect_drivers_v1';
const STORAGE_KEY_SURGE = 'vtc_connect_surge_v1';

// Initial drivers matching screenshots
const INITIAL_DRIVERS: DriverProfile[] = [
  {
    id: 'drv-1',
    name: 'SOMED dine',
    phone: '+3360587241',
    email: 'somed3740@gmail.com',
    rating: 4.00,
    totalRides: 4,
    isOnline: false,
    isBusy: false,
    memberSince: 'sept 2026',
    vehicle: {
      brand: 'Alfa Romeo',
      model: 'teresa',
      plate: 'H45H8887',
      color: 'Gris',
      year: 2019,
      category: 'CONFORT',
    },
    location: { lat: 31.6295, lng: -7.9811 }, // Marrakech
    todayEarnings: 0.00,
    weeklyEarnings: 0.00,
    driverWalletBalance: 5.66,
    acceptanceRate: 98,
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    serviceTypes: ['Sedan', 'Entrega', 'SUV', 'Económico', 'Estándar', 'Premium'],
    driverTransactions: [
      {
        id: 'tx-drv-1',
        type: 'REMITTANCE_SETTLED',
        title: 'Cash remittance settled',
        amount: 8.00,
        date: 'sábado, 19 septiembre 2026',
        time: '17:02:00',
        description: 'Remisión de efectivo recibida - Pedido FD-GCKBWM4M',
        status: 'Completed',
        reference: 'FD-GCKBWM4M',
      },
      {
        id: 'tx-drv-2',
        type: 'REMITTANCE',
        title: 'Cash remittance',
        amount: -8.00,
        date: 'jueves, 17 septiembre 2026',
        time: '17:24:32',
        description: 'Efectivo del producto pendiente de remitir - Pedido FD-GCKBWM4M',
        status: 'Completed',
        reference: 'FD-GCKBWM4M',
      },
      {
        id: 'tx-drv-3',
        type: 'COMMISSION',
        title: 'Cash delivery commission',
        amount: -2.22,
        date: '17 sept 2026',
        time: '17:24',
        description: 'Comisión entrega #FD-GCKBWM4M',
        status: 'Completed',
      },
      {
        id: 'tx-drv-4',
        type: 'COMMISSION',
        title: 'Cash trip commission',
        amount: -0.36,
        date: 'domingo, 13 septiembre 2026',
        time: '14:02:57',
        description: 'Comisión 15% - Viaje TMTZTPOCR',
        status: 'Completed',
        tripCode: 'TMTZTPOCR',
        origin: '18 avenue idrissides, Ménara, Marrakech',
        destination: 'Voiture Super Puissante, Marrakech, Marruecos',
        completedDate: '13/09/2026 14:02',
      },
    ],
    bankInfo: {
      accountHolder: 'SOMED DINE',
      iban: 'FR76 3000 4000 1234 5678 9014 3',
      bic: 'BNPAFRPP',
      bankName: 'BNP Paribas Private Banking',
    },
    documents: {
      vtcCard: 'VALID',
      insurance: 'VALID',
      kbis: 'VALID',
      technicalInspection: 'VALID',
      driverLicense: 'VALID',
    },
    preferredGps: 'waze',
    autoAccept: false,
    searchRadiusKm: 15,
    soundAlertsEnabled: true,
  },
  {
    id: 'drv-2',
    name: 'Alexandre Dupont',
    phone: '+33 6 78 45 12 33',
    email: 'alex.dupont@vtc-connect.fr',
    rating: 4.91,
    totalRides: 870,
    isOnline: true,
    isBusy: false,
    vehicle: {
      model: 'Mercedes Classe E',
      plate: 'GD-411-AZ',
      color: 'Gris Anthracite',
      category: 'BERLINE',
    },
    location: { lat: 48.8550, lng: 2.3450 }, // Near Louvre / Châtelet
    todayEarnings: 215.00,
    weeklyEarnings: 1340.00,
    driverWalletBalance: 142.50,
    driverTransactions: [],
    serviceTypes: ['Sedan', 'Premium', 'Berline'],
    acceptanceRate: 95,
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'drv-3',
    name: 'Sarah Benali',
    phone: '+33 7 89 65 23 14',
    email: 'sarah.b@vtc-connect.fr',
    rating: 4.98,
    totalRides: 630,
    isOnline: true,
    isBusy: false,
    vehicle: {
      model: 'Peugeot 508 Hybrid',
      plate: 'EK-772-QS',
      color: 'Bleu Nuit',
      category: 'STANDARD',
    },
    location: { lat: 48.8750, lng: 2.3380 }, // Near Opéra
    todayEarnings: 98.00,
    weeklyEarnings: 740.00,
    driverWalletBalance: 88.00,
    driverTransactions: [],
    serviceTypes: ['Standard', 'Eco'],
    acceptanceRate: 99,
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'drv-4',
    name: 'Marc Leclerc',
    phone: '+33 6 11 22 33 44',
    email: 'marc.l@vtc-connect.fr',
    rating: 4.88,
    totalRides: 1100,
    isOnline: true,
    isBusy: false,
    vehicle: {
      model: 'Mercedes Classe V',
      plate: 'HB-339-RT',
      color: 'Noir Obsidienne',
      category: 'VAN',
    },
    location: { lat: 48.8470, lng: 2.3700 }, // Near Gare de Lyon
    todayEarnings: 180.00,
    weeklyEarnings: 1120.00,
    driverWalletBalance: 210.00,
    driverTransactions: [],
    serviceTypes: ['Van', 'VIP', 'Groupe'],
    acceptanceRate: 94,
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  },
];

const INITIAL_PASSENGER: PassengerProfile = {
  id: 'usr-1',
  name: 'SOMED dine',
  phone: '+3360587241',
  email: 'contact@somed.biz',
  rating: 4.0,
  tripsCount: 4,
  memberSince: 2026,
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  walletBalance: 0.00,
  defaultPayment: 'CARD',
  savedAddresses: [
    { label: 'Trabajo', address: 'Voiture Super Puissante, Marrakech, Marruecos', lat: 31.6295, lng: -7.9811 },
    { label: 'Domicile', address: PRESET_LOCATIONS[0].address, lat: PRESET_LOCATIONS[0].lat, lng: PRESET_LOCATIONS[0].lng },
    { label: 'Bureau', address: PRESET_LOCATIONS[5].address, lat: PRESET_LOCATIONS[5].lat, lng: PRESET_LOCATIONS[5].lng },
  ],
  savedCards: [
    {
      id: 'card-1',
      brand: 'VISA',
      last4: '4242',
      expMonth: '12',
      expYear: '2034',
      isDefault: true,
      gateway: 'via Stripe',
    },
  ],
  walletTransactions: [],
  savedLocations: [
    {
      id: 'fav-1',
      title: 'Trabajo',
      address: 'Voiture Super Puissante, Marrakech, Marruecos',
      lat: 31.6295,
      lng: -7.9811,
      type: 'FAVORITE',
      iconType: 'work',
    },
    {
      id: 'rec-1',
      title: 'marrakech',
      address: 'marrakech',
      lat: 31.6295,
      lng: -7.9811,
      type: 'RECENT',
      iconType: 'history',
    },
    {
      id: 'rec-2',
      title: 'targa gueliz',
      address: 'targa gueliz',
      lat: 31.6441,
      lng: -8.0315,
      type: 'RECENT',
      iconType: 'history',
    },
    {
      id: 'rec-3',
      title: '18 avenue idrissides',
      address: '18 avenue idrissides, Ménara, Marrakech',
      lat: 31.6225,
      lng: -8.0125,
      type: 'RECENT',
      iconType: 'history',
    },
    {
      id: 'rec-4',
      title: 'Establishment la Maison du Savoir',
      address: 'Establishment la Maison du Savoir, Marrakech, Marruecos',
      lat: 31.6380,
      lng: -8.0050,
      type: 'RECENT',
      iconType: 'history',
    },
    {
      id: 'rec-5',
      title: 'Rue 19',
      address: 'Rue 19, Marrakech, Marruecos',
      lat: 31.6310,
      lng: -8.0180,
      type: 'RECENT',
      iconType: 'history',
    },
    {
      id: 'rec-6',
      title: 'Le Jarret',
      address: 'Le Jarret, Marrakech, Marruecos',
      lat: 31.6190,
      lng: -8.0250,
      type: 'RECENT',
      iconType: 'history',
    },
  ],
  notificationPreferences: {
    tripUpdates: true,
    promotions: true,
    rideRequests: true,
    chatMessages: true,
    walletPayments: true,
  },
  mapEngine: 'leaflet',
  mapsApiKey: 'AIzaSyDemoTestingKeyVtcSomed2026',
  appearance: 'dark',
  language: 'fr',
};

const INITIAL_DELIVERY_ORDERS: DeliveryOrder[] = [
  {
    id: 'del-1',
    storeName: 'belboula',
    itemsCount: 1,
    date: '17/09',
    time: '17:24',
    total: 31.00,
    status: 'Completed',
    category: 'Food',
  },
  {
    id: 'del-2',
    storeName: 'belboula',
    itemsCount: 1,
    date: '17/09',
    time: '17:13',
    total: 31.00,
    status: 'Cancelled',
    category: 'Food',
  },
  {
    id: 'del-3',
    storeName: 'belboula',
    itemsCount: 1,
    date: '17/09',
    time: '17:01',
    total: 37.95,
    status: 'Cancelled',
    category: 'Food',
  },
  {
    id: 'del-4',
    storeName: 'belboula',
    itemsCount: 1,
    date: '17/09',
    time: '17:00',
    total: 29.40,
    status: 'Cancelled',
    category: 'Food',
  },
  {
    id: 'del-5',
    storeName: 'belboula',
    itemsCount: 1,
    date: '17/09',
    time: '16:59',
    total: 29.00,
    status: 'Cancelled',
    category: 'Food',
  },
  {
    id: 'del-6',
    storeName: 'Voiture Super Puissante, Marrakech',
    itemsCount: 1,
    date: '13/09',
    time: '14:02',
    total: 2.39,
    status: 'Completed',
    category: 'Express',
  },
  {
    id: 'del-7',
    storeName: 'Establishment la Maison du Savoir',
    itemsCount: 1,
    date: '13/09',
    time: '13:51',
    total: 5.64,
    status: 'Completed',
    category: 'Express',
  },
  {
    id: 'del-8',
    storeName: 'Le Jarret, Marrakech, Marruecos',
    itemsCount: 1,
    date: '13/09',
    time: '04:02',
    total: 2.29,
    status: 'Cancelled',
    category: 'Express',
  },
  {
    id: 'del-9',
    storeName: 'Dr. Morsi Barakat Jamal, Marrakech',
    itemsCount: 1,
    date: '13/09',
    time: '00:09',
    total: 1.50,
    status: 'Cancelled',
    category: 'Express',
  },
];

const STORAGE_KEY_BUSINESS = 'vtc_connect_business_v1';

const INITIAL_BUSINESS: BusinessProfile = {
  id: 'biz-belboula',
  name: 'belboula',
  email: 'somed3740@gmail.com',
  phone: '+3360587241',
  address: 'P2006 89, Marrakech, Marruecos',
  publicUrl: '/delivery/belboula',
  rating: 3.0,
  ordersCount: 0,
  isOpen: true,
  bannerUrl: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=800&auto=format&fit=crop&q=80',
  avatarUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=150&auto=format&fit=crop&q=80',
  balance: 6.40,
  todaySales: 0.00,
  todayOrders: 0,
  commissions: 0.00,
  withdrawals: 0.00,
  categories: [
    { id: 'cat-fruits', name: 'fruits', description: 'fresh' }
  ],
  products: [
    {
      id: 'prod-coco',
      name: 'coco',
      price: 8.00,
      category: 'fruits',
      imageUrl: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=200&auto=format&fit=crop&q=80',
      description: 'Fruits frais sélectionnés',
      isAvailable: true,
    }
  ],
  schedule: [
    { day: 'Monday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
    { day: 'Tuesday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
    { day: 'Wednesday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
    { day: 'Thursday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
    { day: 'Friday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
    { day: 'Saturday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
    { day: 'Sunday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
  ],
  transactions: [
    {
      id: 'tx-biz-1',
      title: 'Pago de pedido',
      amount: 6.40,
      date: '17/09/2026',
      time: '17:24',
      type: 'ORDER_PAYMENT',
      status: 'Completed',
      reference: 'FD-GCKBWM4M'
    }
  ],
  courierRequests: []
};

const STORAGE_KEY_NOTIFICATIONS = 'somed_notifications_v1';

const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-1',
    title: 'Bienvenue sur SOMED Prestige',
    body: 'Votre service VTC premium, livraison express et solutions pour entreprises en Île-de-France.',
    category: 'SYSTEM',
    timestamp: Date.now() - 1000 * 60 * 15,
    read: false,
    badge: 'Nouveau',
  },
  {
    id: 'notif-2',
    title: 'Code Promo Spécial : PRESTIGE20',
    body: 'Profitez de 20% de remise immédiate sur votre première course en catégorie Berline ou Confort.',
    category: 'SYSTEM',
    timestamp: Date.now() - 1000 * 60 * 60,
    read: false,
    badge: 'Offre',
  },
  {
    id: 'notif-3',
    title: 'Flotte VTC disponible en temps réel',
    body: 'Des chauffeurs Berline, Van et Confort sont prêts à intervenir autour de votre position.',
    category: 'RIDE',
    timestamp: Date.now() - 1000 * 60 * 240,
    read: true,
  }
];

type Listener = () => void;

class VtcStore {
  private currentRole: UserRole = 'PASSENGER';
  private viewMode: 'SINGLE' | 'SPLIT' = 'SINGLE';
  private passenger: PassengerProfile = INITIAL_PASSENGER;
  private currentDriverId: string = 'drv-1';
  private drivers: DriverProfile[] = [];
  private rides: Ride[] = [];
  private businesses: BusinessProfile[] = [INITIAL_BUSINESS];
  private activeBusinessId: string = INITIAL_BUSINESS.id;

  private get business(): BusinessProfile {
    return this.getBusiness();
  }
  private set business(val: BusinessProfile) {
    const idx = this.businesses.findIndex(b => b.id === val.id || b.id === this.activeBusinessId);
    if (idx !== -1) {
      this.businesses[idx] = val;
    } else {
      this.businesses.push(val);
      this.activeBusinessId = val.id;
    }
  }

  private notifications: AppNotification[] = [];
  private activePushNotification: AppNotification | null = null;
  private pushDismissTimeout: NodeJS.Timeout | null = null;
  private surgeMultiplier: number = 1.0;
  private autoSimulateDriver: boolean = true;
  private listeners: Set<Listener> = new Set();
  private simulationTimer: NodeJS.Timeout | null = null;
  private autoDriverInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.loadState();
    this.initFirestoreSync();
    this.startGlobalSimulationLoop();
  }

  private loadState() {
    try {
      const storedDrivers = localStorage.getItem(STORAGE_KEY_DRIVERS);
      if (storedDrivers) {
        this.drivers = JSON.parse(storedDrivers);
      } else {
        this.drivers = INITIAL_DRIVERS;
      }

      const storedRides = localStorage.getItem(STORAGE_KEY_RIDES);
      if (storedRides) {
        this.rides = JSON.parse(storedRides);
      } else {
        // Create an initial completed sample ride
        const dist = 5.2;
        const dur = 18;
        this.rides = [
          {
            id: 'ride-init-1',
            passengerId: this.passenger.id,
            passengerName: this.passenger.name,
            passengerPhone: this.passenger.phone,
            passengerRating: this.passenger.rating,
            driverId: 'drv-2',
            driverName: 'Alexandre Dupont',
            driverPhone: '+33 6 78 45 12 33',
            driverRating: 4.91,
            vehicleModel: 'Mercedes Classe E',
            vehiclePlate: 'GD-411-AZ',
            vehicleColor: 'Gris Anthracite',
            pickup: PRESET_LOCATIONS[0], // Tour Eiffel
            destination: PRESET_LOCATIONS[2], // Louvre
            category: 'CONFORT',
            distanceKm: dist,
            durationMin: dur,
            fare: calculateFare('CONFORT', dist, dur),
            paymentMethod: 'CARD',
            status: 'COMPLETED',
            createdAt: Date.now() - 3600 * 1000 * 3,
            completedAt: Date.now() - 3600 * 1000 * 2.5,
            rating: 5,
            feedback: 'Très professionnel, véhicule impeccable !',
          },
        ];
      }

      const storedSurge = localStorage.getItem(STORAGE_KEY_SURGE);
      if (storedSurge) {
        this.surgeMultiplier = parseFloat(storedSurge) || 1.0;
      }

      const storedPassenger = localStorage.getItem('vtc_passenger');
      if (storedPassenger) {
        try {
          this.passenger = { ...INITIAL_PASSENGER, ...JSON.parse(storedPassenger) };
        } catch {}
      }

      const storedAppearance = localStorage.getItem('vtc_appearance') as 'light' | 'dark' | 'auto' | null;
      if (storedAppearance) {
        this.passenger.appearance = storedAppearance;
      }
      this.applyAppearanceToDom();

      const storedLang = localStorage.getItem('vtc_language') as 'fr' | 'en' | 'es' | null;
      if (storedLang && ['fr', 'en', 'es'].includes(storedLang)) {
        this.passenger.language = storedLang;
      }

      const storedBusiness = localStorage.getItem(STORAGE_KEY_BUSINESS);
      if (storedBusiness) {
        try {
          const parsed = JSON.parse(storedBusiness);
          if (Array.isArray(parsed) && parsed.length > 0) {
            this.businesses = parsed;
          } else if (parsed && typeof parsed === 'object') {
            this.businesses = [{ ...INITIAL_BUSINESS, ...parsed }];
          } else {
            this.businesses = [INITIAL_BUSINESS];
          }
        } catch {
          this.businesses = [INITIAL_BUSINESS];
        }
      } else {
        this.businesses = [INITIAL_BUSINESS];
      }

      const storedActiveBizId = localStorage.getItem('vtc_active_business_id');
      if (storedActiveBizId && this.businesses.some(b => b.id === storedActiveBizId)) {
        this.activeBusinessId = storedActiveBizId;
      } else if (this.businesses.length > 0) {
        this.activeBusinessId = this.businesses[0].id;
      }

      const storedNotifs = localStorage.getItem(STORAGE_KEY_NOTIFICATIONS);
      if (storedNotifs) {
        try {
          this.notifications = JSON.parse(storedNotifs);
        } catch {
          this.notifications = INITIAL_NOTIFICATIONS;
        }
      } else {
        this.notifications = INITIAL_NOTIFICATIONS;
      }
    } catch {
      this.drivers = INITIAL_DRIVERS;
      this.rides = [];
      this.business = INITIAL_BUSINESS;
      this.notifications = INITIAL_NOTIFICATIONS;
    }
  }

  private initFirestoreSync() {
    try {
      const ridesRef = collection(db, 'rides');
      onSnapshot(ridesRef, (snapshot) => {
        let changed = false;
        snapshot.docChanges().forEach((change) => {
          const data = change.doc.data() as Partial<Ride>;
          if (data.id) {
            const existingIdx = this.rides.findIndex((r) => r.id === data.id);
            if (change.type === 'added' && existingIdx === -1) {
              this.rides.push(data as Ride);
              changed = true;
            } else if (change.type === 'modified' && existingIdx !== -1) {
              this.rides[existingIdx] = { ...this.rides[existingIdx], ...data };
              changed = true;
            }
          }
        });
        if (changed) {
          this.listeners.forEach((listener) => listener());
        }
      }, (err) => {
        console.debug('Firestore sync notice:', err.message);
      });
    } catch (err) {
      console.debug('Firestore init notice:', err);
    }
  }

  private saveState() {
    try {
      localStorage.setItem(STORAGE_KEY_DRIVERS, JSON.stringify(this.drivers));
      localStorage.setItem(STORAGE_KEY_RIDES, JSON.stringify(this.rides));
      localStorage.setItem(STORAGE_KEY_SURGE, this.surgeMultiplier.toString());
      localStorage.setItem('vtc_passenger', JSON.stringify(this.passenger));
      localStorage.setItem('vtc_appearance', this.passenger.appearance || 'dark');
      localStorage.setItem('vtc_language', this.passenger.language || 'fr');
      localStorage.setItem(STORAGE_KEY_BUSINESS, JSON.stringify(this.businesses));
      localStorage.setItem('vtc_active_business_id', this.activeBusinessId);
      localStorage.setItem(STORAGE_KEY_NOTIFICATIONS, JSON.stringify(this.notifications));

      // Seamlessly sync active or recent rides to Firestore database
      const recentRides = this.rides.slice(-5);
      recentRides.forEach((r) => {
        if (r && r.id && r.passengerId && r.passengerName) {
          setDoc(doc(db, 'rides', r.id), {
            id: r.id,
            passengerId: r.passengerId,
            passengerName: r.passengerName,
            category: r.category,
            fare: r.fare,
            distanceKm: r.distanceKm,
            durationMin: r.durationMin,
            status: r.status,
            driverId: r.driverId || '',
            driverName: r.driverName || '',
            updatedAt: new Date().toISOString(),
          }, { merge: true }).catch(() => {});
        }
      });
    } catch {
      // Storage error
    }
  }

  public subscribe(listener: Listener) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public notify() {
    this.saveState();
    this.listeners.forEach((listener) => listener());
  }

  public refresh() {
    this.notify();
  }

  // Push Notifications & Permissions Management
  public getNotifications(): AppNotification[] {
    return this.notifications;
  }

  public getUnreadNotificationsCount(): number {
    return this.notifications.filter((n) => !n.read).length;
  }

  public getActivePushNotification(): AppNotification | null {
    return this.activePushNotification;
  }

  public dismissActivePushNotification() {
    if (this.pushDismissTimeout) {
      clearTimeout(this.pushDismissTimeout);
      this.pushDismissTimeout = null;
    }
    this.activePushNotification = null;
    this.listeners.forEach((listener) => listener());
  }

  public sendPushNotification(params: {
    title: string;
    body: string;
    category?: NotificationCategory;
    badge?: string;
    avatar?: string;
    iconName?: string;
    actions?: NotificationAction[];
    data?: Record<string, any>;
    durationMs?: number;
  }): AppNotification {
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      title: params.title,
      body: params.body,
      category: params.category || 'SYSTEM',
      timestamp: Date.now(),
      read: false,
      badge: params.badge,
      avatar: params.avatar,
      iconName: params.iconName,
      actions: params.actions,
      data: params.data,
    };

    // Prepend to notifications history
    this.notifications.unshift(newNotif);
    if (this.notifications.length > 50) {
      this.notifications = this.notifications.slice(0, 50);
    }

    // Set as active sliding-down push banner
    this.activePushNotification = newNotif;

    // Play push notification sound if enabled
    soundEffects.playPushNotificationSound();

    // Trigger browser Web Notification if supported and permitted
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(params.title, {
          body: params.body,
          icon: '/somed-logo.svg',
          badge: '/somed-logo.svg',
        });
      } catch {}
    }

    // Clear any previous dismiss timer
    if (this.pushDismissTimeout) {
      clearTimeout(this.pushDismissTimeout);
    }

    // Auto dismiss active push banner after duration (default 6500ms)
    const duration = params.durationMs ?? 6500;
    if (duration > 0) {
      this.pushDismissTimeout = setTimeout(() => {
        if (this.activePushNotification?.id === newNotif.id) {
          this.activePushNotification = null;
          this.listeners.forEach((listener) => listener());
        }
      }, duration);
    }

    this.notify();
    return newNotif;
  }

  public markNotificationAsRead(id: string) {
    const notif = this.notifications.find((n) => n.id === id);
    if (notif) {
      notif.read = true;
      this.notify();
    }
  }

  public markAllNotificationsAsRead() {
    this.notifications.forEach((n) => (n.read = true));
    this.notify();
  }

  public deleteNotification(id: string) {
    this.notifications = this.notifications.filter((n) => n.id !== id);
    if (this.activePushNotification?.id === id) {
      this.dismissActivePushNotification();
    }
    this.notify();
  }

  public clearAllNotifications() {
    this.notifications = [];
    this.dismissActivePushNotification();
    this.notify();
  }

  // Request browser notification permission
  public async requestPushPermission(): Promise<'granted' | 'denied' | 'default'> {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return 'denied';
    }
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        this.sendPushNotification({
          title: 'Notifications Push activées !',
          body: 'Vous recevrez désormais les alertes de courses et livraisons en temps réel.',
          category: 'SYSTEM',
          badge: 'Succès'
        });
      }
      this.notify();
      return permission;
    } catch {
      return 'denied';
    }
  }

  // Getters
  public getRole(): UserRole {
    return this.currentRole;
  }

  public setRole(role: UserRole) {
    this.currentRole = role;
    this.notify();
  }

  public getViewMode(): 'SINGLE' | 'SPLIT' {
    return this.viewMode;
  }

  public setViewMode(mode: 'SINGLE' | 'SPLIT') {
    this.viewMode = mode;
    this.notify();
  }

  private deliveryOrders: DeliveryOrder[] = INITIAL_DELIVERY_ORDERS;

  public getPassenger(): PassengerProfile {
    return this.passenger;
  }

  public updatePassengerProfile(updates: Partial<PassengerProfile>) {
    this.passenger = { ...this.passenger, ...updates };
    this.notify();
  }

  public topUpWallet(amount: number, description: string = 'Rechargement Carte Bancaire') {
    const newTx: WalletTransaction = {
      id: `tx-${Date.now()}`,
      type: 'TOP_UP',
      amount,
      date: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }),
      description,
      status: 'COMPLETED',
    };
    this.passenger.walletBalance = Math.round((this.passenger.walletBalance + amount) * 100) / 100;
    this.passenger.walletTransactions = [newTx, ...this.passenger.walletTransactions];
    this.sendPushNotification({
      title: 'Portefeuille rechargé avec succès',
      body: `Votre compte a été crédité de ${amount.toFixed(2)} €. Nouveau solde : ${this.passenger.walletBalance.toFixed(2)} €.`,
      category: 'PAYMENT',
      badge: 'Solde',
      actions: [
        { id: 'wallet', label: 'Voir mon solde', actionType: 'VIEW_WALLET', variant: 'primary' }
      ]
    });
    this.notify();
    return newTx;
  }

  public addSavedCard(cardData: Omit<SavedCard, 'id'>) {
    const newCard: SavedCard = {
      ...cardData,
      id: `card-${Date.now()}`,
    };
    if (newCard.isDefault) {
      this.passenger.savedCards.forEach(c => c.isDefault = false);
    }
    this.passenger.savedCards.push(newCard);
    this.notify();
    return newCard;
  }

  public removeSavedCard(cardId: string) {
    this.passenger.savedCards = this.passenger.savedCards.filter(c => c.id !== cardId);
    if (this.passenger.savedCards.length > 0 && !this.passenger.savedCards.some(c => c.isDefault)) {
      this.passenger.savedCards[0].isDefault = true;
    }
    this.notify();
  }

  public setDefaultCard(cardId: string) {
    this.passenger.savedCards.forEach(c => {
      c.isDefault = (c.id === cardId);
    });
    this.notify();
  }

  public addSavedLocation(loc: Omit<SavedLocationItem, 'id'>) {
    const newLoc: SavedLocationItem = {
      ...loc,
      id: `loc-${Date.now()}`,
    };
    this.passenger.savedLocations.unshift(newLoc);
    this.notify();
    return newLoc;
  }

  public removeSavedLocation(locId: string) {
    this.passenger.savedLocations = this.passenger.savedLocations.filter(l => l.id !== locId);
    this.notify();
  }

  public updateNotificationPreferences(prefs: Partial<NotificationPreferences>) {
    this.passenger.notificationPreferences = {
      ...this.passenger.notificationPreferences,
      ...prefs,
    };
    this.notify();
  }

  public applyPromoCode(code: string): { success: boolean; discountPercent: number; message: string } {
    const cleanCode = code.trim().toUpperCase();
    if (cleanCode === 'SOMEDVIP' || cleanCode === 'SOMED2026') {
      soundEffects.playSuccessSound();
      return { success: true, discountPercent: 20, message: 'Code promo activé : -20% sur vos courses !' };
    }
    if (cleanCode === 'WELCOME10') {
      soundEffects.playSuccessSound();
      return { success: true, discountPercent: 10, message: 'Code bienvenue activé : -10% immédiat !' };
    }
    return { success: false, discountPercent: 0, message: 'Code promotionnel invalide ou expiré.' };
  }

  public getDeliveryOrders(): DeliveryOrder[] {
    return this.deliveryOrders;
  }

  public reorderDelivery(orderId: string) {
    const existing = this.deliveryOrders.find(o => o.id === orderId);
    if (existing) {
      const newOrder: DeliveryOrder = {
        ...existing,
        id: `del-${Date.now()}`,
        date: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }),
        time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        status: 'Completed',
      };
      this.deliveryOrders = [newOrder, ...this.deliveryOrders];
      soundEffects.playSuccessSound();
      this.notify();
      return newOrder;
    }
    return null;
  }

  public setMapEngine(engine: 'leaflet' | 'google', apiKey?: string) {
    this.passenger.mapEngine = engine;
    if (apiKey !== undefined) {
      this.passenger.mapsApiKey = apiKey;
    }
    this.notify();
  }

  public isLightMode(): boolean {
    const appearance = this.passenger?.appearance || 'dark';
    if (appearance === 'light') return true;
    if (appearance === 'dark') return false;
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-color-scheme: light)').matches;
    }
    return false;
  }

  public applyAppearanceToDom() {
    if (typeof document !== 'undefined') {
      const isLight = this.isLightMode();
      if (isLight) {
        document.documentElement.classList.add('theme-light', 'light');
        document.documentElement.classList.remove('theme-dark', 'dark');
        document.documentElement.setAttribute('data-theme', 'light');
        if (document.body) {
          document.body.classList.add('theme-light', 'light');
          document.body.classList.remove('theme-dark', 'dark');
        }
      } else {
        document.documentElement.classList.add('theme-dark', 'dark');
        document.documentElement.classList.remove('theme-light', 'light');
        document.documentElement.setAttribute('data-theme', 'dark');
        if (document.body) {
          document.body.classList.add('theme-dark', 'dark');
          document.body.classList.remove('theme-light', 'light');
        }
      }
    }
  }

  public getAppearance(): 'light' | 'dark' | 'auto' {
    return this.passenger.appearance || 'dark';
  }

  public setAppearance(app: 'light' | 'dark' | 'auto') {
    this.passenger.appearance = app;
    try {
      localStorage.setItem('vtc_appearance', app);
    } catch {}
    this.applyAppearanceToDom();
    this.notify();
  }

  public toggleAppearance() {
    const isCurrentlyLight = this.isLightMode();
    this.setAppearance(isCurrentlyLight ? 'dark' : 'light');
  }

  public getLanguage(): 'fr' | 'en' | 'es' {
    const l = this.passenger.language;
    if (l === 'en' || l === 'es') return l;
    return 'fr';
  }

  public setLanguage(lang: 'fr' | 'en' | 'es' | 'ar') {
    this.passenger.language = lang;
    try {
      localStorage.setItem('vtc_language', lang);
    } catch {}
    soundEffects.playNotificationSound();
    this.saveState();
    this.notify();
  }

  public updateDriverProfile(driverId: string, updates: Partial<DriverProfile>) {
    const drv = this.drivers.find(d => d.id === driverId);
    if (drv) {
      Object.assign(drv, updates);
      soundEffects.playSuccessSound();
      this.notify();
    }
  }

  public updateDriverBankInfo(driverId: string, bankInfo: DriverBankInfo) {
    const drv = this.drivers.find(d => d.id === driverId);
    if (drv) {
      drv.bankInfo = bankInfo;
      soundEffects.playSuccessSound();
      this.notify();
    }
  }

  public updateDriverSettings(
    driverId: string, 
    settings: { 
      preferredGps?: 'waze' | 'google' | 'inapp'; 
      autoAccept?: boolean; 
      searchRadiusKm?: number; 
      soundAlertsEnabled?: boolean 
    }
  ) {
    const drv = this.drivers.find(d => d.id === driverId);
    if (drv) {
      Object.assign(drv, settings);
      this.notify();
    }
  }

  public cashoutDriverWallet(driverId: string, amount: number): { success: boolean; message: string } {
    const drv = this.drivers.find(d => d.id === driverId);
    if (!drv) return { success: false, message: 'Chauffeur introuvable' };
    const balance = drv.driverWalletBalance || 0;
    if (amount <= 0 || amount > balance) {
      return { success: false, message: 'Montant invalide ou solde insuffisant' };
    }
    drv.driverWalletBalance = Math.round((balance - amount) * 100) / 100;
    const newTx: DriverTransaction = {
      id: `tx-drv-cashout-${Date.now()}`,
      type: 'REMITTANCE_SETTLED',
      title: 'Virement bancaire instantané',
      amount: -amount,
      date: new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }),
      time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      description: `Virement vers ${drv.bankInfo?.bankName || 'compte bancaire'} (${drv.bankInfo?.iban ? drv.bankInfo.iban.slice(-4) : 'RIB'})`,
      status: 'Completed',
      reference: `VIR-${Date.now().toString().slice(-6)}`,
    };
    drv.driverTransactions = [newTx, ...(drv.driverTransactions || [])];
    soundEffects.playSuccessSound();
    this.notify();
    return { success: true, message: `Virement instantané de ${amount.toFixed(2)} € validé vers votre compte bancaire.` };
  }

  // ==================== BUSINESS METHODS ====================
  public getBusiness(): BusinessProfile {
    const active = this.businesses.find(b => b.id === this.activeBusinessId);
    if (active) return active;
    if (this.businesses.length > 0) {
      this.activeBusinessId = this.businesses[0].id;
      return this.businesses[0];
    }
    return INITIAL_BUSINESS;
  }

  public getAllBusinesses(): BusinessProfile[] {
    return this.businesses;
  }

  public getActiveBusinessId(): string {
    return this.activeBusinessId;
  }

  public setActiveBusiness(id: string) {
    if (this.businesses.some(b => b.id === id)) {
      this.activeBusinessId = id;
      soundEffects.playNotificationSound();
      this.saveState();
      this.notify();
    }
  }

  public hasBusinessLinked(): boolean {
    return this.businesses.length > 0;
  }

  public unlinkAllBusinesses() {
    this.businesses = [];
    this.activeBusinessId = '';
    this.saveState();
    this.notify();
  }

  public restoreSampleBusiness() {
    this.businesses = [INITIAL_BUSINESS];
    this.activeBusinessId = INITIAL_BUSINESS.id;
    this.saveState();
    this.notify();
  }

  public addBusiness(data: Partial<BusinessProfile>): BusinessProfile {
    const id = `biz-${Date.now()}`;
    const name = data.name?.trim() || 'Nouveau Commerce';
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const newBiz: BusinessProfile = {
      id,
      name,
      email: data.email || this.passenger.email || 'contact@somed.biz',
      phone: data.phone || this.passenger.phone || '+33 6 00 00 00 00',
      address: data.address || 'Paris, France',
      publicUrl: `/delivery/${slug}`,
      rating: 5.0,
      ordersCount: 0,
      isOpen: true,
      bannerUrl: data.bannerUrl || 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=800&auto=format&fit=crop&q=80',
      avatarUrl: data.avatarUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=150&auto=format&fit=crop&q=80',
      balance: 0.00,
      todaySales: 0.00,
      todayOrders: 0,
      commissions: 0.00,
      withdrawals: 0.00,
      taxId: data.taxId || '',
      bankName: data.bankName || '',
      bankAccount: data.bankAccount || '',
      accountType: data.accountType || 'Courant / Checking',
      legalRepId: data.legalRepId || '',
      countryCode: data.countryCode || '+33',
      createdAt: Date.now(),
      categories: [
        { id: `cat-${Date.now()}-1`, name: 'Vitrine Principale', description: 'Catalogue de produits' }
      ],
      products: [],
      schedule: [
        { day: 'Monday', isOpen: true, openTime: '09:00', closeTime: '22:00' },
        { day: 'Tuesday', isOpen: true, openTime: '09:00', closeTime: '22:00' },
        { day: 'Wednesday', isOpen: true, openTime: '09:00', closeTime: '22:00' },
        { day: 'Thursday', isOpen: true, openTime: '09:00', closeTime: '22:00' },
        { day: 'Friday', isOpen: true, openTime: '09:00', closeTime: '22:00' },
        { day: 'Saturday', isOpen: true, openTime: '09:00', closeTime: '23:00' },
        { day: 'Sunday', isOpen: true, openTime: '10:00', closeTime: '21:00' },
      ],
      transactions: [],
      courierRequests: [],
      ...data,
    };
    this.businesses.push(newBiz);
    this.activeBusinessId = newBiz.id;
    soundEffects.playSuccessSound();
    this.sendPushNotification({
      title: 'Nouvel établissement créé !',
      body: `${newBiz.name} est maintenant actif. Vous pouvez ajouter autant de produits que vous le souhaitez dans votre vitrine.`,
      category: 'BUSINESS',
      badge: 'Boutique'
    });
    this.saveState();
    this.notify();
    return newBiz;
  }

  public deleteBusiness(id: string) {
    this.businesses = this.businesses.filter(b => b.id !== id);
    if (this.activeBusinessId === id) {
      this.activeBusinessId = this.businesses[0]?.id || '';
    }
    soundEffects.playSuccessSound();
    this.saveState();
    this.notify();
  }

  public updateBusinessProfile(updates: Partial<BusinessProfile>) {
    const biz = this.getBusiness();
    Object.assign(biz, updates);
    soundEffects.playSuccessSound();
    this.saveState();
    this.notify();
  }

  public toggleBusinessOpen() {
    const biz = this.getBusiness();
    biz.isOpen = !biz.isOpen;
    soundEffects.playNotificationSound();
    this.saveState();
    this.notify();
  }

  public addBusinessProduct(product: Omit<BusinessProduct, 'id'>) {
    const newProduct: BusinessProduct = {
      ...product,
      id: `prod-${Date.now()}`,
    };
    this.business.products.push(newProduct);
    soundEffects.playSuccessSound();
    this.notify();
    return newProduct;
  }

  public updateBusinessProduct(productId: string, updates: Partial<BusinessProduct>) {
    const p = this.business.products.find(prod => prod.id === productId);
    if (p) {
      Object.assign(p, updates);
      this.notify();
    }
  }

  public deleteBusinessProduct(productId: string) {
    this.business.products = this.business.products.filter(p => p.id !== productId);
    soundEffects.playSuccessSound();
    this.notify();
  }

  public toggleBusinessProductAvailable(productId: string) {
    const p = this.business.products.find(prod => prod.id === productId);
    if (p) {
      p.isAvailable = !p.isAvailable;
      this.notify();
    }
  }

  public addBusinessCategory(category: Omit<BusinessCategory, 'id'>) {
    const newCat: BusinessCategory = {
      ...category,
      id: `cat-${Date.now()}`,
    };
    this.business.categories.push(newCat);
    soundEffects.playSuccessSound();
    this.notify();
    return newCat;
  }

  public updateBusinessCategory(catId: string, updates: Partial<BusinessCategory>) {
    const c = this.business.categories.find(cat => cat.id === catId);
    if (c) {
      Object.assign(c, updates);
      this.notify();
    }
  }

  public deleteBusinessCategory(catId: string) {
    this.business.categories = this.business.categories.filter(c => c.id !== catId);
    soundEffects.playSuccessSound();
    this.notify();
  }

  public updateBusinessSchedule(schedule: BusinessDaySchedule[]) {
    this.business.schedule = schedule;
    soundEffects.playSuccessSound();
    this.notify();
  }

  public withdrawBusinessBalance(amount: number): { success: boolean; message: string } {
    if (amount <= 0 || amount > this.business.balance) {
      return { success: false, message: 'Montant invalide ou solde insuffisant' };
    }
    this.business.balance = Math.round((this.business.balance - amount) * 100) / 100;
    this.business.withdrawals = Math.round((this.business.withdrawals + amount) * 100) / 100;
    const tx: BusinessTransaction = {
      id: `tx-biz-${Date.now()}`,
      title: 'Retrait bancaire',
      amount: -amount,
      date: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }),
      time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      type: 'WITHDRAWAL',
      status: 'Completed',
      reference: `RET-${Date.now().toString().slice(-6)}`,
    };
    this.business.transactions.unshift(tx);
    soundEffects.playSuccessSound();
    this.notify();
    return { success: true, message: `Retrait de ${amount.toFixed(2)} € validé vers votre compte bancaire.` };
  }

  public topUpBusinessBalance(amount: number, reference?: string): { success: boolean; message: string } {
    if (amount <= 0) return { success: false, message: 'Montant invalide' };
    this.business.balance = Math.round((this.business.balance + amount) * 100) / 100;
    const tx: BusinessTransaction = {
      id: `tx-biz-${Date.now()}`,
      title: 'Rechargement compte',
      amount,
      date: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }),
      time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      type: 'TOP_UP',
      status: 'Completed',
      reference: reference || `DEP-${Date.now().toString().slice(-6)}`,
    };
    this.business.transactions.unshift(tx);
    soundEffects.playSuccessSound();
    this.notify();
    return { success: true, message: `Dépôt de ${amount.toFixed(2)} € ajouté à votre solde.` };
  }

  public requestCourier(req: Omit<CourierRequest, 'id' | 'createdAt' | 'status'>): CourierRequest {
    const newReq: CourierRequest = {
      ...req,
      id: `cour-${Date.now()}`,
      createdAt: Date.now(),
      status: 'PENDING',
      driverId: 'drv-1',
      driverName: 'SOMED dine',
      driverPhone: '+3360587241',
    };
    if (!this.business.courierRequests) {
      this.business.courierRequests = [];
    }
    this.business.courierRequests.unshift(newReq);
    this.business.todayOrders += 1;
    this.business.ordersCount += 1;
    soundEffects.playRideRequestAlert();
    this.notify();

    // Auto-accept by courier after 3 seconds for realistic courier dispatch
    setTimeout(() => {
      newReq.status = 'IN_TRANSIT';
      soundEffects.playSuccessSound();
      this.notify();
    }, 3500);

    return newReq;
  }

  public cancelCourierRequest(reqId: string) {
    const req = (this.business.courierRequests || []).find(r => r.id === reqId);
    if (req) {
      req.status = 'CANCELLED';
      this.notify();
    }
  }

  public getCourierRequests(): CourierRequest[] {
    return this.business.courierRequests || [];
  }

  public orderBusinessProduct(productId: string, notes?: string): { success: boolean; message: string; order?: DeliveryOrder } {
    const product = (this.business.products || []).find(p => p.id === productId);
    if (!product) {
      return { success: false, message: 'Produit introuvable.' };
    }
    if (!product.isAvailable) {
      return { success: false, message: 'Ce produit est actuellement indisponible.' };
    }

    const orderTotal = product.price;

    // 1. Create CourierRequest for business
    const courierReq: CourierRequest = {
      id: `cour-${Date.now()}`,
      createdAt: Date.now(),
      status: 'PENDING',
      customerPhone: this.passenger.phone,
      customerCountryCode: '+33',
      customerName: this.passenger.name,
      customerAddress: this.passenger.savedAddresses[0]?.address || '18 avenue idrissides, Marrakech',
      serviceType: 'DELIVER_AND_COLLECT',
      orderValue: orderTotal,
      prepTimeMin: 20,
      paymentMethod: 'CASH',
      changeRequirement: 'EXACT_AMOUNT',
      notes: notes || `Commande de ${product.name}`,
      driverId: 'drv-1',
      driverName: 'SOMED dine',
      driverPhone: '+3360587241',
    };
    if (!this.business.courierRequests) {
      this.business.courierRequests = [];
    }
    this.business.courierRequests.unshift(courierReq);
    this.business.todayOrders += 1;
    this.business.ordersCount += 1;
    this.business.todaySales += orderTotal;
    this.business.balance = Math.round((this.business.balance + orderTotal) * 100) / 100;

    // Add business transaction
    const bizTx: BusinessTransaction = {
      id: `tx-biz-${Date.now()}`,
      title: `Vente : ${product.name}`,
      amount: orderTotal,
      date: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }),
      time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      type: 'ORDER_PAYMENT',
      status: 'Completed',
      reference: `CMD-${Date.now().toString().slice(-6)}`,
    };
    this.business.transactions.unshift(bizTx);

    // 2. Create passenger delivery order
    const delOrder: DeliveryOrder = {
      id: `del-${Date.now()}`,
      storeName: this.business.name,
      itemsCount: 1,
      date: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }),
      time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      total: orderTotal,
      status: 'Completed',
      category: 'Food',
    };
    this.deliveryOrders = [delOrder, ...this.deliveryOrders];

    this.sendPushNotification({
      title: 'Commande en préparation',
      body: `Votre commande ${product.name} (${orderTotal.toFixed(2)} €) est en préparation chez ${this.business.name}.`,
      category: 'DELIVERY',
      badge: 'Préparation',
      actions: [
        { id: 'track_order', label: 'Suivre la livraison', actionType: 'VIEW_DELIVERY', variant: 'primary' }
      ]
    });
    this.saveState();
    this.notify();

    // Auto-update status to IN_TRANSIT after 4 seconds
    setTimeout(() => {
      courierReq.status = 'IN_TRANSIT';
      this.sendPushNotification({
        title: 'Coursier en approche',
        body: `Le coursier a récupéré votre commande ${product.name} et roule vers votre adresse.`,
        category: 'DELIVERY',
        badge: 'En route'
      });
      this.saveState();
      this.notify();
    }, 4500);

    return { success: true, message: `Commande de ${product.name} confirmée avec succès !`, order: delOrder };
  }

  public resetAllData() {
    try {
      localStorage.removeItem(STORAGE_KEY_DRIVERS);
      localStorage.removeItem(STORAGE_KEY_RIDES);
      localStorage.removeItem(STORAGE_KEY_SURGE);
      localStorage.removeItem('vtc_passenger');
      localStorage.removeItem(STORAGE_KEY_BUSINESS);
    } catch {}
    this.drivers = INITIAL_DRIVERS;
    this.passenger = INITIAL_PASSENGER;
    this.business = INITIAL_BUSINESS;
    this.rides = [];
    this.surgeMultiplier = 1.0;
    this.saveState();
    this.notify();
  }

  public getDriverRides(driverId: string): Ride[] {
    return this.rides.filter(r => r.driverId === driverId).sort((a, b) => b.createdAt - a.createdAt);
  }

  public updateDriverVehicle(driverId: string, updates: Partial<DriverProfile['vehicle']>) {
    const drv = this.drivers.find(d => d.id === driverId);
    if (drv) {
      drv.vehicle = { ...drv.vehicle, ...updates };
      this.notify();
    }
  }

  public topUpDriverWallet(driverId: string, amount: number) {
    const drv = this.drivers.find(d => d.id === driverId);
    if (drv) {
      drv.driverWalletBalance = Math.round(((drv.driverWalletBalance || 0) + amount) * 100) / 100;
      soundEffects.playNotificationSound();
      this.notify();
    }
  }

  public setDriverOnline(driverId: string, online: boolean) {
    const drv = this.drivers.find(d => d.id === driverId);
    if (drv) {
      drv.isOnline = online;
      if (!online) {
        drv.isBusy = false;
      }
      this.notify();
    }
  }

  public getCurrentDriver(): DriverProfile {
    return this.drivers.find((d) => d.id === this.currentDriverId) || this.drivers[0];
  }

  public setCurrentDriverId(id: string) {
    this.currentDriverId = id;
    this.notify();
  }

  public getAllDrivers(): DriverProfile[] {
    return this.drivers;
  }

  public getAllRides(): Ride[] {
    return [...this.rides].sort((a, b) => b.createdAt - a.createdAt);
  }

  public getSurgeMultiplier(): number {
    return this.surgeMultiplier;
  }

  public setSurgeMultiplier(val: number) {
    this.surgeMultiplier = Math.max(1.0, Math.min(3.0, Math.round(val * 10) / 10));
    this.notify();
  }

  public isAutoSimulateDriver(): boolean {
    return this.autoSimulateDriver;
  }

  public setAutoSimulateDriver(val: boolean) {
    this.autoSimulateDriver = val;
    this.notify();
  }

  public getActiveRideForPassenger(): Ride | undefined {
    return this.rides.find(
      (r) =>
        r.passengerId === this.passenger.id &&
        ['REQUESTED', 'ACCEPTED', 'ARRIVING', 'IN_PROGRESS'].includes(r.status)
    );
  }

  public getActiveRideForDriver(driverId: string): Ride | undefined {
    return this.rides.find(
      (r) =>
        r.driverId === driverId &&
        ['ACCEPTED', 'ARRIVING', 'IN_PROGRESS'].includes(r.status)
    );
  }

  public getIncomingRequestsForDriver(driver: DriverProfile): Ride[] {
    if (!driver.isOnline || driver.isBusy) return [];
    return this.rides.filter(
      (r) =>
        r.status === 'REQUESTED' &&
        (!r.driverId || r.driverId === driver.id) &&
        (r.category === driver.vehicle.category || driver.vehicle.category === 'VAN' || r.category === 'STANDARD')
    );
  }

  public getScheduledRides(): Ride[] {
    return this.rides.filter((r) => r.isScheduled && r.status === 'IDLE');
  }

  // Passenger actions
  public requestRide(params: {
    pickup: LocationPoint;
    destination: LocationPoint;
    stops?: LocationPoint[];
    category: RideCategory;
    paymentMethod: PaymentMethod;
    scheduledFor?: number;
  }): Ride {
    const stops = params.stops || [];
    const distanceKm = calculateDistanceKm(
      params.pickup.lat,
      params.pickup.lng,
      params.destination.lat,
      params.destination.lng
    );
    const durationMin = estimateDurationMinutes(distanceKm, stops.length);
    const fare = calculateFare(params.category, distanceKm, durationMin, this.surgeMultiplier, stops.length);
    const isScheduled = !!params.scheduledFor;

    const newRide: Ride = {
      id: `ride-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      passengerId: this.passenger.id,
      passengerName: this.passenger.name,
      passengerPhone: this.passenger.phone,
      passengerRating: this.passenger.rating,
      pickup: params.pickup,
      destination: params.destination,
      stops: stops.length > 0 ? stops : undefined,
      category: params.category,
      distanceKm,
      durationMin,
      fare,
      paymentMethod: params.paymentMethod,
      status: isScheduled ? 'IDLE' : 'REQUESTED',
      createdAt: Date.now(),
      scheduledFor: params.scheduledFor,
      isScheduled,
      invoiceNumber: `VTC-2026-${Math.floor(100000 + Math.random() * 900000)}`,
      verificationCode: Math.floor(1000 + Math.random() * 9000).toString(),
      isCodeVerified: false,
    };

    this.rides.unshift(newRide);

    if (!isScheduled) {
      soundEffects.playRadarPing();
      this.sendPushNotification({
        title: 'Recherche de chauffeur...',
        body: `Votre demande pour ${params.category} (${fare.toFixed(2)} €) est transmise aux chauffeurs proches.`,
        category: 'RIDE',
        badge: 'Recherche'
      });
      if (this.currentRole === 'DRIVER' || this.viewMode === 'SPLIT') {
        soundEffects.playRideRequestAlert();
      }
    }

    this.notify();
    return newRide;
  }

  public activateScheduledRide(rideId: string) {
    const ride = this.rides.find((r) => r.id === rideId);
    if (!ride) return;
    ride.status = 'REQUESTED';
    ride.isScheduled = false;
    soundEffects.playRadarPing();
    this.sendPushNotification({
      title: 'Trajet programmé activé',
      body: `Votre course programmée (${ride.category}) a été lancée et recherche un chauffeur.`,
      category: 'RIDE',
      badge: 'Programmé'
    });
    this.notify();
  }

  public cancelRide(rideId: string) {
    const ride = this.rides.find((r) => r.id === rideId);
    if (!ride) return;

    ride.status = 'CANCELLED';
    if (ride.driverId) {
      const drv = this.drivers.find((d) => d.id === ride.driverId);
      if (drv) drv.isBusy = false;
    }
    this.sendPushNotification({
      title: 'Course annulée',
      body: 'La demande de course a bien été annulée sans frais.',
      category: 'RIDE',
      badge: 'Annulé'
    });
    this.notify();
  }

  public rateRide(rideId: string, rating: number, feedback?: string, tip?: number) {
    const ride = this.rides.find((r) => r.id === rideId);
    if (!ride) return;
    ride.rating = rating;
    ride.feedback = feedback;
    ride.tip = tip || 0;

    if (ride.driverId && tip && tip > 0) {
      const drv = this.drivers.find((d) => d.id === ride.driverId);
      if (drv) {
        drv.todayEarnings += tip;
        drv.weeklyEarnings += tip;
      }
    }
    this.notify();
  }

  // Driver actions
  public toggleDriverOnline(driverId: string) {
    const drv = this.drivers.find((d) => d.id === driverId);
    if (!drv) return;
    drv.isOnline = !drv.isOnline;
    if (!drv.isOnline) {
      drv.isBusy = false;
    }
    this.sendPushNotification({
      title: drv.isOnline ? 'Chauffeur en ligne' : 'Chauffeur hors ligne',
      body: drv.isOnline 
        ? 'Vous êtes prêt à recevoir des demandes de courses autour de vous.' 
        : 'Vous ne recevrez plus de nouvelles demandes de courses.',
      category: 'SYSTEM',
      badge: drv.isOnline ? 'Actif' : 'Pause'
    });
    this.notify();
  }

  public acceptRide(driverId: string, rideId: string) {
    const drv = this.drivers.find((d) => d.id === driverId);
    const ride = this.rides.find((r) => r.id === rideId);
    if (!drv || !ride || ride.status !== 'REQUESTED') return;

    drv.isBusy = true;
    ride.driverId = drv.id;
    ride.driverName = drv.name;
    ride.driverPhone = drv.phone;
    ride.driverRating = drv.rating;
    ride.vehicleModel = drv.vehicle.model;
    ride.vehiclePlate = drv.vehicle.plate;
    ride.vehicleColor = drv.vehicle.color;
    ride.driverLocation = { ...drv.location };
    ride.status = 'ACCEPTED';
    ride.acceptedAt = Date.now();

    // Fast initial route from driver to pickup
    const routeToPickup = generateRoutePoints(
      drv.location.lat,
      drv.location.lng,
      ride.pickup.lat,
      ride.pickup.lng,
      20
    );
    ride.currentRoutePoints = routeToPickup;
    ride.currentRouteIndex = 0;

    // Asynchronously refine with real road routing
    fetchRealRoadRoute(drv.location.lat, drv.location.lng, ride.pickup.lat, ride.pickup.lng)
      .then((realPoints) => {
        if (ride.status === 'ACCEPTED' && realPoints.length > 5) {
          ride.currentRoutePoints = realPoints;
          ride.currentRouteIndex = 0;
          this.notify();
        }
      })
      .catch(() => {});

    soundEffects.playRideAccepted();
    this.sendPushNotification({
      title: 'Chauffeur en route !',
      body: `${drv.name} arrive en ${drv.vehicle.model} (${drv.vehicle.plate}).`,
      category: 'RIDE',
      badge: 'Confirmé',
      actions: [
        { id: 'view_ride', label: 'Suivre la course', actionType: 'VIEW_RIDE', variant: 'primary' }
      ]
    });
    this.notify();
  }

  public driverArrivedAtPickup(rideId: string) {
    const ride = this.rides.find((r) => r.id === rideId);
    if (!ride) return;
    ride.status = 'ARRIVING';
    ride.driverLocation = { lat: ride.pickup.lat, lng: ride.pickup.lng };
    this.sendPushNotification({
      title: 'Votre chauffeur est arrivé !',
      body: `${ride.driverName || 'Votre chauffeur'} vous attend au point de rendez-vous en ${ride.vehicleModel || 'voiture'}.`,
      category: 'RIDE',
      badge: 'Arrivé',
      actions: [
        { id: 'ready', label: 'Je descends', actionType: 'VIEW_RIDE', variant: 'primary' }
      ]
    });
    this.notify();
  }

  public startRideTrip(rideId: string) {
    const ride = this.rides.find((r) => r.id === rideId);
    if (!ride) return;
    ride.status = 'IN_PROGRESS';
    ride.startedAt = Date.now();

    // Fast initial route from pickup to destination
    const routeToDest = generateRoutePoints(
      ride.pickup.lat,
      ride.pickup.lng,
      ride.destination.lat,
      ride.destination.lng,
      35
    );
    ride.currentRoutePoints = routeToDest;
    ride.currentRouteIndex = 0;

    // Asynchronously refine with real road routing
    fetchRealRoadRoute(ride.pickup.lat, ride.pickup.lng, ride.destination.lat, ride.destination.lng)
      .then((realPoints) => {
        if (ride.status === 'IN_PROGRESS' && realPoints.length > 5) {
          ride.currentRoutePoints = realPoints;
          ride.currentRouteIndex = 0;
          this.notify();
        }
      })
      .catch(() => {});

    this.sendPushNotification({
      title: 'Course en cours',
      body: `En route vers ${ride.destination.name || 'votre destination'}. Bon trajet avec SOMED !`,
      category: 'RIDE',
      badge: 'À bord'
    });
    this.notify();
  }

  public completeRide(rideId: string) {
    const ride = this.rides.find((r) => r.id === rideId);
    if (!ride) return;

    ride.status = 'COMPLETED';
    ride.completedAt = Date.now();
    ride.driverLocation = { lat: ride.destination.lat, lng: ride.destination.lng };

    if (ride.driverId) {
      const drv = this.drivers.find((d) => d.id === ride.driverId);
      if (drv) {
        drv.isBusy = false;
        drv.totalRides += 1;
        drv.todayEarnings += Math.round(ride.fare * 0.8 * 100) / 100;
        drv.weeklyEarnings += Math.round(ride.fare * 0.8 * 100) / 100;
        drv.location = { lat: ride.destination.lat, lng: ride.destination.lng };
      }
    }

    soundEffects.playRideCompleted();
    this.sendPushNotification({
      title: 'Course terminée · Paiement validé',
      body: `Merci d'avoir voyagé avec SOMED. Montant : ${ride.fare.toFixed(2)} €. Facture disponible.`,
      category: 'PAYMENT',
      badge: 'Reçu',
      actions: [
        { id: 'receipt', label: 'Voir la facture', actionType: 'VIEW_WALLET', variant: 'primary' }
      ]
    });
    this.notify();
  }

  // Security Ride Code Sharing (Passager -> Chauffeur)
  public shareRideCodeWithDriver(rideId: string): { success: boolean; code?: string } {
    const ride = this.rides.find((r) => r.id === rideId);
    if (!ride) return { success: false };
    if (!ride.verificationCode) {
      ride.verificationCode = Math.floor(1000 + Math.random() * 9000).toString();
    }
    
    ride.isCodeVerified = true;
    this.sendPushNotification({
      title: `Code Course Partagé : ${ride.verificationCode}`,
      body: `Le passager ${ride.passengerName} a transmis le code de validation (${ride.verificationCode}) au chauffeur ${ride.driverName || 'assigné'}.`,
      category: 'RIDE',
      badge: 'Code Validé',
    });
    this.saveState();
    this.notify();
    return { success: true, code: ride.verificationCode };
  }

  public shareVerificationCodeWithDriver(rideId: string): { success: boolean; code?: string } {
    return this.shareRideCodeWithDriver(rideId);
  }

  public verifyRideCode(rideId: string, inputCode?: string): boolean {
    const ride = this.rides.find((r) => r.id === rideId);
    if (!ride) return false;
    const expected = ride.verificationCode || ride.id.slice(-4);
    if (!inputCode || inputCode.trim() === expected || inputCode.trim() === ride.id.slice(-4)) {
      ride.isCodeVerified = true;
      this.sendPushNotification({
        title: 'Code de course vérifié !',
        body: `Prise en charge validée avec le code ${expected}. Bon trajet !`,
        category: 'RIDE',
        badge: 'Sécurisé'
      });
      this.saveState();
      this.notify();
      return true;
    }
    return false;
  }

  // Support 24/7 Tickets
  public submitSupportTicket(ticket: { subject: string; message: string; category?: string }) {
    const newTicket: SupportTicket = {
      id: `tick-${Date.now()}`,
      userId: this.passenger.id,
      userName: this.passenger.name,
      category: ticket.category || 'Général',
      subject: ticket.subject,
      message: ticket.message,
      status: 'OPEN',
      createdAt: Date.now(),
    };
    this.sendPushNotification({
      title: 'Demande d\'assistance enregistrée',
      body: `Votre ticket #${newTicket.id.slice(-6).toUpperCase()} a été transmis aux conseillers SOMED. Assistance sous 10 minutes.`,
      category: 'SYSTEM',
      badge: 'Support 24/7'
    });
    return newTicket;
  }

  // Admin actions
  public assignDriverManually(rideId: string, driverId: string) {
    this.acceptRide(driverId, rideId);
  }

  public toggleDriverStatus(driverId: string) {
    const drv = this.drivers.find((d) => d.id === driverId);
    if (drv) {
      drv.isOnline = !drv.isOnline;
      if (!drv.isOnline) drv.isBusy = false;
      this.notify();
    }
  }


  public seedDemoRide() {
    const p1 = PRESET_LOCATIONS[0];
    const p2 = PRESET_LOCATIONS[1];
    this.requestRide({
      pickup: p1,
      destination: p2,
      category: 'CONFORT',
      paymentMethod: 'CARD',
    });
  }

  // Autonomous real-time simulation engine
  private startGlobalSimulationLoop() {
    if (typeof window === 'undefined') return;

    if (this.simulationTimer) clearInterval(this.simulationTimer);

    this.simulationTimer = setInterval(() => {
      let stateChanged = false;

      // 1. Process active rides navigation & progression
      for (const ride of this.rides) {
        if (ride.status === 'ACCEPTED' && ride.currentRoutePoints && ride.currentRoutePoints.length > 0) {
          // If auto simulation is on OR driver is an AI driver (not the current user's driver when viewing Driver mode)
          const isManagedByAI = this.autoSimulateDriver && (this.currentRole !== 'DRIVER' || ride.driverId !== this.currentDriverId);

          if (isManagedByAI) {
            const nextIdx = (ride.currentRouteIndex || 0) + 1;
            if (nextIdx < ride.currentRoutePoints.length) {
              ride.currentRouteIndex = nextIdx;
              const [lat, lng] = ride.currentRoutePoints[nextIdx];
              ride.driverLocation = { lat, lng };

              // Sync driver location in drivers list
              if (ride.driverId) {
                const drv = this.drivers.find((d) => d.id === ride.driverId);
                if (drv) drv.location = { lat, lng };
              }
              stateChanged = true;
            } else {
              // Reached pickup location!
              this.driverArrivedAtPickup(ride.id);
              stateChanged = true;

              // Automatically start ride after 2.5 seconds
              setTimeout(() => {
                if (ride.status === 'ARRIVING') {
                  this.startRideTrip(ride.id);
                }
              }, 2500);
            }
          }
        } else if (ride.status === 'IN_PROGRESS' && ride.currentRoutePoints && ride.currentRoutePoints.length > 0) {
          const isManagedByAI = this.autoSimulateDriver && (this.currentRole !== 'DRIVER' || ride.driverId !== this.currentDriverId);

          if (isManagedByAI) {
            const nextIdx = (ride.currentRouteIndex || 0) + 1;
            if (nextIdx < ride.currentRoutePoints.length) {
              ride.currentRouteIndex = nextIdx;
              const [lat, lng] = ride.currentRoutePoints[nextIdx];
              ride.driverLocation = { lat, lng };

              if (ride.driverId) {
                const drv = this.drivers.find((d) => d.id === ride.driverId);
                if (drv) drv.location = { lat, lng };
              }
              stateChanged = true;
            } else {
              // Reached destination!
              this.completeRide(ride.id);
              stateChanged = true;
            }
          }
        } else if (ride.status === 'REQUESTED') {
          // If auto simulation is enabled and no driver has accepted yet
          if (this.autoSimulateDriver && this.currentRole !== 'DRIVER') {
            // Find best available driver
            const availableDriver = this.drivers.find((d) => d.isOnline && !d.isBusy);
            if (availableDriver) {
              // Auto accept after a natural 2 second delay
              const delay = 1800;
              setTimeout(() => {
                const currentRide = this.rides.find((r) => r.id === ride.id);
                if (currentRide && currentRide.status === 'REQUESTED') {
                  this.acceptRide(availableDriver.id, currentRide.id);
                }
              }, delay);
            }
          }
        }
      }

      // 2. Subtle organic jitter/movement for idle online drivers so the map feels truly alive
      this.drivers.forEach((drv) => {
        if (drv.isOnline && !drv.isBusy) {
          // Subtle drifting movement ~ 5 meters
          const dLat = (Math.random() - 0.5) * 0.0003;
          const dLng = (Math.random() - 0.5) * 0.0003;
          drv.location = {
            lat: drv.location.lat + dLat,
            lng: drv.location.lng + dLng,
          };
          stateChanged = true;
        }
      });

      if (stateChanged) {
        this.notify();
      }
    }, 1200);
  }
}

export const vtcStore = new VtcStore();
