import React, { useState, useEffect } from 'react';
import { 
  Navigation, 
  Car, 
  ShieldCheck, 
  SplitSquareVertical, 
  Smartphone, 
  Monitor, 
  Sparkles,
  Menu,
  User,
  Wallet,
  Receipt,
  Sun,
  Moon,
  Store,
  Bike,
  Lock,
  KeyRound,
  X,
  Bell,
  Headphones
} from 'lucide-react';
import { vtcStore } from './services/vtcStore';
import { UserRole, Ride } from './types/vtc';
import { PassengerView } from './components/Passenger/PassengerView';
import { DriverView } from './components/Driver/DriverView';
import { AdminView } from './components/Admin/AdminView';
import { BusinessView } from './components/Business/BusinessView';
import { LeftDrawer } from './components/Navigation/LeftDrawer';
import { BottomTabBar } from './components/Navigation/BottomTabBar';
import { ProfileView } from './components/Profile/ProfileView';
import { ActivityView } from './components/Activity/ActivityView';
import { DeliveryView } from './components/Delivery/DeliveryView';
import { WalletModal } from './components/Modals/WalletModal';
import { PaymentMethodsModal } from './components/Modals/PaymentMethodsModal';
import { SavedLocationsModal } from './components/Modals/SavedLocationsModal';
import { ScheduledTripsModal } from './components/Modals/ScheduledTripsModal';
import { PromotionsModal } from './components/Modals/PromotionsModal';
import { ReceiptsModal } from './components/Modals/ReceiptsModal';
import { NotificationsModal } from './components/Modals/NotificationsModal';
import { SettingsModal } from './components/Modals/SettingsModal';
import { EditProfileModal } from './components/Modals/EditProfileModal';
import { ReceiptModal } from './components/Modals/ReceiptModal';
import { RideDetailModal } from './components/Modals/RideDetailModal';
import { PermissionsModal } from './components/Modals/PermissionsModal';
import { RoleSwitcherModal } from './components/Modals/RoleSwitcherModal';
import { SupportModal } from './components/Modals/SupportModal';
import { PushNotificationBanner } from './components/Notifications/PushNotificationBanner';
import { AuthScreen } from './components/Auth/AuthScreen';
import { NoBusinessLinkedView } from './components/Business/NoBusinessLinkedView';
import { NewBusinessModal } from './components/Business/NewBusinessModal';

export default function App() {
  const [, setTick] = useState(0);

  // User Authentication Gate (Requested: Auth screen is first on app launch)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('somed_authenticated_session') === 'true';
    } catch {
      return false;
    }
  });

  const [authMethod, setAuthMethod] = useState<'google' | 'guest'>(() => {
    try {
      return (localStorage.getItem('somed_auth_method') as 'google' | 'guest') || 'guest';
    } catch {
      return 'guest';
    }
  });

  const [guestNeedsBusinessLink, setGuestNeedsBusinessLink] = useState<boolean>(() => {
    try {
      const method = localStorage.getItem('somed_auth_method');
      const hasChosenRole = sessionStorage.getItem('somed_guest_chose_role');
      return method === 'guest' && !hasChosenRole;
    } catch {
      return false;
    }
  });

  const [isGuestNewBusinessModalOpen, setIsGuestNewBusinessModalOpen] = useState(false);

  const handleAuthenticated = (method: 'google' | 'guest' = 'guest') => {
    try {
      sessionStorage.setItem('somed_authenticated_session', 'true');
      localStorage.setItem('somed_authenticated', 'true');
      localStorage.setItem('somed_auth_method', method);
    } catch {}
    setAuthMethod(method);
    setIsAuthenticated(true);

    if (method === 'guest') {
      try {
        sessionStorage.removeItem('somed_guest_chose_role');
      } catch {}
      setGuestNeedsBusinessLink(true);
    } else {
      try {
        sessionStorage.setItem('somed_guest_chose_role', 'true');
      } catch {}
      setGuestNeedsBusinessLink(false);
    }
  };

  const handleLogout = () => {
    try {
      sessionStorage.removeItem('somed_authenticated_session');
      sessionStorage.removeItem('somed_guest_chose_role');
      localStorage.removeItem('somed_authenticated');
    } catch {}
    setIsAuthenticated(false);
    setGuestNeedsBusinessLink(false);
  };

  // Active navigation tab for Passenger mode
  const [currentTab, setCurrentTab] = useState<string>('taxi');
  const [activityInitialTab, setActivityInitialTab] = useState<'ALL' | 'TRIPS' | 'ORDERS' | 'INVOICES' | 'TRANSACTIONS'>('ALL');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Modals state
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isLocationsOpen, setIsLocationsOpen] = useState(false);
  const [isScheduledOpen, setIsScheduledOpen] = useState(false);
  const [isPromotionsOpen, setIsPromotionsOpen] = useState(false);
  const [isReceiptsOpen, setIsReceiptsOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isPermissionsOpen, setIsPermissionsOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [receiptRideModal, setReceiptRideModal] = useState<Ride | null>(null);
  const [isRoleSwitcherOpen, setIsRoleSwitcherOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);

  // Admin authentication state (Only admin sees Dispatch)
  const [isAdminUnlocked, setIsAdminUnlocked] = useState<boolean>(() => {
    try {
      return localStorage.getItem('somed_admin_auth') === 'true';
    } catch {
      return false;
    }
  });
  const [isAdminAuthModalOpen, setIsAdminAuthModalOpen] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [adminAuthError, setAdminAuthError] = useState('');

  const handleAdminLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = adminPasswordInput.trim();
    if (clean === 'admin' || clean === '2026' || clean === 'SOMED2026' || clean === 'somed') {
      setIsAdminUnlocked(true);
      try {
        localStorage.setItem('somed_admin_auth', 'true');
      } catch {}
      setIsAdminAuthModalOpen(false);
      setAdminPasswordInput('');
      setAdminAuthError('');
      vtcStore.setViewMode('SINGLE');
      vtcStore.setRole('ADMIN');
    } else {
      setAdminAuthError('Mot de passe incorrect (Indice : admin ou 2026)');
    }
  };

  const handleAdminLogout = () => {
    setIsAdminUnlocked(false);
    try {
      localStorage.removeItem('somed_admin_auth');
    } catch {}
    vtcStore.setViewMode('SINGLE');
    vtcStore.setRole('PASSENGER');
    setCurrentTab('taxi');
  };

  // Subscribe to store updates
  useEffect(() => {
    const unsubscribe = vtcStore.subscribe(() => {
      setTick((t) => t + 1);
    });
    return unsubscribe;
  }, []);

  const isLight = vtcStore.isLightMode();
  const currentRole = vtcStore.getRole();
  const viewMode = vtcStore.getViewMode();
  const autoSimulate = vtcStore.isAutoSimulateDriver();
  const passenger = vtcStore.getPassenger();
  const driver = vtcStore.getCurrentDriver();

  const handleNavigateFromDrawer = (viewId: string) => {
    switch (viewId) {
      case 'taxi':
        vtcStore.setViewMode('SINGLE');
        vtcStore.setRole('PASSENGER');
        setCurrentTab('taxi');
        break;
      case 'delivery':
        vtcStore.setViewMode('SINGLE');
        vtcStore.setRole('PASSENGER');
        setCurrentTab('delivery');
        break;
      case 'activity':
        setActivityInitialTab('ALL');
        setCurrentTab('activity');
        break;
      case 'receipts':
        setActivityInitialTab('INVOICES');
        setCurrentTab('activity');
        break;
      case 'wallet':
        setIsWalletOpen(true);
        break;
      case 'scheduled':
        setIsScheduledOpen(true);
        break;
      case 'payment':
        setIsPaymentOpen(true);
        break;
      case 'locations':
        setIsLocationsOpen(true);
        break;
      case 'promotions':
        setIsPromotionsOpen(true);
        break;
      case 'profile':
        setCurrentTab('profile');
        break;
      case 'notifications':
        setIsNotificationsOpen(true);
        break;
      case 'settings':
        setIsSettingsOpen(true);
        break;
      case 'help':
        setIsSupportOpen(true);
        break;
      default:
        break;
    }
  };

  const handleSwitchModeCycle = () => {
    setIsRoleSwitcherOpen(true);
  };

  if (!isAuthenticated) {
    return <AuthScreen onAuthenticated={handleAuthenticated} />;
  }

  // View 4: Displayed after authentication if user did NOT choose Google authentication
  if (isAuthenticated && guestNeedsBusinessLink) {
    return (
      <div className="h-screen w-screen overflow-hidden">
        <NoBusinessLinkedView
          onRequestNewBusiness={() => {
            setIsGuestNewBusinessModalOpen(true);
          }}
          onContactSupport={() => {
            setIsSupportOpen(true);
          }}
          onSwitchToRider={() => {
            try { sessionStorage.setItem('somed_guest_chose_role', 'true'); } catch {}
            setGuestNeedsBusinessLink(false);
            vtcStore.setRole('PASSENGER');
            setCurrentTab('taxi');
          }}
          onSwitchToDriver={() => {
            try { sessionStorage.setItem('somed_guest_chose_role', 'true'); } catch {}
            setGuestNeedsBusinessLink(false);
            vtcStore.setRole('DRIVER');
          }}
          onLogout={handleLogout}
        />

        <NewBusinessModal
          isOpen={isGuestNewBusinessModalOpen}
          onClose={() => setIsGuestNewBusinessModalOpen(false)}
          onCreated={(businessId) => {
            try { sessionStorage.setItem('somed_guest_chose_role', 'true'); } catch {}
            setGuestNeedsBusinessLink(false);
            vtcStore.setActiveBusiness(businessId);
            vtcStore.setRole('BUSINESS');
          }}
        />

        <SupportModal
          isOpen={isSupportOpen}
          onClose={() => setIsSupportOpen(false)}
        />
      </div>
    );
  }

  return (
    <div className={`flex flex-col h-screen w-screen overflow-hidden select-none transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900 theme-light' : 'bg-black text-white theme-dark'
    }`}>
      {/* GLOBAL TOP NAVIGATION & ROLE SWITCHER */}
      <nav className={`h-14 border-b px-4 flex items-center justify-between flex-shrink-0 z-30 shadow-md transition-colors ${
        isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-900 text-white'
      }`}>
        {/* Brand & Left Drawer trigger */}
        <div className="flex items-center gap-2.5">
          {currentRole === 'PASSENGER' && viewMode === 'SINGLE' && (
            <button
              onClick={() => setIsDrawerOpen(true)}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition active:scale-95 ${
                isLight 
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' 
                  : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white'
              }`}
              title="Menu principal"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setCurrentTab('taxi')}>
            <img 
              src="/somed-logo.png" 
              alt="SOMED" 
              className="w-9 h-9 aspect-square object-cover rounded-xl shadow-lg shadow-yellow-500/10 ring-1 ring-yellow-400/40" 
            />
            <div className="hidden sm:block">
              <h1 className={`font-black text-sm tracking-tight leading-none flex items-center gap-1.5 ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}>
                <span>SOMED</span>
                <span className="text-[9px] font-bold bg-yellow-400 text-black px-1.5 py-0.2 rounded tracking-wide">
                  VTC PRESTIGE
                </span>
              </h1>
              <p className={`text-[9px] leading-tight mt-0.5 font-medium ${
                isLight ? 'text-slate-500' : 'text-neutral-400'
              }`}>
                Chauffeur Privé & Mobilité
              </p>
            </div>
          </div>
        </div>

        {/* Theme Quick Toggle & Actions (Support, Theme, Notifications) */}
        <div className="flex items-center gap-2">

          {/* Support 24/7 Concierge Button */}
          <button
            onClick={() => setIsSupportOpen(true)}
            className={`p-2 rounded-xl border transition active:scale-95 shadow-sm ${
              isLight 
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300' 
                : 'bg-neutral-900 hover:bg-neutral-800 text-yellow-400 border-neutral-800'
            }`}
            title="Service Support & Conciergerie 24/7"
          >
            <Headphones className="w-4 h-4 text-yellow-500" />
          </button>
          {/* PROMINENT LIGHT/DARK THEME TOGGLE BUTTON */}
          <button
            onClick={() => vtcStore.toggleAppearance()}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border transition active:scale-95 shadow-sm ${
              isLight 
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300' 
                : 'bg-neutral-900 hover:bg-neutral-800 text-yellow-400 border-neutral-800'
            }`}
            title={isLight ? 'Activer le Mode Sombre' : 'Activer le Mode Clair'}
          >
            {isLight ? (
              <>
                <Moon className="w-3.5 h-3.5 text-slate-700" />
                <span className="hidden sm:inline text-slate-700 font-semibold">Mode Sombre</span>
              </>
            ) : (
              <>
                <Sun className="w-3.5 h-3.5 text-yellow-400" />
                <span className="hidden sm:inline text-yellow-400 font-semibold">Mode Clair</span>
              </>
            )}
          </button>

          {/* Notifications Bell with unread count badge */}
          <button
            onClick={() => setIsNotificationsOpen(true)}
            className={`relative p-2 rounded-xl border transition active:scale-95 flex items-center justify-center ${
              isLight 
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300' 
                : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border-neutral-800'
            }`}
            title="Notifications push & alertes en direct"
          >
            <Bell className="w-4 h-4" />
            {vtcStore.getUnreadNotificationsCount() > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-yellow-400 text-black text-[9px] font-black flex items-center justify-center shadow-md animate-pulse">
                {vtcStore.getUnreadNotificationsCount()}
              </span>
            )}
          </button>

          {/* Wallet balance quick pill for passenger, driver or business */}
          {currentRole === 'PASSENGER' && (
            <button
              onClick={() => setIsWalletOpen(true)}
              className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border transition ${
                isLight 
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300' 
                  : 'bg-neutral-900 hover:bg-neutral-800 text-yellow-400 border-neutral-800'
              }`}
            >
              <Wallet className="w-3.5 h-3.5 text-yellow-500" />
              <span>{passenger.walletBalance.toFixed(2)} €</span>
            </button>
          )}

          {currentRole === 'DRIVER' && (
            <div className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border ${
              isLight 
                ? 'bg-slate-100 text-slate-800 border-slate-300' 
                : 'bg-neutral-900 text-yellow-400 border-neutral-800'
            }`}>
              <Wallet className="w-3.5 h-3.5 text-emerald-500" />
              <span>{(driver.driverWalletBalance || 0).toFixed(2)} €</span>
            </div>
          )}

          {currentRole === 'BUSINESS' && (
            <div className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border ${
              isLight 
                ? 'bg-slate-100 text-slate-800 border-slate-300' 
                : 'bg-neutral-900 text-yellow-400 border-neutral-800'
            }`}
            title="Solde du compte entreprise"
            >
              <Store className="w-3.5 h-3.5 text-yellow-400" />
              <span>{(vtcStore.getBusiness().balance || 0).toFixed(2)} €</span>
            </div>
          )}

          {/* Split Mode Button (Only on large screens) */}
          <button
            onClick={() => {
              vtcStore.setViewMode(viewMode === 'SPLIT' ? 'SINGLE' : 'SPLIT');
            }}
            className={`hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition border ${
              viewMode === 'SPLIT'
                ? 'bg-yellow-400/20 border-yellow-400 text-yellow-600 dark:text-yellow-300'
                : isLight 
                ? 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200' 
                : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:text-white'
            }`}
            title="Affiche le Passager et le Chauffeur côte à côte"
          >
            <SplitSquareVertical className="w-3.5 h-3.5" />
            <span>Double Écran</span>
          </button>

          {/* Autonomous Pilot Indicator */}
          <button
            onClick={() => vtcStore.setAutoSimulateDriver(!autoSimulate)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium border transition ${
              autoSimulate
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500'
                : isLight 
                ? 'bg-slate-100 border-slate-300 text-slate-500' 
                : 'bg-neutral-900 border-neutral-800 text-neutral-400'
            }`}
            title="Quand activé, un chauffeur IA accepte vos courses et conduit en temps réel"
          >
            <Sparkles className="w-3 h-3" />
            <span className="hidden sm:inline">IA Chauffeur</span>
            <span className={`w-2 h-2 rounded-full ${autoSimulate ? 'bg-emerald-500 animate-pulse' : 'bg-neutral-400'}`} />
          </button>
        </div>
      </nav>

      {/* MAIN VIEWPORT */}
      <main className="flex-1 w-full overflow-hidden relative flex flex-col">
        {viewMode === 'SPLIT' ? (
          /* Split View: Passenger on Left, Driver on Right */
          <div className={`h-full w-full grid grid-cols-2 divide-x ${
            isLight ? 'divide-slate-200' : 'divide-neutral-900'
          }`}>
            {/* Passenger Half */}
            <div className="h-full w-full relative flex flex-col">
              <div className={`px-4 py-2 border-b flex items-center justify-between text-xs font-bold z-10 ${
                isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-neutral-950 border-neutral-900 text-neutral-300'
              }`}>
                <span className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-yellow-500" />
                  Vue Passager (Commander & Suivre)
                </span>
                <span className={`text-[11px] font-normal ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
                  Marrakech & France
                </span>
              </div>
              <div className="flex-1 overflow-hidden">
                <PassengerView />
              </div>
            </div>

            {/* Driver Half */}
            <div className="h-full w-full relative flex flex-col">
              <div className={`px-4 py-2 border-b flex items-center justify-between text-xs font-bold z-10 ${
                isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-neutral-950 border-neutral-900 text-neutral-300'
              }`}>
                <span className="flex items-center gap-2">
                  <Car className="w-4 h-4 text-emerald-500" />
                  Vue Chauffeur (Cockpit & GPS)
                </span>
                <span className={`text-[11px] font-normal ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
                  Acceptez et conduisez
                </span>
              </div>
              <div className="flex-1 overflow-hidden">
                <DriverView />
              </div>
            </div>
          </div>
        ) : (
          /* Single View: Current selected role */
          <div className="h-full w-full flex-1 overflow-hidden flex flex-col">
            {currentRole === 'PASSENGER' && (
              <div className="flex-1 w-full h-full overflow-hidden flex flex-col">
                {currentTab === 'taxi' && <PassengerView />}
                {currentTab === 'delivery' && (
                  <DeliveryView 
                    onBack={() => setCurrentTab('taxi')} 
                    onNavigateToActivity={() => setCurrentTab('activity')}
                  />
                )}
                {currentTab === 'activity' && (
                  <ActivityView 
                    onBack={() => setCurrentTab('taxi')}
                    onRebook={(addr) => {
                      setCurrentTab('taxi');
                    }}
                    onViewStore={(store) => {
                      setCurrentTab('delivery');
                    }}
                    initialTab={activityInitialTab}
                  />
                )}
                {currentTab === 'profile' && (
                  <ProfileView 
                    onBack={() => setCurrentTab('taxi')}
                    onOpenEditProfile={() => setIsEditProfileOpen(true)}
                    onOpenPaymentMethods={() => setIsPaymentOpen(true)}
                    onOpenWallet={() => setIsWalletOpen(true)}
                    onOpenSavedLocations={() => setIsLocationsOpen(true)}
                    onOpenTripHistory={() => {
                      setActivityInitialTab('TRIPS');
                      setCurrentTab('activity');
                    }}
                    onOpenReceipts={() => {
                      setActivityInitialTab('INVOICES');
                      setCurrentTab('activity');
                    }}
                    onOpenNotifications={() => setIsNotificationsOpen(true)}
                    onOpenSettings={() => setIsSettingsOpen(true)}
                    onSwitchMode={handleSwitchModeCycle}
                  />
                )}
              </div>
            )}

            {currentRole === 'DRIVER' && <DriverView onSwitchMode={handleSwitchModeCycle} />}
            {currentRole === 'ADMIN' && <AdminView />}
            {currentRole === 'BUSINESS' && (
              <BusinessView 
                onSwitchMode={handleSwitchModeCycle} 
                onOpenSupport={() => setIsSupportOpen(true)}
              />
            )}
          </div>
        )}
      </main>

      {/* BOTTOM TAB BAR (Screenshots 2, 7, 8) */}
      {currentRole === 'PASSENGER' && viewMode === 'SINGLE' && (
        <BottomTabBar 
          currentTab={currentTab} 
          onSelectTab={(tab) => setCurrentTab(tab)} 
        />
      )}

      {/* LEFT DRAWER MENU (Screenshot 3) */}
      <LeftDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onNavigate={handleNavigateFromDrawer}
        onSwitchMode={handleSwitchModeCycle}
        onLogout={handleLogout}
      />

      {/* DEDICATED MODALS MATCHING SCREENSHOTS */}
      <WalletModal
        isOpen={isWalletOpen}
        onClose={() => setIsWalletOpen(false)}
      />

      <PaymentMethodsModal
        isOpen={isPaymentOpen}
        onClose={() => setIsPaymentOpen(false)}
      />

      <SavedLocationsModal
        isOpen={isLocationsOpen}
        onClose={() => setIsLocationsOpen(false)}
      />

      <ScheduledTripsModal
        isOpen={isScheduledOpen}
        onClose={() => setIsScheduledOpen(false)}
        onBookNewTrip={() => {
          setCurrentTab('taxi');
        }}
      />

      <PromotionsModal
        isOpen={isPromotionsOpen}
        onClose={() => setIsPromotionsOpen(false)}
      />

      <ReceiptsModal
        isOpen={isReceiptsOpen}
        onClose={() => setIsReceiptsOpen(false)}
        onViewReceipt={(r) => setReceiptRideModal(r)}
      />

      {/* REAL-TIME SLIDING-DOWN PUSH NOTIFICATION BANNER */}
      <PushNotificationBanner
        onActionClick={(action) => {
          if (action.actionType === 'VIEW_RIDE') {
            vtcStore.setViewMode('SINGLE');
            vtcStore.setRole('PASSENGER');
            setCurrentTab('taxi');
          } else if (action.actionType === 'VIEW_DELIVERY') {
            vtcStore.setViewMode('SINGLE');
            vtcStore.setRole('PASSENGER');
            setCurrentTab('delivery');
          } else if (action.actionType === 'VIEW_WALLET') {
            setIsWalletOpen(true);
          } else if (action.actionType === 'VIEW_BUSINESS') {
            vtcStore.setViewMode('SINGLE');
            vtcStore.setRole('BUSINESS');
          }
        }}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
      />

      <PermissionsModal
        isOpen={isPermissionsOpen}
        onClose={() => setIsPermissionsOpen(false)}
        onTriggerTestPush={() => {}}
      />

      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        onOpenPermissions={() => setIsPermissionsOpen(true)}
        onSelectAction={(notif) => {
          if (notif.category === 'RIDE') {
            vtcStore.setViewMode('SINGLE');
            vtcStore.setRole('PASSENGER');
            setCurrentTab('taxi');
            setIsNotificationsOpen(false);
          } else if (notif.category === 'DELIVERY') {
            vtcStore.setViewMode('SINGLE');
            vtcStore.setRole('PASSENGER');
            setCurrentTab('delivery');
            setIsNotificationsOpen(false);
          } else if (notif.category === 'PAYMENT') {
            setIsWalletOpen(true);
            setIsNotificationsOpen(false);
          } else if (notif.category === 'BUSINESS') {
            vtcStore.setViewMode('SINGLE');
            vtcStore.setRole('BUSINESS');
            setIsNotificationsOpen(false);
          }
        }}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onOpenNotifications={() => {
          setIsSettingsOpen(false);
          setIsNotificationsOpen(true);
        }}
      />

      <EditProfileModal
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
      />

      {receiptRideModal && (
        <RideDetailModal
          ride={receiptRideModal}
          isOpen={!!receiptRideModal}
          onClose={() => setReceiptRideModal(null)}
        />
      )}

      {/* ADMIN AUTH MODAL (Dispatch sécurisé réservé à l'Admin) */}
      {isAdminAuthModalOpen && (
        <div className="fixed inset-0 z-[1500] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className={`w-full max-w-sm rounded-3xl p-6 border shadow-2xl space-y-4 ${
            isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800/40">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-amber-500 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">Accès Réservé Dispatch</h3>
                  <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Supervision & Flotte VTC
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  setIsAdminAuthModalOpen(false);
                  setAdminAuthError('');
                  setAdminPasswordInput('');
                }}
                className={`w-7 h-7 rounded-full flex items-center justify-center ${
                  isLight ? 'hover:bg-slate-100 text-slate-500' : 'hover:bg-neutral-900 text-neutral-400'
                }`}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
              L'interface Dispatch est strictement réservée à l'administrateur. Veuillez renseigner votre code d'accès.
            </p>

            <form onSubmit={handleAdminLoginSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-semibold block mb-1">
                  Mot de passe Administrateur
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    autoFocus
                    required
                    placeholder="Entrez le mot de passe admin"
                    value={adminPasswordInput}
                    onChange={(e) => {
                      setAdminPasswordInput(e.target.value);
                      if (adminAuthError) setAdminAuthError('');
                    }}
                    className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:border-amber-400 ${
                      isLight 
                        ? 'bg-slate-50 border-slate-200 text-slate-900' 
                        : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>
                {adminAuthError ? (
                  <p className="text-xs text-rose-500 font-medium mt-1">{adminAuthError}</p>
                ) : (
                  <p className={`text-[10px] mt-1 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                    Code par défaut : <code className="font-bold text-amber-500">admin</code> ou <code className="font-bold text-amber-500">2026</code>
                  </p>
                )}
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAdminAuthModalOpen(false);
                    setAdminAuthError('');
                    setAdminPasswordInput('');
                  }}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition ${
                    isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                  }`}
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs rounded-xl shadow-md transition active:scale-95"
                >
                  Déverrouiller Dispatch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ROLE SWITCHER MODAL (Main role selector screen) */}
      <RoleSwitcherModal
        isOpen={isRoleSwitcherOpen}
        onClose={() => setIsRoleSwitcherOpen(false)}
        onSelectRole={(role) => {
          vtcStore.setViewMode('SINGLE');
          vtcStore.setRole(role);
          if (role === 'PASSENGER') {
            setCurrentTab('taxi');
          }
        }}
        isAdminUnlocked={isAdminUnlocked}
        onOpenAdminAuth={() => setIsAdminAuthModalOpen(true)}
      />

      {/* 24/7 SUPPORT & CONCIERGE MODAL */}
      <SupportModal
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
      />
    </div>
  );
}
