export type UserRole = 'PASSENGER' | 'DRIVER' | 'ADMIN' | 'BUSINESS';

export type RideStatus = 
  | 'IDLE'
  | 'REQUESTED' 
  | 'ACCEPTED' 
  | 'ARRIVING' 
  | 'IN_PROGRESS' 
  | 'COMPLETED' 
  | 'CANCELLED';

export type RideCategory = 'STANDARD' | 'CONFORT' | 'BERLINE' | 'VAN';

export type PaymentMethod = 'CARD' | 'APPLE_PAY' | 'CASH';

export interface LocationPoint {
  lat: number;
  lng: number;
  address: string;
  name?: string;
}

export interface Ride {
  id: string;
  passengerId: string;
  passengerName: string;
  passengerPhone: string;
  passengerRating: number;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  driverRating?: number;
  vehicleModel?: string;
  vehiclePlate?: string;
  vehicleColor?: string;
  pickup: LocationPoint;
  destination: LocationPoint;
  stops?: LocationPoint[]; // Multi-stop support
  category: RideCategory;
  distanceKm: number;
  durationMin: number;
  fare: number;
  paymentMethod: PaymentMethod;
  status: RideStatus;
  createdAt: number;
  scheduledFor?: number; // Scheduled ride timestamp
  isScheduled?: boolean;
  acceptedAt?: number;
  startedAt?: number;
  completedAt?: number;
  rating?: number;
  feedback?: string;
  tip?: number;
  invoiceNumber?: string;
  verificationCode?: string;
  isCodeVerified?: boolean;
  driverLocation?: { lat: number; lng: number };
  currentRoutePoints?: [number, number][];
  currentRouteIndex?: number;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  category: string;
  subject: string;
  message: string;
  status: 'OPEN' | 'RESOLVED';
  createdAt: number;
}

export interface DriverTransaction {
  id: string;
  type: 'COMMISSION' | 'REMITTANCE' | 'REMITTANCE_SETTLED';
  title: string;
  amount: number;
  date: string;
  time: string;
  description: string;
  status: 'Completed' | 'Pending';
  tripCode?: string;
  origin?: string;
  destination?: string;
  completedDate?: string;
  reference?: string;
}

export interface DriverBankInfo {
  accountHolder: string;
  iban: string;
  bic: string;
  bankName: string;
}

export interface DriverDocumentStatus {
  vtcCard: 'VALID' | 'PENDING' | 'EXPIRED';
  insurance: 'VALID' | 'PENDING' | 'EXPIRED';
  kbis: 'VALID' | 'PENDING' | 'EXPIRED';
  technicalInspection: 'VALID' | 'PENDING' | 'EXPIRED';
  driverLicense: 'VALID' | 'PENDING' | 'EXPIRED';
}

export interface DriverProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  rating: number;
  totalRides: number;
  isOnline: boolean;
  isBusy: boolean;
  vehicle: {
    brand?: string;
    model: string;
    plate: string;
    color: string;
    year?: number;
    category: RideCategory;
  };
  vehiclePhotos?: {
    front?: string;
    side?: string;
    back?: string;
  };
  location: { lat: number; lng: number };
  todayEarnings: number;
  weeklyEarnings: number;
  driverWalletBalance: number;
  driverTransactions: DriverTransaction[];
  serviceTypes: string[];
  acceptanceRate: number;
  avatarUrl: string;
  memberSince?: string;
  bankInfo?: DriverBankInfo;
  documents?: DriverDocumentStatus;
  preferredGps?: 'waze' | 'google' | 'inapp';
  autoAccept?: boolean;
  searchRadiusKm?: number;
  soundAlertsEnabled?: boolean;
}

export interface WalletTransaction {
  id: string;
  type: 'TOP_UP' | 'RIDE_PAYMENT' | 'REFUND';
  amount: number;
  date: string;
  description: string;
  status: 'COMPLETED' | 'PENDING' | 'FAILED';
}

export interface SavedCard {
  id: string;
  brand: 'VISA' | 'MASTERCARD' | 'AMEX';
  last4: string;
  expMonth: string;
  expYear: string;
  isDefault: boolean;
  gateway: string;
}

export interface SavedLocationItem {
  id: string;
  title: string;
  address: string;
  lat: number;
  lng: number;
  type: 'FAVORITE' | 'RECENT';
  iconType?: 'work' | 'home' | 'history' | 'pin';
}

export interface NotificationPreferences {
  tripUpdates: boolean;
  promotions: boolean;
  rideRequests: boolean;
  chatMessages: boolean;
  walletPayments: boolean;
}

export interface PromoCode {
  id: string;
  code: string;
  title: string;
  discountPercent: number;
  description: string;
  isActive: boolean;
}

export interface DeliveryOrder {
  id: string;
  storeName: string;
  itemsCount: number;
  date: string;
  time: string;
  total: number;
  status: 'Completed' | 'Cancelled';
  category: 'Food' | 'Package' | 'Express';
}

export interface PassengerProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  rating: number;
  tripsCount: number;
  memberSince: number;
  avatarUrl: string;
  walletBalance: number;
  defaultPayment: PaymentMethod;
  savedAddresses: { label: string; address: string; lat: number; lng: number }[];
  savedCards: SavedCard[];
  walletTransactions: WalletTransaction[];
  savedLocations: SavedLocationItem[];
  notificationPreferences: NotificationPreferences;
  mapEngine: 'leaflet' | 'google';
  mapsApiKey: string;
  appearance: 'light' | 'dark' | 'auto';
  language: 'fr' | 'en' | 'es' | 'ar';
}

export interface CategoryInfo {
  id: RideCategory;
  name: string;
  tagline: string;
  multiplier: number;
  baseFare: number;
  perKm: number;
  perMin: number;
  capacity: number;
  exampleVehicle: string;
  etaMinutes: number;
}

export interface BusinessProduct {
  id: string;
  name: string;
  price: number;
  category: string;
  imageUrl?: string;
  description?: string;
  isAvailable: boolean;
}

export interface BusinessCategory {
  id: string;
  name: string;
  description: string;
  icon?: string;
}

export interface BusinessDaySchedule {
  day: string;
  isOpen: boolean;
  openTime: string;
  closeTime: string;
}

export interface BusinessTransaction {
  id: string;
  title: string;
  amount: number;
  date: string;
  time: string;
  type: 'ORDER_PAYMENT' | 'WITHDRAWAL' | 'TOP_UP' | 'COMMISSION';
  status: 'Completed' | 'Pending';
  reference?: string;
}

export interface CourierRequest {
  id: string;
  customerPhone: string;
  customerCountryCode: string;
  customerName: string;
  customerAddress: string;
  serviceType: 'DELIVER_AND_COLLECT' | 'DELIVER_ONLY';
  orderValue: number;
  prepTimeMin: number;
  paymentMethod: 'CASH' | 'BANK_TRANSFER';
  changeRequirement: 'EXACT_AMOUNT' | 'NEEDS_CHANGE';
  notes?: string;
  status: 'PENDING' | 'ACCEPTED' | 'IN_TRANSIT' | 'DELIVERED' | 'CANCELLED';
  createdAt: number;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
}

export interface BusinessProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  publicUrl: string;
  rating: number;
  ordersCount: number;
  isOpen: boolean;
  bannerUrl: string;
  avatarUrl: string;
  balance: number;
  todaySales: number;
  todayOrders: number;
  commissions: number;
  withdrawals: number;
  categories: BusinessCategory[];
  products: BusinessProduct[];
  schedule: BusinessDaySchedule[];
  transactions: BusinessTransaction[];
  courierRequests: CourierRequest[];
  taxId?: string;
  bankName?: string;
  bankAccount?: string;
  accountType?: string;
  legalRepId?: string;
  countryCode?: string;
  createdAt?: number;
}

export type NotificationCategory = 'RIDE' | 'DELIVERY' | 'BUSINESS' | 'PAYMENT' | 'SYSTEM' | 'SECURITY';

export interface NotificationAction {
  id: string;
  label: string;
  variant?: 'primary' | 'secondary' | 'danger';
  actionType: 'VIEW_RIDE' | 'VIEW_DELIVERY' | 'VIEW_BUSINESS' | 'VIEW_WALLET' | 'VIEW_CHAT' | 'CALL' | 'CUSTOM';
  targetId?: string;
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  category: NotificationCategory;
  timestamp: number;
  read: boolean;
  avatar?: string;
  iconName?: string;
  badge?: string;
  actions?: NotificationAction[];
  data?: Record<string, any>;
}

export interface SystemPermissionStatus {
  pushNotifications: 'granted' | 'denied' | 'prompt' | 'unsupported';
  geolocation: 'granted' | 'denied' | 'prompt' | 'unsupported';
  microphone: 'granted' | 'denied' | 'prompt' | 'unsupported';
  storagePersistence: 'granted' | 'denied' | 'prompt' | 'unsupported';
  soundAlerts: boolean;
  hapticVibration: boolean;
}


