import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Search, 
  Bike, 
  ShoppingBag, 
  Star, 
  Clock, 
  CheckCircle2, 
  Plus,
  Store,
  X,
  Package,
  Check,
  Tag,
  AlertCircle
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';
import { BusinessProduct } from '../../types/vtc';

interface DeliveryViewProps {
  onBack: () => void;
  onNavigateToActivity: () => void;
}

export const DeliveryView: React.FC<DeliveryViewProps> = ({
  onBack,
  onNavigateToActivity,
}) => {
  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const businessProducts = business.products || [];

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | 'PRODUCTS' | 'FOOD' | 'EXPRESS'>('ALL');
  const [orderedModal, setOrderedModal] = useState<{ title: string; subtitle: string } | null>(null);

  const stores = [
    {
      id: 'store-1',
      name: business.name || 'belboula',
      category: 'FOOD',
      rating: business.rating || 4.8,
      prepTime: '15-25 min',
      price: 31.00,
      image: business.bannerUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300&auto=format&fit=crop&q=80',
      description: `${business.address} · Produits frais & livraison coursier express`,
      isLiveBusiness: true,
    },
    {
      id: 'store-2',
      name: 'Le Comptoir Gourmand',
      category: 'FOOD',
      rating: 4.9,
      prepTime: '15-25 min',
      price: 24.50,
      image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=300&auto=format&fit=crop&q=80',
      description: 'Pizzas au feu de bois, burgers artisanaux et salades bio',
      isLiveBusiness: false,
    },
    {
      id: 'store-3',
      name: 'SOMED Express Courier',
      category: 'EXPRESS',
      rating: 4.95,
      prepTime: 'Course immédiate',
      price: 9.90,
      image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=300&auto=format&fit=crop&q=80',
      description: 'Livraison de plis urgents, colis et clés en moins de 35 min',
      isLiveBusiness: false,
    },
  ];

  const filteredProducts = businessProducts.filter(p => {
    if (!p.isAvailable && selectedCategory !== 'PRODUCTS') return false;
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
      (p.description && p.description.toLowerCase().includes(search.toLowerCase()));
    return matchSearch;
  });

  const filteredStores = stores.filter(s => {
    const matchCat = selectedCategory === 'ALL' || s.category === selectedCategory;
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.description.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const handleOrderProduct = (prod: BusinessProduct) => {
    const res = vtcStore.orderBusinessProduct(prod.id);
    if (res.success) {
      setOrderedModal({
        title: prod.name,
        subtitle: `Commandé auprès de ${business.name}. Un coursier SOMED a été assigné pour la livraison.`
      });
    }
  };

  const handleOrderStore = (store: typeof stores[0]) => {
    vtcStore.reorderDelivery(store.id);
    setOrderedModal({
      title: store.name,
      subtitle: `Votre commande a été transmise au restaurant/magasin et un coursier est en route.`
    });
  };

  return (
    <div className={`h-full w-full flex flex-col overflow-hidden select-none transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
    }`}>
      {/* Top Header */}
      <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 sticky top-0 z-20 backdrop-blur-md ${
        isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
      }`}>
        <button
          onClick={onBack}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
            isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
          }`}
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="text-center">
          <h2 className="font-extrabold text-base flex items-center justify-center gap-1.5">
            <span>SOMED Market</span>
            <span className="text-[10px] font-bold bg-yellow-400 text-black px-1.5 py-0.2 rounded">
              BOUTIQUE & LIVRAISON
            </span>
          </h2>
          <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
            Produits d'entreprises partenaires & Colis Express
          </p>
        </div>
        <div className="w-9" />
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-md mx-auto w-full pb-24">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Rechercher un produit, une boutique ou un coursier..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={`w-full rounded-2xl pl-10 pr-4 py-2.5 text-xs font-medium border focus:outline-none focus:border-yellow-400 ${
              isLight 
                ? 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 shadow-sm' 
                : 'bg-neutral-900 border-neutral-800 text-white placeholder-neutral-500'
            }`}
          />
        </div>

        {/* Categories */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {[
            { id: 'ALL', label: 'Tous' },
            { id: 'PRODUCTS', label: '🛍️ Produits en vente' },
            { id: 'FOOD', label: '🍔 Repas & Traiteurs' },
            { id: 'EXPRESS', label: '⚡ Coursier Colis' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                selectedCategory === cat.id
                  ? 'bg-yellow-400 text-black shadow-md'
                  : isLight 
                  ? 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 shadow-sm' 
                  : 'bg-neutral-950 text-neutral-400 border border-neutral-900 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* LIVE BUSINESS PRODUCTS SECTION (Entreprises qui vendent leurs produits) */}
        {(selectedCategory === 'ALL' || selectedCategory === 'PRODUCTS') && businessProducts.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Store className="w-4 h-4 text-yellow-500" />
                <h3 className="font-extrabold text-xs uppercase tracking-wider">
                  Produits en vente directe ({business.name})
                </h3>
              </div>
              <span className={`text-[11px] font-semibold ${business.isOpen ? 'text-emerald-500' : 'text-rose-500'}`}>
                {business.isOpen ? '● Ouvert' : '● Fermé'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className={`p-3 rounded-2xl border flex flex-col justify-between transition shadow-sm ${
                    isLight 
                      ? 'bg-white border-slate-200 hover:border-yellow-400' 
                      : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
                  }`}
                >
                  <div className="w-full h-24 rounded-xl overflow-hidden bg-neutral-900 mb-2 relative">
                    <img
                      src={product.imageUrl || 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=200&auto=format&fit=crop&q=80'}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-1.5 left-1.5 bg-black/75 px-1.5 py-0.5 rounded-md text-[9px] font-bold text-yellow-400">
                      {product.category}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-bold text-xs truncate leading-tight">{product.name}</h4>
                    {product.description && (
                      <p className={`text-[10px] truncate mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                        {product.description}
                      </p>
                    )}
                    <p className="text-yellow-500 font-black text-sm mt-1">
                      {formatEuro(product.price)}
                    </p>
                  </div>

                  <button
                    onClick={() => handleOrderProduct(product)}
                    disabled={!business.isOpen || !product.isAvailable}
                    className={`mt-2.5 w-full py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 ${
                      !business.isOpen || !product.isAvailable
                        ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        : 'bg-yellow-400 hover:bg-yellow-300 text-black shadow-sm'
                    }`}
                  >
                    <Plus className="w-3.5 h-3.5 stroke-[3]" />
                    <span>Acheter & Livrer</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STORES & SERVICES LIST */}
        <div className="space-y-3">
          <h3 className={`text-xs font-extrabold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
            Boutiques partenaires & Services
          </h3>

          {filteredStores.map((store) => (
            <div
              key={store.id}
              className={`rounded-3xl border overflow-hidden transition shadow-sm ${
                isLight 
                  ? 'bg-white border-slate-200 hover:border-slate-300' 
                  : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
              }`}
            >
              <div className="h-32 w-full relative">
                <img
                  src={store.image}
                  alt={store.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-full text-xs font-bold text-yellow-400 flex items-center gap-1 border border-white/10">
                  <Star className="w-3 h-3 fill-yellow-400" />
                  <span>{store.rating}</span>
                </div>
                {store.isLiveBusiness && (
                  <div className="absolute top-3 left-3 bg-yellow-400 text-black font-extrabold text-[10px] px-2 py-0.5 rounded-full">
                    Partenaire vérifié
                  </div>
                )}
              </div>

              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm">{store.name}</h3>
                  <span className="font-black text-sm text-yellow-500">{formatEuro(store.price)}</span>
                </div>

                <p className={`text-xs leading-snug ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {store.description}
                </p>

                <div className="pt-2 flex items-center justify-between">
                  <span className={`text-[11px] flex items-center gap-1 ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
                    <Clock className="w-3.5 h-3.5" />
                    <span>{store.prepTime}</span>
                  </span>

                  <button
                    onClick={() => handleOrderStore(store)}
                    className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-black font-bold text-xs rounded-xl transition active:scale-95 shadow-md flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5 stroke-[3]" />
                    <span>Commander</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Ordered success modal */}
      {orderedModal && (
        <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className={`rounded-3xl w-full max-w-xs p-6 shadow-2xl text-center space-y-4 border ${
            isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
          }`}>
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
            </div>
            <h3 className="font-bold text-base">Commande confirmée !</h3>
            <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
              <strong className="text-yellow-500">{orderedModal.title}</strong>
              <br />
              {orderedModal.subtitle}
            </p>
            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  setOrderedModal(null);
                  onNavigateToActivity();
                }}
                className="w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-bold text-xs rounded-xl shadow-md transition active:scale-95"
              >
                Suivre dans mes activités
              </button>
              <button
                onClick={() => setOrderedModal(null)}
                className={`w-full py-2.5 text-xs transition ${
                  isLight ? 'text-slate-500 hover:text-slate-800' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
