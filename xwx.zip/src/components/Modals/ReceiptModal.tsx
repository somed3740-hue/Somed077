import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Star, CheckCircle2, Heart, Award, FileText, Download } from 'lucide-react';
import { Ride } from '../../types/vtc';
import { formatEuro } from '../../utils/geo';
import { vtcStore } from '../../services/vtcStore';
import { generateInvoicePDF } from '../../utils/invoice';

interface ReceiptModalProps {
  ride: Ride;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ ride, onClose }) => {
  const [rating, setRating] = useState(5);
  const [tip, setTip] = useState<number>(2);
  const [selectedTags, setSelectedTags] = useState<string[]>(['Véhicule très propre', 'Conduite souple']);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    // Launch celebratory confetti
    try {
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#3b82f6', '#f59e0b'],
      });
    } catch {
      // Ignore
    }
  }, []);

  const compliments = [
    'Véhicule très propre',
    'Conduite souple',
    'Chauffeur ponctuel',
    'Excellente musique',
    'Service 5 étoiles',
    'Trajet rapide',
  ];

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = () => {
    const feedbackText = [selectedTags.join(', '), comment].filter(Boolean).join(' - ');
    vtcStore.rateRide(ride.id, rating, feedbackText, tip);
    setSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  const handleDownloadInvoice = () => {
    generateInvoicePDF({ ...ride, tip });
  };

  const totalCharged = ride.fare + tip;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl my-8">
        {!submitted ? (
          <div>
            {/* Header */}
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-3 border border-emerald-500/30">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-white">Course terminée avec succès !</h2>
              <p className="text-xs text-slate-400 mt-1">Merci d'avoir voyagé avec SOMED</p>
            </div>

            {/* Receipt Summary Card */}
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4 mb-4 space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span>Trajet ({ride.distanceKm} km · {ride.durationMin} min)</span>
                <span className="font-semibold text-white">{formatEuro(ride.fare)}</span>
              </div>
              {tip > 0 && (
                <div className="flex justify-between items-center text-amber-400">
                  <span className="flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5" /> Pourboire chauffeur
                  </span>
                  <span className="font-semibold">+{formatEuro(tip)}</span>
                </div>
              )}
              <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-sm font-bold text-white">
                <span>Total débité</span>
                <span className="text-emerald-400 text-base">{formatEuro(totalCharged)}</span>
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1 border-t border-slate-800/60">
                <span>TVA 10% incluse ({formatEuro(totalCharged - totalCharged / 1.1)})</span>
                <button
                  onClick={handleDownloadInvoice}
                  type="button"
                  className="text-blue-400 hover:text-blue-300 flex items-center gap-1 font-semibold"
                >
                  <Download className="w-3 h-3" />
                  <span>Facture PDF</span>
                </button>
              </div>
            </div>

            {/* Driver Profile */}
            <div className="flex items-center gap-3 bg-slate-800/40 p-3 rounded-xl border border-slate-800 mb-5">
              <div className="w-11 h-11 rounded-full bg-slate-700 flex items-center justify-center font-bold text-white text-base">
                {ride.driverName?.charAt(0) || 'C'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white">{ride.driverName || 'Chauffeur VTC'}</p>
                <p className="text-xs text-slate-400 truncate">{ride.vehicleModel} · {ride.vehiclePlate}</p>
              </div>
              <div className="flex items-center gap-1 text-xs text-amber-400 font-medium bg-amber-400/10 px-2 py-1 rounded-md">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                <span>{ride.driverRating?.toFixed(2) || '4.95'}</span>
              </div>
            </div>

            {/* Rating Stars */}
            <div className="text-center mb-5">
              <p className="text-xs font-medium text-slate-300 mb-2">Notez votre chauffeur</p>
              <div className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1 text-slate-600 hover:text-amber-400 transition"
                  >
                    <Star
                      className={`w-7 h-7 transition ${
                        star <= rating
                          ? 'fill-amber-400 text-amber-400 scale-110'
                          : 'text-slate-600'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Driver Tip options */}
            <div className="mb-5">
              <p className="text-xs font-medium text-slate-300 mb-2 flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-amber-400" />
                <span>Ajouter un pourboire (100% reversé au chauffeur)</span>
              </p>
              <div className="grid grid-cols-4 gap-2">
                {[0, 2, 4, 6].map((amount) => (
                  <button
                    key={amount}
                    type="button"
                    onClick={() => setTip(amount)}
                    className={`py-2 text-xs font-semibold rounded-xl border transition ${
                      tip === amount
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {amount === 0 ? 'Aucun' : `+${amount} €`}
                  </button>
                ))}
              </div>
            </div>

            {/* Compliments tags */}
            <div className="mb-5">
              <p className="text-xs font-medium text-slate-300 mb-2">Qu'avez-vous particulièrement apprécié ?</p>
              <div className="flex flex-wrap gap-1.5">
                {compliments.map((comp) => {
                  const isSelected = selectedTags.includes(comp);
                  return (
                    <button
                      key={comp}
                      type="button"
                      onClick={() => toggleTag(comp)}
                      className={`text-[11px] px-2.5 py-1 rounded-lg border transition ${
                        isSelected
                          ? 'bg-blue-600/30 border-blue-500 text-blue-300'
                          : 'bg-slate-800/40 border-slate-700/50 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {comp}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Free comment */}
            <input
              type="text"
              placeholder="Laisser un commentaire (facultatif)..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 mb-5 focus:outline-none focus:border-blue-500"
            />

            {/* Submit button */}
            <button
              onClick={handleSubmit}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold rounded-xl shadow-lg shadow-emerald-600/30 transition active:scale-[0.98]"
            >
              Envoyer l'évaluation
            </button>
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-lg font-bold text-white">Merci pour votre retour !</h3>
            <p className="text-xs text-slate-400 mt-1">Votre avis nous aide à maintenir l'excellence du service.</p>
          </div>
        )}
      </div>
    </div>
  );
};
