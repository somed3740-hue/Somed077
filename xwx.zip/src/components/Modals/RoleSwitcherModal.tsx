import React from 'react';
import { 
  ShoppingCart, 
  Car, 
  Store, 
  ChevronRight, 
  X, 
  ShieldCheck,
  Check
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { UserRole } from '../../types/vtc';

interface RoleSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRole: (role: UserRole) => void;
  isAdminUnlocked: boolean;
  onOpenAdminAuth: () => void;
}

export const RoleSwitcherModal: React.FC<RoleSwitcherModalProps> = ({
  isOpen,
  onClose,
  onSelectRole,
  isAdminUnlocked,
  onOpenAdminAuth,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const currentRole = vtcStore.getRole();

  const handleSelect = (roleId: UserRole) => {
    if (roleId === 'ADMIN' && !isAdminUnlocked) {
      onClose();
      onOpenAdminAuth();
      return;
    }
    onSelectRole(roleId);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[1500] flex items-center justify-center bg-black/95 backdrop-blur-xl animate-in fade-in duration-200 select-none overflow-y-auto p-4 sm:p-6">
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-5 right-5 w-10 h-10 rounded-full bg-neutral-900/80 hover:bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center transition active:scale-95 z-20 border border-neutral-800"
        title="Fermer"
      >
        <X className="w-5 h-5" />
      </button>

      {/* Main Container matching Screenshot_20261001-192146 */}
      <div className="w-full max-w-md my-auto flex flex-col items-center text-center">
        {/* App Logo Squircle */}
        <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl overflow-hidden bg-transparent p-0 flex items-center justify-center shadow-2xl shadow-yellow-400/25 ring-4 ring-yellow-400/30 mb-6 transition-transform hover:scale-105">
          <img 
            src="/somed-logo.png" 
            alt="SOMED" 
            className="w-full h-full object-cover" 
          />
        </div>

        {/* Welcome Titles */}
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white mb-2">
          Welcome to SOMED!
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 font-medium mb-8">
          How would you like to use the app?
        </p>

        {/* Three Main Role Cards */}
        <div className="w-full space-y-3.5">
          {/* 1. I'm a rider */}
          <div
            onClick={() => handleSelect('PASSENGER')}
            className={`w-full p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group active:scale-[0.98] shadow-lg ${
              currentRole === 'PASSENGER'
                ? 'bg-neutral-900 border-yellow-400/80 ring-1 ring-yellow-400/40'
                : 'bg-neutral-900/90 hover:bg-neutral-850 border-neutral-800 hover:border-neutral-700'
            }`}
          >
            <div className="flex items-center gap-4 min-w-0">
              {/* White rounded squircle with Shopping cart icon */}
              <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-md flex-shrink-0 group-hover:scale-105 transition-transform">
                <ShoppingCart className="w-7 h-7 text-cyan-600 stroke-[2.2]" />
              </div>
              <div className="text-left min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-yellow-400 transition-colors truncate">
                    I'm a rider
                  </h3>
                  {currentRole === 'PASSENGER' && (
                    <span className="w-4 h-4 rounded-full bg-yellow-400 text-black flex items-center justify-center flex-shrink-0">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-neutral-400 mt-0.5 leading-snug">
                  I want to request rides and get around the city
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-neutral-600 group-hover:text-neutral-300 group-hover:translate-x-0.5 transition-all flex-shrink-0 ml-2" />
          </div>

          {/* 2. I'm a driver */}
          <div
            onClick={() => handleSelect('DRIVER')}
            className={`w-full p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group active:scale-[0.98] shadow-lg ${
              currentRole === 'DRIVER'
                ? 'bg-neutral-900 border-yellow-400/80 ring-1 ring-yellow-400/40'
                : 'bg-neutral-900/90 hover:bg-neutral-850 border-neutral-800 hover:border-neutral-700'
            }`}
          >
            <div className="flex items-center gap-4 min-w-0">
              {/* Yellow rounded squircle with Car icon */}
              <div className="w-14 h-14 rounded-2xl bg-yellow-400 flex items-center justify-center shadow-md shadow-yellow-500/20 flex-shrink-0 group-hover:scale-105 transition-transform">
                <Car className="w-7 h-7 text-black stroke-[2.2]" />
              </div>
              <div className="text-left min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-yellow-400 transition-colors truncate">
                    I'm a driver
                  </h3>
                  {currentRole === 'DRIVER' && (
                    <span className="w-4 h-4 rounded-full bg-yellow-400 text-black flex items-center justify-center flex-shrink-0">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-neutral-400 mt-0.5 leading-snug">
                  I want to offer rides and earn income
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-neutral-600 group-hover:text-neutral-300 group-hover:translate-x-0.5 transition-all flex-shrink-0 ml-2" />
          </div>

          {/* 3. I am a business */}
          <div
            onClick={() => handleSelect('BUSINESS')}
            className={`w-full p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group active:scale-[0.98] shadow-lg ${
              currentRole === 'BUSINESS'
                ? 'bg-neutral-900 border-yellow-400/80 ring-1 ring-yellow-400/40'
                : 'bg-neutral-900/90 hover:bg-neutral-850 border-neutral-800 hover:border-neutral-700'
            }`}
          >
            <div className="flex items-center gap-4 min-w-0">
              {/* White rounded squircle with Store icon */}
              <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-md flex-shrink-0 group-hover:scale-105 transition-transform">
                <Store className="w-7 h-7 text-emerald-600 stroke-[2.2]" />
              </div>
              <div className="text-left min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-yellow-400 transition-colors truncate">
                    I am a business
                  </h3>
                  {currentRole === 'BUSINESS' && (
                    <span className="w-4 h-4 rounded-full bg-yellow-400 text-black flex items-center justify-center flex-shrink-0">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-neutral-400 mt-0.5 leading-snug">
                  I want to sell products and receive orders
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-neutral-600 group-hover:text-neutral-300 group-hover:translate-x-0.5 transition-all flex-shrink-0 ml-2" />
          </div>
        </div>

        {/* Bottom Note */}
        <p className="text-xs sm:text-sm text-neutral-500 text-center mt-8">
          You can switch between modes at any time from the menu
        </p>

        {/* Discreet Dispatch Admin Access */}
        <button
          onClick={() => {
            if (isAdminUnlocked) {
              handleSelect('ADMIN');
            } else {
              onClose();
              onOpenAdminAuth();
            }
          }}
          className="text-xs text-neutral-600 hover:text-neutral-400 transition-colors mt-4 flex items-center gap-1.5"
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Accès Dispatch Régulation</span>
        </button>
      </div>
    </div>
  );
};
