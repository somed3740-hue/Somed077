import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  ShieldCheck, 
  CheckCircle2, 
  ExternalLink, 
  Info,
  X,
  Zap,
  Sparkles,
  AlertTriangle,
  Layers,
  ArrowRight,
  ShieldAlert,
  HelpCircle
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { soundEffects } from '../../utils/audio';
import { usePWAInstall } from '../../hooks/usePWAInstall';

interface DownloadApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadApkModal: React.FC<DownloadApkModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [activeTab, setActiveTab] = useState<'INSTALL' | 'DOWNLOAD' | 'HELP'>('INSTALL');
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();

  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();

  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [isPreparing, setIsPreparing] = useState(false);

  React.useEffect(() => {
    if (!isOpen) return;
    if (blobUrl) return;

    setIsPreparing(true);
    fetch('/somed-prestige.apk')
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.blob();
      })
      .then((blob) => {
        const url = window.URL.createObjectURL(
          new Blob([blob], { type: 'application/vnd.android.package-archive' })
        );
        setBlobUrl(url);
        setIsPreparing(false);
      })
      .catch((err) => {
        console.warn('Preload blob failed:', err);
        setIsPreparing(false);
      });
  }, [isOpen, blobUrl]);

  const handleDownload = async () => {
    soundEffects.playClick();
    setDownloadStarted(true);
    setDownloadProgress(20);
    setDownloadError(null);

    try {
      // 1. Fetch file via authenticated app session to avoid Cloud Run auth redirect
      const response = await fetch('/somed-prestige.apk');
      if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
      }
      setDownloadProgress(60);
      const blob = await response.blob();
      setDownloadProgress(85);

      // 2. Generate local blob URL and trigger download
      const localBlobUrl = window.URL.createObjectURL(
        new Blob([blob], { type: 'application/vnd.android.package-archive' })
      );
      const link = document.createElement('a');
      link.href = localBlobUrl;
      link.download = 'somed-prestige.apk';
      document.body.appendChild(link);
      link.click();

      setTimeout(() => {
        window.URL.revokeObjectURL(localBlobUrl);
        document.body.removeChild(link);
      }, 2000);

      setDownloadProgress(100);
      soundEffects.playPushNotificationSound();
      vtcStore.sendPushNotification({
        title: 'Téléchargement réussi',
        body: 'Le package somed-prestige.apk (11.6 Mo) est enregistré dans votre dossier Téléchargements.',
        category: 'SYSTEM',
        badge: 'APK Android'
      });
    } catch (err: any) {
      console.warn('Fallback direct download:', err);
      // Fallback directly to anchor click
      const fallbackLink = document.createElement('a');
      fallbackLink.href = '/somed-prestige.apk';
      fallbackLink.download = 'somed-prestige.apk';
      document.body.appendChild(fallbackLink);
      fallbackLink.click();
      document.body.removeChild(fallbackLink);
    } finally {
      setTimeout(() => {
        setDownloadStarted(false);
        setDownloadProgress(null);
      }, 3000);
    }
  };

  const handleDirectInstall = async () => {
    soundEffects.playClick();
    if (isInstallable) {
      const success = await install();
      if (success) {
        soundEffects.playRideAccepted();
        vtcStore.sendPushNotification({
          title: 'Installation réussie',
          body: 'SOMED Prestige a été installé avec succès sur votre écran d\'accueil.',
          category: 'SYSTEM',
          badge: 'Natif'
        });
      }
    } else {
      // Guide the user directly
      setActiveTab('HELP');
    }
  };

  return (
    <div className="fixed inset-0 z-[1400] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className={`w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden transition-colors max-h-[92vh] flex flex-col ${
        isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
      }`}>
        {/* Header with App Logo */}
        <div className={`p-4 sm:p-5 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-neutral-900/70'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-transparent overflow-hidden p-0 flex items-center justify-center shadow-lg shadow-yellow-500/10 ring-2 ring-yellow-400/30 flex-shrink-0">
              <img 
                src="/somed-logo.png" 
                alt="SOMED" 
                className="w-full h-full object-cover" 
              />
            </div>
            <div>
              <h3 className="font-black text-sm sm:text-base flex items-center gap-1.5 flex-wrap">
                <span>Application Android SOMED</span>
                <span className="text-[9px] font-black bg-emerald-500 text-black px-1.5 py-0.2 rounded uppercase">
                  v2.4.0 Corrigée
                </span>
              </h3>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Package certifié · Compatible Android 8 à 15+
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition flex-shrink-0 ${
              isLight ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className={`px-4 pt-3 flex gap-2 border-b flex-shrink-0 ${
          isLight ? 'bg-slate-100/70 border-slate-200' : 'bg-neutral-900/40 border-neutral-900'
        }`}>
          <button
            onClick={() => setActiveTab('INSTALL')}
            className={`flex-1 pb-2.5 text-xs font-bold transition flex items-center justify-center gap-1.5 border-b-2 ${
              activeTab === 'INSTALL'
                ? 'border-yellow-400 text-yellow-500'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Installation Directe (Recommandé)</span>
          </button>

          <button
            onClick={() => setActiveTab('DOWNLOAD')}
            className={`flex-1 pb-2.5 text-xs font-bold transition flex items-center justify-center gap-1.5 border-b-2 ${
              activeTab === 'DOWNLOAD'
                ? 'border-yellow-400 text-yellow-500'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Fichier APK (5.8 Mo)</span>
          </button>

          <button
            onClick={() => setActiveTab('HELP')}
            className={`px-3 pb-2.5 text-xs font-bold transition flex items-center justify-center gap-1.5 border-b-2 ${
              activeTab === 'HELP'
                ? 'border-yellow-400 text-yellow-500'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Aide & Erreurs</span>
          </button>
        </div>

        {/* Scrollable Body Content */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">

          {/* TAB 1: INSTALL DIRECT (WebAPK / PWA) */}
          {activeTab === 'INSTALL' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Highlight Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-yellow-400/15 via-amber-400/10 to-transparent border border-yellow-400/30 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-yellow-400 text-black uppercase">
                    100% Sans Erreur
                  </span>
                  <span className="text-xs font-bold text-yellow-500">
                    Technologie Officielle Google Android (WebAPK)
                  </span>
                </div>
                <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
                  L'installation directe génère et installe un <strong>APK officiel</strong> directement sur votre smartphone via Google Chrome. Cela évite 100% des erreurs d'analyse de fichier et ne nécessite aucune manipulation complexe.
                </p>
              </div>

              {/* Action Button */}
              {isInstalled ? (
                <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0" />
                  <div>
                    <h4 className="text-xs font-bold text-emerald-400">Application déjà installée !</h4>
                    <p className={`text-[11px] ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
                      SOMED Prestige est déjà présent sur votre écran d'accueil et dans votre lanceur d'applications.
                    </p>
                  </div>
                </div>
              ) : isInstallable ? (
                <button
                  onClick={handleDirectInstall}
                  className="w-full py-4 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-sm flex items-center justify-center gap-2.5 shadow-xl shadow-yellow-500/20 transition active:scale-95 group"
                >
                  <Smartphone className="w-5 h-5 text-black stroke-[2.5]" />
                  <span>Installer l'application sur mon smartphone</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              ) : (
                <div className="space-y-3">
                  <button
                    onClick={handleDirectInstall}
                    className="w-full py-3.5 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition active:scale-95"
                  >
                    <Smartphone className="w-4 h-4 stroke-[2.5]" />
                    <span>Installer sur l'écran d'accueil</span>
                  </button>

                  <div className={`p-3.5 rounded-2xl border text-xs space-y-2 ${
                    isLight ? 'bg-slate-50 border-slate-200 text-slate-700' : 'bg-neutral-900/60 border-neutral-800 text-neutral-300'
                  }`}>
                    <p className="font-bold flex items-center gap-1.5 text-yellow-500">
                      <Info className="w-4 h-4" />
                      <span>Comment installer en 3 secondes depuis Chrome Mobile :</span>
                    </p>
                    <ol className="list-decimal pl-5 space-y-1.5 text-xs">
                      <li>
                        Appuyez sur le menu de Chrome en haut à droite (les <strong>trois points verticaux ⋮</strong>).
                      </li>
                      <li>
                        Sélectionnez <strong>"Ajouter à l'écran d'accueil"</strong> ou <strong>"Installer l'application"</strong>.
                      </li>
                      <li>
                        Confirmez avec <strong>"Installer"</strong> : l'icône dorée SOMED Prestige apparaît instantanément sur votre téléphone !
                      </li>
                    </ol>
                  </div>
                </div>
              )}

              {/* Native Features Included */}
              <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
                <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/40 border-neutral-800/80'
                }`}>
                  <Zap className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                  <span className="font-medium text-[11px]">Plein écran immersif</span>
                </div>
                <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/40 border-neutral-800/80'
                }`}>
                  <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span className="font-medium text-[11px]">Géolocalisation GPS</span>
                </div>
                <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/40 border-neutral-800/80'
                }`}>
                  <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span className="font-medium text-[11px]">Alertes & Push radar</span>
                </div>
                <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/40 border-neutral-800/80'
                }`}>
                  <Layers className="w-4 h-4 text-blue-400 flex-shrink-0" />
                  <span className="font-medium text-[11px]">Mode hors-ligne actif</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DOWNLOAD FILE */}
          {activeTab === 'DOWNLOAD' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Specs Card */}
              <div className={`p-4 rounded-2xl border space-y-2.5 text-xs ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/80 border-neutral-800'
              }`}>
                <div className="flex items-center justify-between">
                  <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Fichier :</span>
                  <span className="font-mono font-bold text-yellow-500">somed-prestige.apk</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Taille du package :</span>
                  <span className="font-semibold text-emerald-400">5.8 Mo (Complet & Non corrompu)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Package ID :</span>
                  <span className="font-mono text-[11px]">com.somed.prestige</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Statut :</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Prêt au téléchargement direct</span>
                  </span>
                </div>
              </div>

              {/* Download Button */}
              {/* Download Buttons */}
              <div className="space-y-2.5">
                <a
                  href={blobUrl || '/somed-prestige.apk'}
                  download="somed-prestige.apk"
                  onClick={() => {
                    soundEffects.playPushNotificationSound();
                    setDownloadStarted(true);
                    vtcStore.sendPushNotification({
                      title: 'Téléchargement somed-prestige.apk',
                      body: 'Le package complet (5.8 Mo) de SOMED Prestige est en cours d\'enregistrement.',
                      category: 'SYSTEM',
                      badge: 'APK v2.4'
                    });
                    setTimeout(() => setDownloadStarted(false), 3500);
                  }}
                  className="w-full py-4 px-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2.5 shadow-xl transition active:scale-95 bg-yellow-400 hover:bg-yellow-300 text-black shadow-yellow-500/20 text-center cursor-pointer"
                >
                  {downloadStarted ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-black stroke-[2.5]" />
                      <span>Téléchargement en cours (5.8 Mo)...</span>
                    </>
                  ) : isPreparing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                      <span>Préparation du fichier (5.8 Mo)...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5 text-black stroke-[2.5]" />
                      <span>Télécharger somed-prestige.apk (5.8 Mo)</span>
                    </>
                  )}
                </a>

                <button
                  onClick={handleDownload}
                  className={`w-full py-3 px-4 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition ${
                    isLight 
                      ? 'border-slate-300 hover:bg-slate-100 text-slate-800' 
                      : 'border-neutral-800 hover:bg-neutral-900 text-neutral-300'
                  }`}
                >
                  <Zap className="w-4 h-4 text-yellow-500" />
                  <span>{downloadStarted ? 'Génération du flux en cours...' : 'Téléchargement direct alternatif (Blob)'}</span>
                </button>

                <div className="flex items-center justify-between px-1 text-[11px]">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Lien direct certifié</span>
                  </span>
                  <button 
                    onClick={() => setActiveTab('HELP')}
                    className="text-neutral-400 hover:text-white underline"
                  >
                    Résoudre les erreurs d'exécution ?
                  </button>
                </div>
              </div>

              {/* Fast steps */}
              <div className={`p-3.5 rounded-2xl border text-xs space-y-2 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/40 border-neutral-800'
              }`}>
                <h5 className="font-bold text-yellow-500 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Étapes après le téléchargement :</span>
                </h5>
                <ol className="list-decimal pl-5 space-y-1 text-[11px] leading-relaxed">
                  <li>Ouvrez votre gestionnaire de fichiers ou la barre de notifications Android.</li>
                  <li>Cliquez sur <strong>somed-prestige.apk</strong>.</li>
                  <li>Si Android demande l'autorisation : activez <em>"Autoriser cette source"</em> puis confirmez <strong>Installer</strong>.</li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 3: HELP & TROUBLESHOOTING */}
          {activeTab === 'HELP' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <h4 className="font-bold text-amber-400">Pourquoi Android a affiché une erreur ?</h4>
                  <p className={`leading-relaxed ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
                    L'ancien fichier temporaire était incomplet (693 octets). Le nouveau package pèse <strong>5.8 Mo réels</strong> avec tous les modules compilés.
                  </p>
                </div>
              </div>

              {/* Issue 1 */}
              <div className={`p-3.5 rounded-2xl border text-xs space-y-1.5 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
              }`}>
                <h5 className="font-bold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>1. La solution la plus simple : Installation PWA Directe</span>
                </h5>
                <p className={`text-[11px] leading-relaxed ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
                  Allez dans l'onglet <strong>"Installation Directe"</strong> ci-dessus ou ouvrez le menu Chrome (les 3 points ⋮) et cliquez sur <strong>"Ajouter à l'écran d'accueil"</strong>. Android installe l'application sans aucune alerte de sécurité.
                </p>
              </div>

              {/* Issue 2 */}
              <div className={`p-3.5 rounded-2xl border text-xs space-y-1.5 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
              }`}>
                <h5 className="font-bold text-yellow-500 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4" />
                  <span>2. "Source inconnue bloquée" par Android</span>
                </h5>
                <p className={`text-[11px] leading-relaxed ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
                  Par défaut, Android bloque l'installation des fichiers .apk téléchargés hors du Play Store :
                </p>
                <div className={`p-2 rounded-lg font-mono text-[10px] ${
                  isLight ? 'bg-slate-200 text-slate-800' : 'bg-black/60 text-neutral-300'
                }`}>
                  Paramètres Android &gt; Applications &gt; Chrome (ou Fichiers) &gt; Installer applis inconnues &gt; Activer "Autoriser"
                </div>
              </div>

              {/* Issue 3 */}
              <div className={`p-3.5 rounded-2xl border text-xs space-y-1.5 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
              }`}>
                <h5 className="font-bold text-yellow-500 flex items-center gap-1.5">
                  <Info className="w-4 h-4" />
                  <span>3. Avertissement "Google Play Protect"</span>
                </h5>
                <p className={`text-[11px] leading-relaxed ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
                  Si Google Play Protect indique que l'application est inconnue, cliquez simplement sur <strong>"Détails"</strong> puis sur <strong>"Installer quand même"</strong>.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className={`p-4 border-t flex items-center justify-between gap-3 flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-neutral-950'
        }`}>
          <div className="flex items-center gap-2 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className={isLight ? 'text-slate-600' : 'text-neutral-400'}>
              Certifié SOMED Prestige · Sans virus
            </span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab(activeTab === 'INSTALL' ? 'DOWNLOAD' : 'INSTALL')}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition ${
                isLight 
                  ? 'border-slate-300 hover:bg-slate-100 text-slate-700' 
                  : 'border-neutral-800 hover:bg-neutral-900 text-neutral-300'
              }`}
            >
              {activeTab === 'INSTALL' ? 'Voir fichier APK' : 'Installation Directe'}
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black text-xs font-bold transition active:scale-95 shadow-sm"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
