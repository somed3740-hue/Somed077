import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  ShieldCheck, 
  Bell, 
  MapPin, 
  Mic, 
  Database, 
  Volume2, 
  Smartphone, 
  CheckCircle2, 
  AlertCircle, 
  HelpCircle, 
  RefreshCw,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Info
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';

interface PermissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerTestPush?: () => void;
}

export const PermissionsModal: React.FC<PermissionsModalProps> = ({
  isOpen,
  onClose,
  onTriggerTestPush,
}) => {
  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();

  const [pushStatus, setPushStatus] = useState<'granted' | 'denied' | 'default' | 'unsupported'>('default');
  const [geoStatus, setGeoStatus] = useState<'granted' | 'denied' | 'prompt' | 'unsupported'>('prompt');
  const [micStatus, setMicStatus] = useState<'granted' | 'denied' | 'prompt' | 'unsupported'>('prompt');
  const [storageStatus, setStorageStatus] = useState<'persisted' | 'prompt'>('persisted');
  const [isLoading, setIsLoading] = useState(false);
  const [showTroubleshoot, setShowTroubleshoot] = useState(false);

  // Check initial permissions
  useEffect(() => {
    if (!isOpen) return;

    // Check Push
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPushStatus(Notification.permission);
    } else {
      setPushStatus('unsupported');
    }

    // Check Geo
    if (typeof navigator !== 'undefined' && 'permissions' in navigator && navigator.permissions.query) {
      navigator.permissions.query({ name: 'geolocation' as PermissionName })
        .then((res) => {
          setGeoStatus(res.state as any);
          res.onchange = () => setGeoStatus(res.state as any);
        })
        .catch(() => {
          setGeoStatus('prompt');
        });
    }

    // Check Storage persistence
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persisted) {
      navigator.storage.persisted().then((isPersisted) => {
        setStorageStatus(isPersisted ? 'persisted' : 'prompt');
      });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Request Push
  const handleRequestPush = async () => {
    setIsLoading(true);
    try {
      const res = await vtcStore.requestPushPermission();
      setPushStatus(res);
      if (res === 'denied') {
        setShowTroubleshoot(true);
      }
    } catch {
      setPushStatus('denied');
      setShowTroubleshoot(true);
    } finally {
      setIsLoading(false);
    }
  };

  // Request Geo
  const handleRequestGeo = () => {
    if (typeof navigator !== 'undefined' && navigator.geolocation) {
      setIsLoading(true);
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setGeoStatus('granted');
          setIsLoading(false);
          vtcStore.sendPushNotification({
            title: 'Position GPS localisée',
            body: `Coordonnées détectées : ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}. Vos points de prise en charge sont précis.`,
            category: 'SYSTEM',
            badge: 'GPS Actif'
          });
        },
        () => {
          setGeoStatus('denied');
          setIsLoading(false);
          setShowTroubleshoot(true);
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    }
  };

  // Request Mic
  const handleRequestMic = async () => {
    if (typeof navigator !== 'undefined' && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        setIsLoading(true);
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        setMicStatus('granted');
        stream.getTracks().forEach(track => track.stop()); // release
        vtcStore.sendPushNotification({
          title: 'Microphone autorisé',
          body: 'Vous pouvez désormais passer des appels audio directs avec votre chauffeur.',
          category: 'SYSTEM',
          badge: 'Appels OK'
        });
      } catch {
        setMicStatus('denied');
        setShowTroubleshoot(true);
      } finally {
        setIsLoading(false);
      }
    }
  };

  // Enable all in 1-click
  const handleAuthorizeAll = async () => {
    await handleRequestPush();
    handleRequestGeo();
    await handleRequestMic();
  };

  // Trigger test push
  const handleTestPush = () => {
    vtcStore.sendPushNotification({
      title: 'Course Confirmée · Chauffeur en approche',
      body: 'Sofiane arrive dans 3 minutes avec sa Mercedes Classe E (GD-411-AZ).',
      category: 'RIDE',
      badge: 'Test Push',
      actions: [
        { id: 'track_test', label: 'Suivre le chauffeur', actionType: 'VIEW_RIDE', variant: 'primary' }
      ]
    });
    if (onTriggerTestPush) {
      onTriggerTestPush();
    }
  };

  return (
    <div className="fixed inset-0 z-[1400] flex flex-col bg-black/80 backdrop-blur-md text-white animate-in fade-in duration-200">
      <div className={`flex flex-col h-full max-w-lg mx-auto w-full border-x shadow-2xl transition-colors ${
        isLight ? 'bg-slate-50 border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-900 text-white'
      }`}>
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-white' : 'border-neutral-900 bg-black'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-neutral-900 text-neutral-300 hover:text-white'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="text-center">
            <h2 className="font-extrabold text-sm sm:text-base flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-yellow-500" />
              <span>Autorisations & Push</span>
            </h2>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Gestion des permissions de l'application
            </p>
          </div>

          <button
            onClick={handleTestPush}
            className="px-2.5 py-1 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black text-xs font-black transition active:scale-95 shadow-sm flex items-center gap-1"
            title="Tester une notification push immédiatement"
          >
            <Bell className="w-3.5 h-3.5 fill-black" />
            <span className="hidden xs:inline">Test Push</span>
          </button>
        </header>

        {/* Content body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Quick Banner Alert */}
          <div className={`p-4 rounded-2xl border flex items-start gap-3 ${
            isLight ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-yellow-500/10 border-yellow-500/30 text-yellow-200'
          }`}>
            <Info className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <p className="font-bold">Notifications Push descendantes en temps réel</p>
              <p className={`text-[11px] leading-relaxed ${isLight ? 'text-amber-800' : 'text-neutral-300'}`}>
                SOMED Prestige utilise des bannières push interactives pour vous avertir instantanément de l'approche du chauffeur, de l'état de votre course, et du suivi coursier.
              </p>
            </div>
          </div>

          {/* Quick Action: Tout Autoriser */}
          <button
            onClick={handleAuthorizeAll}
            disabled={isLoading}
            className="w-full py-3.5 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 active:scale-98 text-black font-black text-sm transition shadow-lg shadow-yellow-500/15 flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Autoriser toutes les permissions d'un clic</span>
          </button>

          {/* List of Permissions */}
          <div className="space-y-3">
            {/* 1. NOTIFICATIONS PUSH */}
            <div className={`p-4 rounded-2xl border transition ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'
            }`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center flex-shrink-0">
                    <Bell className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm">Notifications Push</h4>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        pushStatus === 'granted'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : pushStatus === 'denied'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}>
                        {pushStatus === 'granted' ? 'Autorisé' : pushStatus === 'denied' ? 'Refusé' : 'En attente'}
                      </span>
                    </div>
                    <p className={`text-xs mt-1 leading-relaxed ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Alertes push descendantes pour arrivée du chauffeur, validation de course et reçus de paiement.
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5 flex-shrink-0">
                  {pushStatus !== 'granted' ? (
                    <button
                      onClick={handleRequestPush}
                      disabled={isLoading}
                      className="px-3 py-1.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black text-xs font-black transition active:scale-95"
                    >
                      Autoriser
                    </button>
                  ) : (
                    <button
                      onClick={handleTestPush}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200'
                      }`}
                    >
                      Tester
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* 2. GÉOLOCALISATION GPS */}
            <div className={`p-4 rounded-2xl border transition ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'
            }`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm">Géolocalisation GPS</h4>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        geoStatus === 'granted'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : geoStatus === 'denied'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}>
                        {geoStatus === 'granted' ? 'Actif' : geoStatus === 'denied' ? 'Refusé' : 'À configurer'}
                      </span>
                    </div>
                    <p className={`text-xs mt-1 leading-relaxed ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Permet de positionner automatiquement votre adresse de départ et de suivre le chauffeur sur la carte en direct.
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleRequestGeo}
                  disabled={isLoading}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex-shrink-0 ${
                    geoStatus === 'granted'
                      ? isLight ? 'bg-slate-100 text-slate-700' : 'bg-neutral-800 text-neutral-300'
                      : 'bg-yellow-400 hover:bg-yellow-300 text-black font-black'
                  }`}
                >
                  {geoStatus === 'granted' ? 'Actualiser' : 'Activer'}
                </button>
              </div>
            </div>

            {/* 3. MICROPHONE & APPELS VOCAUX */}
            <div className={`p-4 rounded-2xl border transition ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'
            }`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center flex-shrink-0">
                    <Mic className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm">Microphone & Appels</h4>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        micStatus === 'granted'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}>
                        {micStatus === 'granted' ? 'Autorisé' : 'Optionnel'}
                      </span>
                    </div>
                    <p className={`text-xs mt-1 leading-relaxed ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Pour communiquer directement avec votre chauffeur via l'interphone VoIP sécurisé de l'application.
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleRequestMic}
                  disabled={isLoading}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex-shrink-0 ${
                    micStatus === 'granted'
                      ? isLight ? 'bg-slate-100 text-slate-700' : 'bg-neutral-800 text-neutral-300'
                      : 'bg-yellow-400 hover:bg-yellow-300 text-black font-black'
                  }`}
                >
                  {micStatus === 'granted' ? 'Vérifié' : 'Activer'}
                </button>
              </div>
            </div>

            {/* 4. STOCKAGE LOCAL & PERSISTANCE HORS-LIGNE */}
            <div className={`p-4 rounded-2xl border transition ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'
            }`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0">
                    <Database className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm">Stockage & Persistance</h4>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        Permanent
                      </span>
                    </div>
                    <p className={`text-xs mt-1 leading-relaxed ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Vos factures, coordonnées, historique et solde restent sauvegardés en local même sans connexion.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-emerald-500 text-xs font-bold pr-1">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>

          {/* Guide de dépannage si bloqué */}
          <div className={`p-4 rounded-2xl border transition ${
            isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-900/60 border-neutral-800'
          }`}>
            <button
              onClick={() => setShowTroubleshoot(!showTroubleshoot)}
              className="w-full flex items-center justify-between text-left font-bold text-xs"
            >
              <div className="flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-yellow-500" />
                <span>Comment débloquer une permission dans votre navigateur ?</span>
              </div>
              <ChevronRight className={`w-4 h-4 transition-transform ${showTroubleshoot ? 'rotate-90' : ''}`} />
            </button>

            {showTroubleshoot && (
              <div className="mt-3 pt-3 border-t border-neutral-500/20 text-xs space-y-2.5">
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center text-[10px] flex-shrink-0">1</span>
                  <p className={isLight ? 'text-slate-600' : 'text-neutral-300'}>
                    Cliquez sur l'icône de <strong>cadenas 🔒</strong> ou de <strong>réglages de site</strong> située tout à gauche de la barre d'adresse de votre navigateur.
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center text-[10px] flex-shrink-0">2</span>
                  <p className={isLight ? 'text-slate-600' : 'text-neutral-300'}>
                    Trouvez <strong>"Notifications"</strong> et <strong>"Position"</strong>, puis basculez l'interrupteur sur <strong>Autoriser</strong>.
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center text-[10px] flex-shrink-0">3</span>
                  <p className={isLight ? 'text-slate-600' : 'text-neutral-300'}>
                    Rechargez la page pour profiter de la synchronisation push instantanée.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <footer className={`p-4 border-t flex items-center justify-between ${
          isLight ? 'border-slate-200 bg-white' : 'border-neutral-900 bg-neutral-950'
        }`}>
          <button
            onClick={onClose}
            className={`w-full py-3 rounded-xl font-bold text-xs transition ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'
            }`}
          >
            Fermer les autorisations
          </button>
        </footer>
      </div>
    </div>
  );
};
