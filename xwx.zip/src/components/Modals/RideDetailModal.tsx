import React, { useState } from 'react';
import { 
  X, 
  MapPin, 
  Car, 
  Calendar, 
  Clock, 
  Download, 
  Share2, 
  Mail, 
  CheckCircle2, 
  ShieldCheck, 
  Receipt, 
  User, 
  CreditCard, 
  Star,
  Copy,
  Send,
  Sparkles
} from 'lucide-react';
import { Ride } from '../../types/vtc';
import { formatEuro } from '../../utils/geo';
import { generateInvoicePDF } from '../../utils/invoice';
import { vtcStore } from '../../services/vtcStore';
import { soundEffects } from '../../utils/audio';

interface RideDetailModalProps {
  ride: Ride | null;
  isOpen: boolean;
  onClose: () => void;
}

export const RideDetailModal: React.FC<RideDetailModalProps> = ({
  ride,
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [emailSent, setEmailSent] = useState(false);

  if (!isOpen || !ride) return null;

  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();
  const invoiceNum = ride.invoiceNumber || `FAC-${new Date(ride.createdAt).getFullYear()}-${ride.id.slice(-6).toUpperCase()}`;

  const dateFormatted = new Date(ride.createdAt).toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const timeFormatted = new Date(ride.createdAt).toLocaleTimeString('fr-FR', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const totalTTC = ride.fare + (ride.tip || 0);
  const vatRate = 0.10;
  const totalHT = totalTTC / (1 + vatRate);
  const vatAmount = totalTTC - totalHT;

  const handleDownloadPDF = () => {
    soundEffects.playClick();
    generateInvoicePDF(ride);
    vtcStore.sendPushNotification({
      title: 'Facture téléchargée',
      body: `La facture PDF ${invoiceNum} a été téléchargée avec succès.`,
      category: 'PAYMENT',
      badge: 'Facture PDF'
    });
  };

  const handleShare = async () => {
    soundEffects.playClick();
    const shareText = `Course SOMED Prestige #${ride.id.slice(-4)}\nDe : ${ride.pickup.name || ride.pickup.address}\nÀ : ${ride.destination.name || ride.destination.address}\nChauffeur : ${ride.driverName || 'VTC'}\nMontant : ${formatEuro(totalTTC)}\nFacture : ${invoiceNum}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `Détails de course SOMED Prestige - ${invoiceNum}`,
          text: shareText,
          url: window.location.href,
        });
        return;
      } catch {
        // User cancelled or unsupported
      }
    }

    try {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      soundEffects.playClick();
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    const targetEmail = recipientEmail.trim() || passenger.email || 'client@somed.biz';
    soundEffects.playSuccessSound();
    setEmailSent(true);

    vtcStore.sendPushNotification({
      title: 'Facture envoyée par email',
      body: `Le reçu acquitté (${invoiceNum}) pour ${formatEuro(totalTTC)} a été transmis à ${targetEmail}.`,
      category: 'PAYMENT',
      badge: 'Email Envoyé'
    });

    setTimeout(() => {
      setEmailSent(false);
      setShowEmailModal(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[1400] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className={`w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] transition-colors ${
        isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
      }`}>
        {/* Header */}
        <header className={`p-5 pb-4 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-neutral-900/60'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-yellow-400 p-1 flex items-center justify-center shadow-lg shadow-yellow-500/10">
              <Receipt className="w-5 h-5 text-black stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base">Détails & Facture Course</h3>
                <span className="text-[10px] font-mono font-bold bg-yellow-400/20 text-yellow-500 border border-yellow-400/30 px-2 py-0.5 rounded-full">
                  #{invoiceNum}
                </span>
              </div>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                {dateFormatted} à {timeFormatted}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition ${
              isLight ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </header>

        {/* Content Body */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {/* Status & Price Highlight */}
          <div className={`p-4 rounded-2xl border flex items-center justify-between ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/80 border-neutral-800'
          }`}>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-500 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Course réglée & acquittée
              </span>
              <p className="text-xs text-neutral-400 mt-0.5">
                Gamme {ride.category} · {ride.distanceKm} km · {ride.durationMin} min
              </p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-black text-emerald-400">{formatEuro(totalTTC)}</p>
              <p className="text-[10px] text-neutral-500">TTC (TVA 10% incluse)</p>
            </div>
          </div>

          {/* Itinerary */}
          <div className={`p-4 rounded-2xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-900/40 border-neutral-800'
          }`}>
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400">Itinéraire emprunté</h4>
            
            <div className="space-y-2.5">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <MapPin className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-xs text-neutral-400">Prise en charge</p>
                  <p className="text-sm font-semibold text-white">
                    {ride.pickup.name || ride.pickup.address}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <MapPin className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-xs text-neutral-400">Destination finale</p>
                  <p className="text-sm font-semibold text-white">
                    {ride.destination.name || ride.destination.address}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Driver & Vehicle */}
          <div className={`p-4 rounded-2xl border flex items-center justify-between ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
          }`}>
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center font-bold text-white text-base">
                {ride.driverName?.charAt(0) || 'C'}
              </div>
              <div>
                <p className="text-sm font-bold text-white">{ride.driverName || 'Chauffeur VTC Partenaire'}</p>
                <p className="text-xs text-neutral-400">
                  {ride.vehicleModel || 'Berline VTC'} · {ride.vehiclePlate || 'N/A'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1 text-xs text-amber-400 bg-amber-400/10 border border-amber-400/20 px-2.5 py-1 rounded-xl">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
              <span>{ride.driverRating?.toFixed(2) || '4.95'}</span>
            </div>
          </div>

          {/* Breakdown & Taxes */}
          <div className={`p-4 rounded-2xl border space-y-2 text-xs ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
          }`}>
            <h4 className="font-bold text-neutral-400 uppercase tracking-wider text-[11px] mb-2">
              Détail financier & TVA
            </h4>

            <div className="flex justify-between items-center text-neutral-300">
              <span>Montant HT prestation transport</span>
              <span className="font-semibold text-white">{formatEuro(totalHT)}</span>
            </div>

            <div className="flex justify-between items-center text-neutral-300">
              <span>TVA transport de personnes (10.00 %)</span>
              <span className="font-semibold text-white">{formatEuro(vatAmount)}</span>
            </div>

            {ride.tip && ride.tip > 0 && (
              <div className="flex justify-between items-center text-amber-400">
                <span>Pourboire chauffeur (exonéré)</span>
                <span className="font-semibold">+{formatEuro(ride.tip)}</span>
              </div>
            )}

            <div className="pt-2 border-t border-neutral-800 flex justify-between items-center font-bold text-sm text-white">
              <span>Total Débité (TTC)</span>
              <span className="text-emerald-400">{formatEuro(totalTTC)}</span>
            </div>

            <div className="flex justify-between items-center text-[11px] text-neutral-500 pt-1">
              <span>Mode de règlement</span>
              <span className="font-medium text-neutral-300 flex items-center gap-1">
                <CreditCard className="w-3 h-3 text-yellow-400" />
                {ride.paymentMethod === 'CARD' ? 'Carte bancaire •••• 4242' : ride.paymentMethod === 'APPLE_PAY' ? 'Apple Pay' : 'Espèces'}
              </span>
            </div>
          </div>

          {/* 3 Main Action Buttons requested: Partager, Télécharger, Envoi par email */}
          <div className="grid grid-cols-3 gap-2.5 pt-1">
            <button
              onClick={handleShare}
              className={`py-3 px-2 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition active:scale-95 ${
                isLight 
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300' 
                  : 'bg-neutral-900 hover:bg-neutral-800 text-white border-neutral-800'
              }`}
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span className="text-[11px] text-emerald-400">Copié !</span>
                </>
              ) : (
                <>
                  <Share2 className="w-5 h-5 text-blue-400" />
                  <span className="text-[11px]">Partager</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownloadPDF}
              className="py-3 px-2 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black text-xs font-black flex flex-col items-center justify-center gap-1.5 transition active:scale-95 shadow-lg shadow-yellow-500/10"
            >
              <Download className="w-5 h-5 stroke-[2.5]" />
              <span className="text-[11px]">Télécharger PDF</span>
            </button>

            <button
              onClick={() => {
                setRecipientEmail(passenger.email || '');
                setShowEmailModal(true);
              }}
              className={`py-3 px-2 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition active:scale-95 ${
                isLight 
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300' 
                  : 'bg-neutral-900 hover:bg-neutral-800 text-white border-neutral-800'
              }`}
            >
              <Mail className="w-5 h-5 text-emerald-400" />
              <span className="text-[11px]">Envoi par email</span>
            </button>
          </div>
        </div>

        {/* Email Prompt Modal / Overlay */}
        {showEmailModal && (
          <div className="absolute inset-0 z-50 bg-black/85 backdrop-blur-sm p-6 flex items-center justify-center animate-in fade-in duration-150">
            <div className={`w-full max-w-sm rounded-3xl border p-5 space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
            }`}>
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                <div className="flex items-center gap-2">
                  <Mail className="w-5 h-5 text-yellow-500" />
                  <h4 className="font-bold text-sm">Transmettre la facture par email</h4>
                </div>
                <button
                  onClick={() => setShowEmailModal(false)}
                  className="w-7 h-7 rounded-lg text-neutral-400 hover:text-white flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {emailSent ? (
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                  <p className="text-xs font-bold text-emerald-400">Facture transmise avec succès !</p>
                  <p className="text-[11px] text-neutral-400">Consultez votre boîte de réception.</p>
                </div>
              ) : (
                <form onSubmit={handleSendEmail} className="space-y-3">
                  <div>
                    <label className="text-xs font-medium block mb-1 text-neutral-400">
                      Adresse email destinataire :
                    </label>
                    <input
                      type="email"
                      value={recipientEmail}
                      onChange={(e) => setRecipientEmail(e.target.value)}
                      placeholder="nom@exemple.com"
                      required
                      className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                        isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-900 border-neutral-800 text-white'
                      }`}
                    />
                  </div>

                  <p className="text-[11px] text-neutral-500">
                    La facture officielle N° {invoiceNum} avec TVA et mentions légales sera envoyée en pièce jointe PDF.
                  </p>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowEmailModal(false)}
                      className="flex-1 py-2.5 rounded-xl border border-neutral-800 text-xs font-semibold text-neutral-400 hover:text-white"
                    >
                      Annuler
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Envoyer</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
