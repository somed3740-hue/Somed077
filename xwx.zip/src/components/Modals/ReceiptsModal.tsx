import React from 'react';
import { ArrowLeft, Receipt, ChevronRight, Download } from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { generateInvoicePDF } from '../../utils/invoice';
import { Ride } from '../../types/vtc';

interface ReceiptsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onViewReceipt: (ride: Ride) => void;
}

interface ReceiptItem {
  id: string;
  amount: number;
  route: string;
  date: string;
  ride?: Ride;
}

export const ReceiptsModal: React.FC<ReceiptsModalProps> = ({
  isOpen,
  onClose,
  onViewReceipt,
}) => {
  if (!isOpen) return null;

  const rides = vtcStore.getAllRides();

  // Create sample receipt items including the one from Screenshot 10
  const receipts: ReceiptItem[] = [
    {
      id: 'REC-20260917-0001',
      amount: 1.50,
      route: '18 avenue idrissides -> Dr. Morsi Barakat Jamal',
      date: '11/9/2026',
    },
    ...rides.map((r, i) => ({
      id: r.invoiceNumber || `REC-202609${18 + i}-000${i + 2}`,
      amount: r.fare,
      route: `${r.pickup.name || r.pickup.address} -> ${r.destination.name || r.destination.address}`,
      date: new Date(r.createdAt).toLocaleDateString('fr-FR'),
      ride: r,
    })),
  ];

  const handleDownload = (e: React.MouseEvent, rItem: ReceiptItem) => {
    e.stopPropagation();
    if (rItem.ride) {
      generateInvoicePDF(rItem.ride);
    } else {
      // Mock ride to generate invoice
      const sampleRide: Ride = {
        id: 'sample-rec-1',
        passengerId: 'usr-1',
        passengerName: 'SOMED dine',
        passengerPhone: '+3360587241',
        passengerRating: 4.0,
        pickup: { lat: 31.6225, lng: -8.0125, address: '18 avenue idrissides, Marrakech', name: '18 avenue idrissides' },
        destination: { lat: 31.6300, lng: -8.0100, address: 'Dr. Morsi Barakat Jamal', name: 'Dr. Morsi Barakat Jamal' },
        category: 'STANDARD',
        distanceKm: 2.1,
        durationMin: 7,
        fare: 1.50,
        paymentMethod: 'CARD',
        status: 'COMPLETED',
        createdAt: Date.now() - 3600 * 1000 * 24 * 5,
        invoiceNumber: rItem.id,
      };
      generateInvoicePDF(sampleRide);
    }
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col bg-black text-white select-none animate-in fade-in duration-200">
      {/* Top Header (Screenshot 10) */}
      <header className="px-5 py-4 border-b border-neutral-900 flex items-center justify-between flex-shrink-0 bg-black">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-base text-white">My Receipts</h2>
        <div className="w-9" />
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-3 max-w-md mx-auto w-full">
        {receipts.map((rec) => (
          <div
            key={rec.id}
            onClick={() => {
              if (rec.ride) {
                onViewReceipt(rec.ride);
              }
            }}
            className="bg-neutral-950 border border-neutral-900 rounded-2xl p-4 flex items-center justify-between hover:border-neutral-800 transition cursor-pointer group shadow-sm"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              {/* Yellow Square Receipt Icon (Screenshot 10) */}
              <div className="w-11 h-11 rounded-xl bg-yellow-400/20 border border-yellow-400/40 text-yellow-400 flex items-center justify-center flex-shrink-0">
                <Receipt className="w-5 h-5 stroke-[2]" />
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-bold text-sm text-white truncate">#{rec.id}</p>
                  <span className="font-bold text-xs text-yellow-400">€{rec.amount.toFixed(2)}</span>
                </div>
                <p className="text-xs text-neutral-400 truncate mt-0.5">{rec.route}</p>
                <p className="text-[11px] text-neutral-500 mt-0.5">{rec.date}</p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 flex-shrink-0">
              <button
                onClick={(e) => handleDownload(e, rec)}
                className="w-8 h-8 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-yellow-400 flex items-center justify-center transition"
                title="Télécharger la facture PDF"
              >
                <Download className="w-4 h-4" />
              </button>
              <ChevronRight className="w-4 h-4 text-neutral-600 group-hover:text-neutral-300" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
