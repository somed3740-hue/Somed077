import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Phone, 
  MessageSquare, 
  ShieldAlert, 
  HelpCircle, 
  Send, 
  ChevronRight, 
  CheckCircle2, 
  Clock, 
  ExternalLink,
  LifeBuoy,
  FileQuestion,
  Headphones,
  AlertTriangle,
  X
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { soundEffects } from '../../utils/audio';

interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartCall?: (phoneNumber: string, name: string) => void;
}

interface SupportMessage {
  id: string;
  sender: 'user' | 'support';
  text: string;
  time: string;
}

export const SupportModal: React.FC<SupportModalProps> = ({
  isOpen,
  onClose,
  onStartCall,
}) => {
  const [activeTab, setActiveTab] = useState<'HOTLINE' | 'CHAT' | 'INCIDENT' | 'FAQ'>('HOTLINE');
  const [selectedIncidentType, setSelectedIncidentType] = useState<string>('');
  const [incidentDescription, setIncidentDescription] = useState('');
  const [incidentSubmitted, setIncidentSubmitted] = useState(false);

  // Live support chat state
  const [chatMessages, setChatMessages] = useState<SupportMessage[]>([
    {
      id: 'msg-1',
      sender: 'support',
      text: 'Bonjour ! Bienvenue au service conciergerie & support SOMED Prestige. Comment pouvons-nous vous assister aujourd\'hui ?',
      time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();
  const recentRides = vtcStore.getAllRides().filter((r) => r.passengerId === passenger.id);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const userMsg: SupportMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: inputMessage,
      time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    const query = inputMessage;
    setInputMessage('');
    soundEffects.playClick();

    // Simulate concierge instant response
    setIsTyping(true);
    setTimeout(() => {
      let reply = 'Votre demande a bien été prise en charge par notre superviseur d\'astreinte. Un gestionnaire de compte examine votre dossier.';
      const lower = query.toLowerCase();
      if (lower.includes('code') || lower.includes('course')) {
        reply = 'Le code de sécurité à 4 chiffres s\'affiche directement sur votre écran dès qu\'un chauffeur accepte. Vous pouvez cliquer sur "Partager avec le chauffeur" pour lui transmettre instantanément.';
      } else if (lower.includes('facture') || lower.includes('reçu') || lower.includes('remboursement')) {
        reply = 'Toutes vos factures acquittées sont disponibles avec TVA 10% dans votre onglet Activité et reçus. Vous pouvez les télécharger en PDF ou les renvoyer par email en un clic.';
      } else if (lower.includes('oubli') || lower.includes('perdu')) {
        reply = 'Pour tout objet oublié à bord, nous pouvons joindre votre dernier chauffeur en priorité ou bloquer le véhicule pour vérification immédiate.';
      } else if (lower.includes('tarif') || lower.includes('prix')) {
        reply = 'Nos tarifs sont garantis à la réservation sans surprise. En cas d\'écart inhabituel, notre service comptabilité régularise sur votre compte SOMED.';
      }

      setChatMessages((prev) => [
        ...prev,
        {
          id: `sup-${Date.now()}`,
          sender: 'support',
          text: reply,
          time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      setIsTyping(false);
      soundEffects.playPushNotificationSound();
    }, 1200);
  };

  const handleCallHotline = () => {
    soundEffects.playClick();
    if (onStartCall) {
      onStartCall('+33 1 89 20 44 00', 'Conciergerie SOMED Prestige 24/7');
    } else {
      window.open('tel:+33189204400');
    }
  };

  const handleSubmitIncident = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIncidentType) return;

    vtcStore.sendPushNotification({
      title: 'Ticket support ouvert #TK-' + Math.floor(10000 + Math.random() * 90000),
      body: `Votre signalement (${selectedIncidentType}) a été transmis aux équipes d'astreinte SOMED. Réponse sous 15 min.`,
      category: 'SECURITY',
      badge: 'Support 24/7'
    });

    setIncidentSubmitted(true);
    soundEffects.playRideCompleted();
    setTimeout(() => {
      setIncidentSubmitted(false);
      setSelectedIncidentType('');
      setIncidentDescription('');
      setActiveTab('HOTLINE');
    }, 2200);
  };

  const faqs = [
    {
      q: 'Comment partager le code de confirmation avec le chauffeur ?',
      a: 'Dès que le chauffeur est assigné ou arrive, votre code de sécurité à 4 chiffres s\'affiche. Cliquez sur le bouton "Partager avec le chauffeur" pour l\'envoyer directement sur son écran GPS.',
    },
    {
      q: 'Comment obtenir et télécharger ma facture avec TVA ?',
      a: 'Rendez-vous dans "Activité" ou "Reçus" depuis le menu. Chaque course permet de télécharger un PDF officiel ou de l\'envoyer à votre adresse email.',
    },
    {
      q: 'Comment basculer entre les modes Passager, Chauffeur, Business et Dispatch ?',
      a: 'Cliquez sur le bouton "Switch Mode" en haut de l\'écran pour afficher le sélecteur complet des interfaces SOMED.',
    },
    {
      q: 'Quels sont les délais d\'attente garantis ?',
      a: 'À Paris et petite couronne, nos chauffeurs partenaires arrivent en moyenne en 3 à 5 minutes pour les gammes Standard et Confort, et 4 minutes pour les gammes Berline Luxe et Van.',
    },
  ];

  return (
    <div className="fixed inset-0 z-[1400] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className={`w-full max-w-lg rounded-3xl border shadow-2xl flex flex-col h-[85vh] max-h-[720px] overflow-hidden transition-colors ${
        isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
      }`}>
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-neutral-900/60'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-yellow-400 p-1 flex items-center justify-center shadow-lg shadow-yellow-500/10 ring-2 ring-yellow-400/40">
              <Headphones className="w-5 h-5 text-black stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-extrabold text-base flex items-center gap-2">
                <span>Assistance & Conciergerie</span>
                <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                  En direct 24/7
                </span>
              </h3>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Support dédié passagers, chauffeurs et partenaires SOMED
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition ${
              isLight ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </header>

        {/* Tab switcher */}
        <div className={`px-4 pt-3 border-b flex items-center gap-1.5 overflow-x-auto no-scrollbar flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-slate-100/60' : 'border-neutral-900 bg-neutral-900/40'
        }`}>
          <button
            onClick={() => setActiveTab('HOTLINE')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'HOTLINE'
                ? 'bg-yellow-400 text-black shadow-sm'
                : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Hotline 24/7</span>
          </button>

          <button
            onClick={() => setActiveTab('CHAT')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'CHAT'
                ? 'bg-yellow-400 text-black shadow-sm'
                : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Tchat Concierge</span>
          </button>

          <button
            onClick={() => setActiveTab('INCIDENT')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'INCIDENT'
                ? 'bg-yellow-400 text-black shadow-sm'
                : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Signaler un incident</span>
          </button>

          <button
            onClick={() => setActiveTab('FAQ')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'FAQ'
                ? 'bg-yellow-400 text-black shadow-sm'
                : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>FAQ</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-5">
          {/* 1. HOTLINE TAB */}
          {activeTab === 'HOTLINE' && (
            <div className="space-y-4">
              {/* Emergency Banner */}
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-3">
                <ShieldAlert className="w-6 h-6 text-rose-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-sm text-rose-400">Urgence & Sécurité immédiate</h4>
                  <p className="text-xs text-rose-300/80 mt-0.5">
                    En cas de danger réel sur la voie publique, composez immédiatement le <strong>17</strong> (Police Secours) ou le <strong>112</strong>.
                  </p>
                </div>
              </div>

              {/* Concierge Call Card */}
              <div className={`p-5 rounded-3xl border text-center space-y-3.5 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900 border-neutral-800'
              }`}>
                <div className="w-16 h-16 rounded-full bg-yellow-400 text-black flex items-center justify-center mx-auto shadow-xl shadow-yellow-500/20 ring-4 ring-yellow-400/20">
                  <Phone className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="font-black text-base">Ligne Directe Chauffeurs & Passagers</h4>
                  <p className="text-xs text-yellow-500 font-bold mt-1 tracking-wider text-lg">
                    +33 1 89 20 44 00
                  </p>
                  <p className={`text-xs mt-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Temps d'attente moyen : moins de 30 secondes · Appel gratuit non surtaxé
                  </p>
                </div>

                <button
                  onClick={handleCallHotline}
                  className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold rounded-2xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-yellow-400/20 transition active:scale-95"
                >
                  <Phone className="w-4 h-4 fill-current" />
                  <span>Lancer l'appel assistance</span>
                </button>
              </div>

              {/* Priority Contact Details */}
              <div className={`p-4 rounded-2xl border space-y-2.5 text-xs ${
                isLight ? 'bg-white border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
              }`}>
                <div className="flex justify-between items-center">
                  <span className="text-neutral-400">Email assistance client :</span>
                  <span className="font-semibold text-yellow-500">support@somed.biz</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-neutral-400">Service litiges & facturation :</span>
                  <span className="font-semibold text-yellow-500">facturation@somed.biz</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-neutral-400">Disponibilité :</span>
                  <span className="font-semibold text-emerald-400">7j/7 - 24h/24</span>
                </div>
              </div>
            </div>
          )}

          {/* 2. LIVE CHAT TAB */}
          {activeTab === 'CHAT' && (
            <div className="h-full flex flex-col -m-5 p-5">
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-yellow-400 text-black font-medium rounded-br-none shadow-md'
                        : isLight
                        ? 'bg-slate-100 text-slate-800 border border-slate-200 rounded-bl-none'
                        : 'bg-neutral-900 text-neutral-100 border border-neutral-800 rounded-bl-none'
                    }`}>
                      {msg.text}
                    </div>
                    <span className="text-[10px] text-neutral-500 mt-1 px-1">{msg.time}</span>
                  </div>
                ))}

                {isTyping && (
                  <div className="flex items-center gap-1.5 text-xs text-neutral-400 py-1">
                    <span className="w-2 h-2 rounded-full bg-yellow-400 animate-bounce" />
                    <span className="w-2 h-2 rounded-full bg-yellow-400 animate-bounce [animation-delay:0.2s]" />
                    <span className="w-2 h-2 rounded-full bg-yellow-400 animate-bounce [animation-delay:0.4s]" />
                    <span className="text-[11px] ml-1">L'opérateur SOMED rédige...</span>
                  </div>
                )}
              </div>

              {/* Chat Input */}
              <form onSubmit={handleSendMessage} className="pt-3 border-t flex items-center gap-2 mt-auto">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Posez votre question à notre concierge..."
                  className={`flex-1 px-4 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                    isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
                <button
                  type="submit"
                  disabled={!inputMessage.trim()}
                  className="w-10 h-10 rounded-xl bg-yellow-400 hover:bg-yellow-300 disabled:opacity-40 text-black flex items-center justify-center transition active:scale-95 shadow-md flex-shrink-0"
                >
                  <Send className="w-4 h-4 stroke-[2.5]" />
                </button>
              </form>
            </div>
          )}

          {/* 3. REPORT INCIDENT TAB */}
          {activeTab === 'INCIDENT' && (
            <div className="space-y-4">
              {incidentSubmitted ? (
                <div className="p-8 text-center space-y-3 bg-emerald-500/10 border border-emerald-500/30 rounded-3xl">
                  <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
                  <h4 className="font-extrabold text-base text-white">Signalement transmis</h4>
                  <p className="text-xs text-emerald-300">
                    Notre équipe d'astreinte a reçu votre dossier prioritaire. Une notification vous sera envoyée dès prise en charge.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmitIncident} className="space-y-4">
                  <div>
                    <label className="text-xs font-bold block mb-1.5">Type de signalement :</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        'Objet oublié dans le véhicule',
                        'Problème de facturation',
                        'Comportement ou retard chauffeur',
                        'Incident sur le véhicule',
                        'Course non effectuée',
                        'Autre demande urgente'
                      ].map((motif) => (
                        <button
                          key={motif}
                          type="button"
                          onClick={() => setSelectedIncidentType(motif)}
                          className={`p-2.5 rounded-xl border text-xs font-semibold text-left transition ${
                            selectedIncidentType === motif
                              ? 'bg-yellow-400 text-black border-yellow-500 shadow-md'
                              : isLight
                              ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                              : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-850'
                          }`}
                        >
                          {motif}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold block mb-1.5">Précisions sur l'incident :</label>
                    <textarea
                      value={incidentDescription}
                      onChange={(e) => setIncidentDescription(e.target.value)}
                      placeholder="Indiquez le numéro de course ou décrivez ce qu'il s'est passé..."
                      rows={4}
                      className={`w-full p-3 rounded-2xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                        isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                      }`}
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={!selectedIncidentType}
                    className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 disabled:opacity-40 text-black font-extrabold rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-yellow-400/20 transition active:scale-95"
                  >
                    <Send className="w-4 h-4" />
                    <span>Transmettre au superviseur d'astreinte</span>
                  </button>
                </form>
              )}
            </div>
          )}

          {/* 4. FAQ TAB */}
          {activeTab === 'FAQ' && (
            <div className="space-y-3">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className={`p-4 rounded-2xl border space-y-1.5 ${
                    isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
                  }`}
                >
                  <h4 className="font-bold text-xs text-yellow-500 flex items-center gap-2">
                    <HelpCircle className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>{faq.q}</span>
                  </h4>
                  <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
                    {faq.a}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
