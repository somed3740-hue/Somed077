import React, { useState } from 'react';
import { ArrowLeft, Camera, Check, X, User, Phone, Mail, Image as ImageIcon } from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const passenger = vtcStore.getPassenger();
  const [name, setName] = useState(passenger.name);
  const [phone, setPhone] = useState(passenger.phone);
  const [email, setEmail] = useState(passenger.email);
  const [avatarUrl, setAvatarUrl] = useState(passenger.avatarUrl);
  const [isSaved, setIsSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    vtcStore.updatePassengerProfile({
      name,
      phone,
      email,
      avatarUrl,
    });
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 700);
  };

  const sampleAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  ];

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col bg-black text-white select-none animate-in fade-in duration-200">
      {/* Header */}
      <header className="px-5 py-4 border-b border-neutral-900 flex items-center justify-between flex-shrink-0 bg-black">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-base text-white">Edit profile</h2>
        <div className="w-9" />
      </header>

      {/* Form */}
      <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5 max-w-md mx-auto w-full">
        {/* Avatar preview */}
        <div className="flex flex-col items-center py-2 space-y-3">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-neutral-900 border-2 border-yellow-400 p-0.5 overflow-hidden flex items-center justify-center shadow-xl">
              <img
                src={avatarUrl}
                alt={name}
                className="w-full h-full object-cover rounded-full"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            {sampleAvatars.map((url, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setAvatarUrl(url)}
                className={`w-9 h-9 rounded-full overflow-hidden border-2 transition ${
                  avatarUrl === url ? 'border-yellow-400 scale-105' : 'border-neutral-800 opacity-60'
                }`}
              >
                <img src={url} alt="preset" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Inputs */}
        <div className="space-y-4 bg-neutral-950 p-5 rounded-3xl border border-neutral-900 shadow-sm">
          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-yellow-400" />
              <span>Nom complet</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400 font-medium"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1.5 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-yellow-400" />
              <span>Numéro de téléphone</span>
            </label>
            <input
              type="text"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400 font-medium font-mono"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1.5 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-yellow-400" />
              <span>Email de facturation</span>
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400 font-medium"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1.5 flex items-center gap-1.5">
              <ImageIcon className="w-3.5 h-3.5 text-yellow-400" />
              <span>URL de l'image de profil</span>
            </label>
            <input
              type="url"
              value={avatarUrl}
              onChange={(e) => setAvatarUrl(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400 font-mono"
            />
          </div>
        </div>

        {/* Submit */}
        <button
          type="submit"
          className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-black rounded-2xl transition active:scale-98 text-sm shadow-xl shadow-yellow-400/10 flex items-center justify-center gap-2"
        >
          {isSaved ? (
            <>
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Modifications enregistrées !</span>
            </>
          ) : (
            <span>Enregistrer le profil</span>
          )}
        </button>
      </form>
    </div>
  );
};
