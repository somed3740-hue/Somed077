import React from 'react';
import { ArrowLeft, Clock, Calendar, Trash2, Play } from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';

interface ScheduledTripsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBookNewTrip?: () => void;
}

export const ScheduledTripsModal: React.FC<ScheduledTripsModalProps> = ({
  isOpen,
  onClose,
  onBookNewTrip,
}) => {
  if (!isOpen) return null;

  const scheduledRides = vtcStore.getScheduledRides();

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col bg-black text-white select-none animate-in fade-in duration-200">
      {/* Header (Screenshot 4) */}
      <header className="px-5 py-4 border-b border-neutral-900 flex items-center justify-between flex-shrink-0 bg-black">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-base text-white">Scheduled trips</h2>
        <div className="w-9" />
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-5 flex flex-col items-center justify-center max-w-md mx-auto w-full">
        {scheduledRides.length === 0 ? (
          /* Empty State (Screenshot 4) */
          <div className="flex flex-col items-center justify-center text-center space-y-4 py-20">
            <div className="w-20 h-20 rounded-full border-2 border-neutral-800 flex items-center justify-center text-neutral-500">
              <Clock className="w-10 h-10 stroke-[1.5]" />
            </div>
            <p className="text-sm font-semibold text-neutral-400">
              No tienes viajes programados
            </p>
            <p className="text-xs text-neutral-600 max-w-xs">
              Vous pouvez planifier une course à l'avance depuis l'onglet Taxi.
            </p>

            {onBookNewTrip && (
              <button
                onClick={() => {
                  onClose();
                  onBookNewTrip();
                }}
                className="mt-4 px-6 py-3 bg-yellow-400 text-black font-bold text-xs rounded-xl shadow-lg hover:bg-yellow-300 transition"
              >
                Planifier une course
              </button>
            )}
          </div>
        ) : (
          <div className="w-full space-y-3">
            {scheduledRides.map((sr) => (
              <div
                key={sr.id}
                className="bg-neutral-950 border border-neutral-900 rounded-2xl p-4 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-yellow-400">
                    <Calendar className="w-4 h-4" />
                    <span>
                      {sr.scheduledFor
                        ? new Date(sr.scheduledFor).toLocaleString('fr-FR', {
                            dateStyle: 'medium',
                            timeStyle: 'short',
                          })
                        : 'Planifié'}
                    </span>
                  </div>
                  <span className="font-bold text-white text-sm">{formatEuro(sr.fare)}</span>
                </div>

                <div className="text-xs space-y-1 text-neutral-300">
                  <p className="truncate">
                    <strong className="text-emerald-400 font-semibold">De :</strong> {sr.pickup.name || sr.pickup.address}
                  </p>
                  <p className="truncate">
                    <strong className="text-rose-400 font-semibold">Vers :</strong> {sr.destination.name || sr.destination.address}
                  </p>
                </div>

                <div className="pt-2 border-t border-neutral-900 flex items-center justify-between">
                  <button
                    onClick={() => {
                      vtcStore.activateScheduledRide(sr.id);
                      onClose();
                    }}
                    className="px-3.5 py-1.5 bg-yellow-400 text-black font-bold text-xs rounded-xl hover:bg-yellow-300 transition flex items-center gap-1.5"
                  >
                    <Play className="w-3.5 h-3.5 fill-black" />
                    <span>Déclencher maintenant</span>
                  </button>

                  <button
                    onClick={() => vtcStore.cancelRide(sr.id)}
                    className="text-xs text-rose-400 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Annuler</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
