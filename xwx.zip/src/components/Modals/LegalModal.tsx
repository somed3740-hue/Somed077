import React from 'react';
import { 
  X, 
  FileText, 
  ShieldCheck, 
  ExternalLink, 
  CheckCircle2, 
  Mail, 
  HelpCircle,
  MapPin,
  Smartphone,
  Shield,
  Scale
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';

interface LegalModalProps {
  isOpen: boolean;
  type: 'terms' | 'privacy';
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ isOpen, type, onClose }) => {
  const isLight = vtcStore.isLightMode();

  if (!isOpen) return null;

  const isTerms = type === 'terms';
  const title = isTerms ? "Conditions d'Utilisation de SOMED" : "Politique de Confidentialité (RGPD) - SOMED";
  const pageUrl = isTerms ? "/terms.html" : "/privacy.html";

  return (
    <div className="fixed inset-0 z-[3200] flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className={`border rounded-3xl w-full max-w-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
        isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
      }`}>
        {/* Top Header */}
        <div className={`p-4 sm:p-5 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-slate-50/90' : 'border-neutral-900 bg-neutral-900/70'
        }`}>
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-sm ${
              isTerms 
                ? 'bg-yellow-400/20 text-yellow-500 border border-yellow-400/40' 
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
            }`}>
              {isTerms ? <FileText className="w-5 h-5 text-yellow-500" /> : <ShieldCheck className="w-5 h-5 text-emerald-400" />}
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base leading-tight">
                {title}
              </h3>
              <p className={`text-[11px] mt-0.5 font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Document officiel · Dernière mise à jour : 01-10-2026 · SOMED
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={pageUrl}
              target="_blank"
              rel="noreferrer"
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
              }`}
              title="Ouvrir dans un nouvel onglet plein écran"
            >
              <ExternalLink className="w-3.5 h-3.5 text-yellow-500" />
              <span className="hidden sm:inline">Plein écran</span>
            </a>
            <button
              onClick={onClose}
              className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
                isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
              }`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Clean, Readable Official Document Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 text-left space-y-5 leading-relaxed text-sm">
          {isTerms ? (
            /* =========================================================
               TERMS OF SERVICE - 14 OFFICIAL SECTIONS
               ========================================================= */
            <>
              {/* Introduction Banner */}
              <div className={`p-4 rounded-2xl border ${
                isLight ? 'bg-amber-50/80 border-amber-200 text-amber-950' : 'bg-yellow-400/10 border-yellow-400/25 text-yellow-200'
              }`}>
                <p className="font-semibold text-xs sm:text-sm">
                  Bienvenue sur SOMED, exploité par SOMED. En accédant à ou en utilisant notre application mobile et nos services associés (le « Service »), vous acceptez d'être lié par ces Conditions d'Utilisation (« Conditions »). Si vous n'acceptez pas ces Conditions, n'utilisez pas le Service.
                </p>
              </div>

              {/* Section 1 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">1</span>
                  <span>Acceptation des Conditions</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  En créant un compte, en accédant ou en utilisant le Service, vous confirmez que vous avez lu, compris et accepté ces Conditions, ainsi que notre Politique de Confidentialité. Si vous utilisez le Service au nom d'une organisation, vous déclarez avoir l'autorité d'engager cette organisation par ces Conditions.
                </p>
              </div>

              {/* Section 2 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">2</span>
                  <span>Description du Service</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  SOMED est une <strong>plateforme technologique</strong> qui met en relation des utilisateurs ayant besoin d'un transport (« Passagers ») avec des chauffeurs indépendants (« Chauffeurs »). SOMED <strong>n'est pas une entreprise de transport</strong>, n'emploie pas les Chauffeurs et ne fournit pas directement de services de transport. Le Service facilite la mise en relation entre Passagers et Chauffeurs via l'application mobile.
                </p>
              </div>

              {/* Section 3 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">3</span>
                  <span>Inscription et Compte</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Vous devez avoir au moins <strong>18 ans</strong> pour créer un compte et utiliser le Service. Vous êtes responsable du maintien de la confidentialité de vos identifiants d'accès. Toutes les informations fournies lors de l'inscription doivent être véridiques, exactes et à jour. Vous êtes responsable de toutes les activités effectuées depuis votre compte. SOMED se réserve le droit de suspendre ou de résilier les comptes qui violent ces Conditions.
                </p>
              </div>

              {/* Section 4 */}
              <div className="space-y-2">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">4</span>
                  <span>Utilisation du Service</span>
                </h4>
                <div className={`p-3.5 rounded-2xl border space-y-2 text-xs sm:text-sm ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
                }`}>
                  <div>
                    <h5 className="font-bold text-white mb-0.5">Tarifs et Paiements :</h5>
                    <p className={isLight ? 'text-slate-600' : 'text-neutral-400'}>
                      Les tarifs sont calculés en fonction de la distance, du temps et d'autres facteurs tels que la demande. Un tarif estimé vous sera présenté avant de confirmer votre demande de trajet. SOMED peut appliquer des frais supplémentaires pour les annulations tardives, les temps d'attente excessifs ou d'autres circonstances définies dans l'application. Les modes de paiement acceptés sont affichés dans l'application.
                    </p>
                  </div>
                  <div>
                    <h5 className="font-bold text-white mb-0.5">Annulations :</h5>
                    <p className={isLight ? 'text-slate-600' : 'text-neutral-400'}>
                      Vous pouvez annuler une demande de trajet avant que le Chauffeur n'arrive au point de prise en charge. Des frais d'annulation peuvent s'appliquer conformément aux politiques en vigueur affichées dans l'application.
                    </p>
                  </div>
                </div>
              </div>

              {/* Section 5 */}
              <div className="space-y-2">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">5</span>
                  <span>Conduite de l'Utilisateur</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>En utilisant le Service, vous vous engagez à :</p>
                <ul className="list-disc pl-5 space-y-1.5 text-xs sm:text-sm text-neutral-400">
                  <li>Ne pas utiliser le Service à des fins illégales ou non autorisées.</li>
                  <li>Traiter les Chauffeurs et les autres utilisateurs avec respect et courtoisie.</li>
                  <li>Ne pas perturber le fonctionnement normal du Service.</li>
                  <li>Ne pas usurper l'identité d'une autre personne.</li>
                  <li>Respecter toutes les lois et réglementations applicables.</li>
                </ul>
              </div>

              {/* Section 6 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">6</span>
                  <span>Prestataires Indépendants</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Les Chauffeurs sont des <strong>prestataires indépendants</strong> et non des employés, agents ou représentants de SOMED. SOMED ne contrôle ni ne dirige les méthodes ou moyens par lesquels les Chauffeurs fournissent leurs services de transport. Les Chauffeurs sont responsables de leurs propres véhicules, assurances, permis et du respect des lois sur la circulation routière applicables.
                </p>
              </div>

              {/* Section 7 */}
              <div className="space-y-2">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">7</span>
                  <span>Services de Géolocalisation</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>Le Service utilise la technologie <strong>GPS</strong> et d'autres services de localisation pour :</p>
                <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm text-neutral-400">
                  <li>Déterminer votre position et vous mettre en relation avec des Chauffeurs à proximité.</li>
                  <li>Suivre l'avancement de votre trajet en temps réel.</li>
                  <li>Calculer les tarifs basés sur la distance et le temps.</li>
                  <li>Améliorer la sécurité et la qualité du Service.</li>
                </ul>
                <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                  Certains Chauffeurs peuvent nécessiter l'utilisation de la localisation en <strong>arrière-plan</strong> pour rester disponibles pour les demandes de trajet. Vous pouvez gérer les autorisations de localisation dans les paramètres de votre appareil.
                </p>
              </div>

              {/* Section 8 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">8</span>
                  <span>Collecte et Utilisation des Données</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Nous collectons et utilisons les informations personnelles conformément à notre <strong>Politique de Confidentialité</strong>, qui fait partie intégrante de ces Conditions. Nous vous recommandons de consulter notre Politique de Confidentialité pour comprendre comment nous collectons, utilisons et protégeons vos informations.
                </p>
                <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                  Sur les appareils iOS, nous respectons le cadre d'<strong>App Tracking Transparency (ATT)</strong> d'Apple. Nous vous demanderons votre consentement avant de suivre votre activité à travers les applications et sites web d'autres entreprises.
                </p>
              </div>

              {/* Section 9 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">9</span>
                  <span>Propriété Intellectuelle</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Tous les droits de propriété intellectuelle sur le Service, y compris mais sans s'y limiter, l'application, les logos, les marques, les designs, le code source et le contenu, sont la propriété de SOMED ou de ses concédants de licence. Vous n'acquérez aucun droit de propriété sur le Service au-delà du droit d'utilisation limité conformément à ces Conditions.
                </p>
              </div>

              {/* Section 10 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">10</span>
                  <span>Limitation de Responsabilité</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Dans la mesure maximale permise par la loi : SOMED ne sera pas responsable des dommages indirects, accessoires, particuliers, consécutifs ou punitifs. SOMED ne garantit pas la disponibilité, la ponctualité ou la qualité des services de transport fournis par les Chauffeurs. La responsabilité totale de SOMED ne dépassera pas le montant payé par vous pour le Service au cours des 12 derniers mois.
                </p>
              </div>

              {/* Section 11 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">11</span>
                  <span>Indemnisation</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Vous acceptez d'indemniser et de dégager de toute responsabilité SOMED, ses dirigeants, employés et agents, contre toute réclamation, dommage, perte ou dépense (y compris les honoraires d'avocat) découlant de votre utilisation du Service ou de la violation de ces Conditions.
                </p>
              </div>

              {/* Section 12 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">12</span>
                  <span>Modifications des Conditions</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  SOMED se réserve le droit de modifier ces Conditions à tout moment. Les modifications seront notifiées via l'application ou par courrier électronique. L'utilisation continue du Service après la notification des modifications constitue l'acceptation des Conditions modifiées.
                </p>
              </div>

              {/* Section 13 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">13</span>
                  <span>Droit Applicable</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Ces Conditions seront régies et interprétées conformément aux lois en vigueur dans la juridiction où opère SOMED. Tout litige sera soumis aux tribunaux compétents de cette juridiction.
                </p>
              </div>

              {/* Section 14 */}
              <div className={`p-4 rounded-2xl border ${
                isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900 border-neutral-800'
              }`}>
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-yellow-500 mb-2">
                  <span className="w-6 h-6 rounded-lg bg-yellow-400/15 border border-yellow-400/30 text-yellow-500 text-xs flex items-center justify-center font-black">14</span>
                  <span>Contact</span>
                </h4>
                <p className={`text-xs sm:text-sm mb-2 ${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
                  Si vous avez des questions concernant ces Conditions d'Utilisation, vous pouvez nous contacter à :
                </p>
                <div className="space-y-1.5 text-xs sm:text-sm">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-yellow-500 flex-shrink-0" />
                    <span><strong>Courrier électronique :</strong> sumup.consultant01@gmail.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-yellow-500 flex-shrink-0" />
                    <span><strong>Via l'application :</strong> Section Aide et Support</span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            /* =========================================================
               PRIVACY POLICY - 15 OFFICIAL SECTIONS (RGPD)
               ========================================================= */
            <>
              {/* Introduction Banner */}
              <div className={`p-4 rounded-2xl border ${
                isLight ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950' : 'bg-emerald-950/20 border-emerald-800/40 text-emerald-300'
              }`}>
                <p className="font-semibold text-xs sm:text-sm">
                  SOMED (« nous », « notre » ou « l'Entreprise ») s'engage à protéger la vie privée des utilisateurs de SOMED (l'« Application »). Cette Politique de Confidentialité décrit comment nous collectons, utilisons, partageons et protégeons vos informations personnelles lorsque vous utilisez notre Service.
                </p>
              </div>

              {/* Section 1 */}
              <div className="space-y-2">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">1</span>
                  <span>Informations que nous collectons</span>
                </h4>
                <div className={`p-3.5 rounded-2xl border space-y-2 text-xs sm:text-sm ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
                }`}>
                  <div>
                    <h5 className="font-bold text-white mb-0.5">Informations d'Inscription :</h5>
                    <p className={isLight ? 'text-slate-600' : 'text-neutral-400'}>
                      Nom complet, adresse e-mail, numéro de téléphone, photo de profil (optionnelle), identifiants d'accès (Google Sign-In, Apple Sign-In ou autres méthodes).
                    </p>
                  </div>
                  <div>
                    <h5 className="font-bold text-white mb-0.5">Informations de Localisation (GPS) :</h5>
                    <p className={isLight ? 'text-slate-600' : 'text-neutral-400'}>
                      <strong>Passagers :</strong> Localisation lorsque l'application est en cours d'utilisation pour demander des trajets et suivre la progression.<br/>
                      <strong>Chauffeurs :</strong> Localisation au <strong>premier plan et en arrière-plan</strong> pour recevoir les demandes de trajet et permettre le suivi en temps réel.
                    </p>
                  </div>
                  <div>
                    <h5 className="font-bold text-white mb-0.5">Informations sur l'Appareil :</h5>
                    <p className={isLight ? 'text-slate-600' : 'text-neutral-400'}>
                      Modèle de l'appareil, système d'exploitation, version de l'application, identifiants uniques de l'appareil, adresse IP et fournisseur de réseau.
                    </p>
                  </div>
                  <div>
                    <h5 className="font-bold text-white mb-0.5">Informations d'Utilisation :</h5>
                    <p className={isLight ? 'text-slate-600' : 'text-neutral-400'}>
                      Historique des trajets (origine, destination, date, heure, tarif), interactions avec l'application, préférences, configurations, évaluations et commentaires.
                    </p>
                  </div>
                  <div>
                    <h5 className="font-bold text-white mb-0.5">Informations de Paiement :</h5>
                    <p className={isLight ? 'text-slate-600' : 'text-neutral-400'}>
                      Mode de paiement sélectionné (espèces, carte bancaire, portefeuille numérique). Les données de carte bancaire sont traitées directement par nos prestataires de paiement certifiés (PCI-DSS). SOMED <strong>ne stocke pas</strong> les numéros complets de carte bancaire.
                    </p>
                  </div>
                </div>
              </div>

              {/* Section 2 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">2</span>
                  <span>Utilisation des Informations</span>
                </h4>
                <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm text-neutral-400">
                  <li>Fournir, maintenir et améliorer le Service.</li>
                  <li>Mettre en relation les Passagers avec les Chauffeurs à proximité.</li>
                  <li>Traiter les paiements et les transactions.</li>
                  <li>Envoyer des notifications sur les trajets, promotions et mises à jour du Service.</li>
                  <li>Garantir la sécurité des utilisateurs et prévenir les fraudes.</li>
                  <li>Respecter les obligations légales et réglementaires.</li>
                  <li>Générer des analyses et des statistiques agrégées (anonymisées).</li>
                  <li>Résoudre les litiges et fournir un support client.</li>
                </ul>
              </div>

              {/* Section 3 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">3</span>
                  <span>Suivi et Publicité — App Tracking Transparency (ATT)</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  <strong>iOS (App Tracking Transparency - ATT) :</strong> Sur les appareils iOS, nous respectons le cadre d'<strong>App Tracking Transparency (ATT)</strong> d'Apple : nous vous demanderons votre <strong>consentement explicite</strong> avant d'accéder à l'Identifiant Publicitaire (IDFA) de votre appareil. Vous avez le droit de <strong>refuser</strong> le suivi sans que cela n'affecte la fonctionnalité principale de l'Application.
                </p>
                <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                  <strong>Publicité :</strong> Nous pouvons afficher des annonces dans l'Application. Si vous donnez votre consentement, nous pouvons personnaliser les annonces en fonction de vos intérêts. Vous pouvez modifier vos préférences à tout moment dans les réglages de votre appareil iOS (<code>Réglages &gt; Confidentialité et sécurité &gt; Suivi</code>).
                </p>
              </div>

              {/* Section 4 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">4</span>
                  <span>Services de Géolocalisation</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  <strong>Passagers :</strong> Nous collectons votre position pendant que vous utilisez l'application pour vous mettre en relation avec des Chauffeurs et suivre vos trajets.
                </p>
                <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                  <strong>Chauffeurs :</strong> Nous collectons la localisation en <strong>arrière-plan</strong> pour leur permettre de recevoir des demandes de trajet même lorsque l'application n'est pas activement affichée. Les Chauffeurs peuvent désactiver la localisation en arrière-plan en se déconnectant.
                </p>
              </div>

              {/* Section 5 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">5</span>
                  <span>Partage des Données</span>
                </h4>
                <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm text-neutral-400">
                  <li><strong>Entre Passagers et Chauffeurs :</strong> Nom, photo, position de prise en charge/destination, note, détails du véhicule.</li>
                  <li><strong>Prestataires de Services :</strong> Processeurs de paiement, services de cartographie, fournisseurs de notifications.</li>
                  <li><strong>Autorités :</strong> Lorsque la loi ou une ordonnance judiciaire l'exige.</li>
                </ul>
              </div>

              {/* Section 6 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">6</span>
                  <span>SDKs de Tiers</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  L'Application intègre les services tiers suivants : <strong>Google Maps / Apple Maps</strong> (cartographie), <strong>Firebase - Google</strong> (notifications push, analyses, authentification), et des <strong>Processeurs de Paiement certifiés PCI-DSS</strong>.
                </p>
              </div>

              {/* Section 7 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">7</span>
                  <span>Sécurité des Données</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Nous mettons en œuvre un chiffrement en transit (HTTPS/TLS), un chiffrement au repos pour les données sensibles, ainsi qu'un contrôle d'accès basé sur les rôles.
                </p>
              </div>

              {/* Section 8 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">8</span>
                  <span>Rétention et Suppression des Données</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Vos données sont conservées tant que votre compte est actif. L'historique des trajets est conservé conformément aux obligations fiscales et commerciales applicables.
                </p>
              </div>

              {/* Section 9 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">9</span>
                  <span>Droits de l'Utilisateur — RGPD</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Conformément au RGPD européen, vous disposez des droits d'<strong>accès</strong>, de <strong>rectification</strong>, de <strong>suppression</strong>, d'<strong>opposition</strong> et de <strong>portabilité</strong>. Pour exercer ces droits, contactez : <code>sumup.consultant01@gmail.com</code>.
                </p>
              </div>

              {/* Section 10 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">10</span>
                  <span>Suppression de Compte</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Vous pouvez demander la suppression de votre compte via l'application (<code>Profil &gt; Paramètres &gt; Supprimer le compte</code>) ou par courrier électronique.
                </p>
              </div>

              {/* Section 11 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">11</span>
                  <span>Cookies</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Sur nos services web, nous pouvons utiliser des cookies essentiels et analytiques. Vous pouvez les gérer depuis votre navigateur.
                </p>
              </div>

              {/* Section 12 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">12</span>
                  <span>Transferts Internationaux</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Vos informations peuvent être traitées sur des serveurs situés hors de votre pays avec les garanties de protection appropriées.
                </p>
              </div>

              {/* Section 13 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">13</span>
                  <span>Mineurs</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Le Service n'est pas destiné aux mineurs de moins de 18 ans.
                </p>
              </div>

              {/* Section 14 */}
              <div className="space-y-1.5">
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">14</span>
                  <span>Modifications de cette Politique</span>
                </h4>
                <p className={isLight ? 'text-slate-700' : 'text-neutral-300'}>
                  Les modifications seront notifiées via l'Application ou par e-mail.
                </p>
              </div>

              {/* Section 15 */}
              <div className={`p-4 rounded-2xl border ${
                isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900 border-neutral-800'
              }`}>
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2 text-emerald-500 mb-2">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 text-xs flex items-center justify-center font-black">15</span>
                  <span>Contact</span>
                </h4>
                <p className={`text-xs sm:text-sm mb-2 ${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
                  Pour toute question relative à cette politique ou pour exercer vos droits RGPD :
                </p>
                <div className="space-y-1.5 text-xs sm:text-sm">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                    <span><strong>Courrier électronique :</strong> sumup.consultant01@gmail.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                    <span><strong>Responsable du traitement :</strong> SOMED</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className={`p-4 border-t flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-neutral-900/60'
        }`}>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            <span className="text-[11px] text-neutral-500">Document légal officiel SOMED · 2026</span>
          </div>
          <button
            onClick={onClose}
            className="py-2.5 px-6 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs shadow-md active:scale-95 transition"
          >
            Fermer la lecture
          </button>
        </div>
      </div>
    </div>
  );
};
