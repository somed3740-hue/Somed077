import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Wallet, 
  DollarSign, 
  TrendingUp, 
  Building2, 
  ArrowUpRight, 
  Check, 
  CheckCircle2, 
  Clock, 
  CreditCard, 
  Calendar, 
  ChevronRight, 
  Edit2, 
  AlertCircle
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';
import { DriverBankInfo } from '../../types/vtc';

interface DriverEarningsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DriverEarningsModal: React.FC<DriverEarningsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const driver = vtcStore.getCurrentDriver();

  const [isCashoutOpen, setIsCashoutOpen] = useState(false);
  const [cashoutAmount, setCashoutAmount] = useState<string>(
    driver.driverWalletBalance > 0 ? driver.driverWalletBalance.toFixed(2) : '0.00'
  );
  const [cashoutNotice, setCashoutNotice] = useState<string | null>(null);

  // RIB Editing State
  const [isEditRibOpen, setIsEditRibOpen] = useState(false);
  const [accountHolder, setAccountHolder] = useState(driver.bankInfo?.accountHolder || 'SOMED DINE');
  const [iban, setIban] = useState(driver.bankInfo?.iban || 'FR76 3000 4000 1234 5678 9014 3');
  const [bic, setBic] = useState(driver.bankInfo?.bic || 'BNPAFRPP');
  const [bankName, setBankName] = useState(driver.bankInfo?.bankName || 'BNP Paribas Private Banking');

  const handleCashoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(cashoutAmount);
    if (isNaN(amount) || amount <= 0) {
      setCashoutNotice('Veuillez renseigner un montant valide.');
      return;
    }

    const res = vtcStore.cashoutDriverWallet(driver.id, amount);
    if (res.success) {
      setCashoutNotice(res.message);
      setTimeout(() => {
        setIsCashoutOpen(false);
        setCashoutNotice(null);
      }, 1500);
    } else {
      setCashoutNotice(res.message);
    }
  };

  const handleSaveRib = (e: React.FormEvent) => {
    e.preventDefault();
    const newBankInfo: DriverBankInfo = {
      accountHolder,
      iban,
      bic,
      bankName,
    };
    vtcStore.updateDriverBankInfo(driver.id, newBankInfo);
    setIsEditRibOpen(false);
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col select-none animate-in fade-in duration-200">
      <div 
        className={`h-full w-full flex flex-col overflow-y-auto transition-colors ${
          isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
        }`}
      >
        {/* Top Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">Gains, Portefeuille & Reversements</h2>
          <div className="w-9" />
        </header>

        {/* Content */}
        <div className="flex-1 max-w-lg mx-auto w-full p-5 space-y-5">
          {/* Main Wallet Balance Card */}
          <div className={`p-6 rounded-3xl border shadow-xl relative overflow-hidden ${
            isLight 
              ? 'bg-gradient-to-br from-slate-900 to-slate-800 text-white border-slate-700' 
              : 'bg-gradient-to-br from-neutral-900 via-neutral-900 to-neutral-950 border-neutral-800 text-white'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs uppercase font-bold tracking-wider text-yellow-400 flex items-center gap-1.5">
                <Wallet className="w-4 h-4" />
                Solde disponible Chauffeur
              </span>
              <span className="text-[10px] font-bold bg-white/10 px-2 py-0.5 rounded-full border border-white/20">
                Paiement Instantané
              </span>
            </div>

            <div className="my-3">
              <p className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                {formatEuro(driver.driverWalletBalance || 0)}
              </p>
              <p className="text-xs text-neutral-400 mt-1">Disponible pour virement bancaire sous 10 secondes</p>
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center gap-2">
              <button
                onClick={() => {
                  setCashoutAmount((driver.driverWalletBalance || 0).toFixed(2));
                  setIsCashoutOpen(true);
                }}
                disabled={(driver.driverWalletBalance || 0) <= 0}
                className={`flex-1 py-3 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition active:scale-95 ${
                  (driver.driverWalletBalance || 0) > 0
                    ? 'bg-yellow-400 hover:bg-yellow-300 text-black shadow-yellow-400/20'
                    : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                }`}
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>Demander un virement immédiat</span>
              </button>
            </div>
          </div>

          {/* Earnings Overview Cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className={`p-4 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className={`font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>Aujourd'hui</span>
                <Clock className="w-3.5 h-3.5 text-emerald-500" />
              </div>
              <p className="text-xl font-bold text-emerald-500">{formatEuro(driver.todayEarnings)}</p>
              <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>Net généré</p>
            </div>

            <div className={`p-4 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className={`font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>Cette semaine</span>
                <TrendingUp className="w-3.5 h-3.5 text-yellow-500" />
              </div>
              <p className="text-xl font-bold text-yellow-500">{formatEuro(driver.weeklyEarnings)}</p>
              <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>7 derniers jours</p>
            </div>
          </div>

          {/* Bank Account / RIB Details (Mode de reversement) */}
          <div className={`p-5 rounded-3xl border space-y-3.5 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Building2 className="w-4 h-4 text-yellow-500" />
                <span>Mode de reversement (RIB Bancaire)</span>
              </h3>
              <button
                onClick={() => setIsEditRibOpen(true)}
                className={`text-xs font-bold flex items-center gap-1 transition ${
                  isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Edit2 className="w-3 h-3" />
                <span>Modifier</span>
              </button>
            </div>

            <div className={`p-4 rounded-2xl border space-y-2.5 ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
            }`}>
              <div className="flex justify-between items-center text-xs">
                <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Titulaire :</span>
                <span className="font-bold">{driver.bankInfo?.accountHolder || 'SOMED DINE'}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Banque :</span>
                <span className="font-medium">{driver.bankInfo?.bankName || 'BNP Paribas Private Banking'}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>IBAN :</span>
                <span className="font-mono font-bold">{driver.bankInfo?.iban || 'FR76 3000 4000 1234 5678 9014 3'}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>BIC / SWIFT :</span>
                <span className="font-mono font-medium">{driver.bankInfo?.bic || 'BNPAFRPP'}</span>
              </div>
            </div>
          </div>

          {/* Transaction History matching screenshots */}
          <div className={`p-5 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <h3 className="font-bold text-sm flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-500" />
              <span>Historique des opérations & commissions</span>
            </h3>

            <div className="divide-y divide-slate-100 dark:divide-neutral-900">
              {driver.driverTransactions && driver.driverTransactions.length > 0 ? (
                driver.driverTransactions.map((tx) => {
                  const isPositive = tx.amount > 0;
                  return (
                    <div key={tx.id} className="py-3 flex items-start justify-between gap-3">
                      <div>
                        <p className="font-bold text-xs">{tx.title}</p>
                        <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                          {tx.description}
                        </p>
                        <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                          {tx.date} à {tx.time}
                        </p>
                      </div>

                      <div className="text-right flex-shrink-0">
                        <span className={`font-bold text-xs ${
                          isPositive ? 'text-emerald-500' : 'text-slate-700 dark:text-neutral-300'
                        }`}>
                          {isPositive ? `+${tx.amount.toFixed(2)} €` : `${tx.amount.toFixed(2)} €`}
                        </span>
                        <p className="text-[10px] text-emerald-500 font-medium">Effectué</p>
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className={`text-xs py-4 text-center ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                  Aucune transaction récente.
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Cashout Modal */}
        {isCashoutOpen && (
          <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
            <div className={`w-full max-w-sm rounded-3xl p-6 border shadow-2xl space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
            }`}>
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base flex items-center gap-2">
                  <ArrowUpRight className="w-5 h-5 text-yellow-500" />
                  <span>Virement bancaire immédiat</span>
                </h3>
                <button 
                  onClick={() => setIsCashoutOpen(false)}
                  className="text-xs font-bold text-neutral-400 hover:text-white"
                >
                  Fermer
                </button>
              </div>

              <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                Transférez vos gains en temps réel vers votre compte bancaire ({driver.bankInfo?.bankName || 'RIB'}).
              </p>

              <form onSubmit={handleCashoutSubmit} className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-xs font-semibold">Montant à virer (€)</label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="1"
                      max={driver.driverWalletBalance || 0}
                      value={cashoutAmount}
                      onChange={(e) => setCashoutAmount(e.target.value)}
                      className={`w-full px-4 py-2.5 rounded-xl border text-lg font-bold ${
                        isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setCashoutAmount((driver.driverWalletBalance || 0).toFixed(2))}
                      className="absolute right-2.5 top-2.5 px-2 py-1 bg-yellow-400 text-black text-[10px] font-bold rounded-lg"
                    >
                      MAX
                    </button>
                  </div>
                </div>

                {cashoutNotice && (
                  <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-medium">
                    {cashoutNotice}
                  </div>
                )}

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsCashoutOpen(false)}
                    className={`flex-1 py-3 rounded-xl text-xs font-bold border ${
                      isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-900 border-neutral-800'
                    }`}
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-yellow-400 hover:bg-yellow-300 text-black rounded-xl text-xs font-bold shadow-lg"
                  >
                    Confirmer le virement
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit RIB Modal */}
        {isEditRibOpen && (
          <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
            <div className={`w-full max-w-sm rounded-3xl p-6 border shadow-2xl space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
            }`}>
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-yellow-500" />
                  <span>Coordonnées bancaires (RIB)</span>
                </h3>
                <button 
                  onClick={() => setIsEditRibOpen(false)}
                  className="text-xs font-bold text-neutral-400 hover:text-white"
                >
                  Fermer
                </button>
              </div>

              <form onSubmit={handleSaveRib} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold">Titulaire du compte</label>
                  <input
                    type="text"
                    required
                    value={accountHolder}
                    onChange={(e) => setAccountHolder(e.target.value)}
                    className={`w-full px-3.5 py-2 rounded-xl border text-xs font-medium ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold">Nom de la banque</label>
                  <input
                    type="text"
                    required
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    className={`w-full px-3.5 py-2 rounded-xl border text-xs font-medium ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold">IBAN</label>
                  <input
                    type="text"
                    required
                    value={iban}
                    onChange={(e) => setIban(e.target.value.toUpperCase())}
                    className={`w-full px-3.5 py-2 rounded-xl border text-xs font-mono font-medium ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold">BIC / SWIFT</label>
                  <input
                    type="text"
                    required
                    value={bic}
                    onChange={(e) => setBic(e.target.value.toUpperCase())}
                    className={`w-full px-3.5 py-2 rounded-xl border text-xs font-mono font-medium ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditRibOpen(false)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold border ${
                      isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-900 border-neutral-800'
                    }`}
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black rounded-xl text-xs font-bold shadow-lg"
                  >
                    Enregistrer
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
