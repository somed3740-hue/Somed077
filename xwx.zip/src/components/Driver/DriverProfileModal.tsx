import React from 'react';
import { 
  ArrowLeft, 
  Settings, 
  User, 
  Car, 
  Star, 
  ShieldCheck, 
  CheckCircle2, 
  Edit3, 
  Wallet, 
  Clock, 
  ChevronRight, 
  Power, 
  Repeat,
  Globe,
  Check
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';
import { useTranslation, SUPPORTED_LANGUAGES, Language } from '../../utils/i18n';
import { soundEffects } from '../../utils/audio';

interface DriverProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenEditProfile: () => void;
  onOpenEarnings: () => void;
  onOpenActivity: () => void;
  onOpenSettings: () => void;
  onSwitchMode?: () => void;
}

export const DriverProfileModal: React.FC<DriverProfileModalProps> = ({
  isOpen,
  onClose,
  onOpenEditProfile,
  onOpenEarnings,
  onOpenActivity,
  onOpenSettings,
  onSwitchMode,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const driver = vtcStore.getCurrentDriver();
  const { lang, t, setLanguage } = useTranslation();

  const handleSelectLanguage = (code: Language) => {
    soundEffects.playClick();
    setLanguage(code);

    const labels: Record<Language, string> = {
      fr: 'Français activé pour toute l’application',
      en: 'English activated across all interfaces',
      es: 'Español activado en todas las interfaces',
    };

    vtcStore.sendPushNotification({
      title: t('language'),
      body: labels[code],
      category: 'SYSTEM',
      badge: code.toUpperCase(),
    });
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col select-none animate-in fade-in duration-200">
      <div 
        className={`h-full w-full flex flex-col overflow-y-auto transition-colors ${
          isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
        }`}
      >
        {/* Top Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">{t('driverProfile')}</h2>
          <button
            onClick={onOpenSettings}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <Settings className="w-5 h-5" />
          </button>
        </header>

        {/* Profile Details Container */}
        <div className="flex-1 max-w-lg mx-auto w-full p-5 space-y-5">
          {/* Driver Hero Card */}
          <div className={`p-6 rounded-3xl border flex flex-col items-center text-center shadow-xl relative overflow-hidden ${
            isLight ? 'bg-white border-slate-200 shadow-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div className="relative mb-3">
              <div className="w-24 h-24 rounded-full border-2 border-yellow-400 p-0.5 overflow-hidden flex items-center justify-center shadow-lg bg-neutral-900">
                <img
                  src={driver.avatarUrl}
                  alt={driver.name}
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <span className={`absolute bottom-0 right-0 w-6 h-6 rounded-full border-2 ${
                isLight ? 'border-white' : 'border-black'
              } flex items-center justify-center ${
                driver.isOnline ? 'bg-emerald-500 text-white' : 'bg-slate-500 text-slate-200'
              }`}>
                <Power className="w-3.5 h-3.5" />
              </span>
            </div>

            <div className="flex items-center gap-2">
              <h1 className="font-black text-xl tracking-tight">{driver.name}</h1>
              <span className="text-[10px] font-bold bg-yellow-400 text-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                VTC Pro
              </span>
            </div>

            <p className={`text-xs mt-0.5 font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              {driver.phone} · {driver.email}
            </p>

            {/* 3 Driver Performance Stats */}
            <div className={`grid grid-cols-3 gap-2 w-full mt-5 p-3 rounded-2xl border text-center ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900 border-neutral-800'
            }`}>
              <div>
                <p className="text-base font-bold text-yellow-500 flex items-center justify-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400" />
                  <span>{driver.rating.toFixed(2)}</span>
                </p>
                <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('driverRating')}</p>
              </div>

              <div className={`border-x ${isLight ? 'border-slate-300' : 'border-neutral-800'}`}>
                <p className="text-base font-bold text-emerald-500">{driver.acceptanceRate}%</p>
                <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('driverAcceptanceRate')}</p>
              </div>

              <div>
                <p className="text-base font-bold">{driver.totalRides}</p>
                <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('tabTaxi')}</p>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="w-full mt-4 space-y-2">
              <button
                onClick={() => {
                  onClose();
                  onSwitchMode?.();
                }}
                className="w-full py-3 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-yellow-400/20"
              >
                <Repeat className="w-4 h-4 stroke-[2.5]" />
                <span>{t('switchInterface')}</span>
              </button>

              <button
                onClick={onOpenEditProfile}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-2 active:scale-95 ${
                  isLight 
                    ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800' 
                    : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-700 text-white'
                }`}
              >
                <Edit3 className="w-4 h-4 text-yellow-500" />
                <span>{t('editProfile')}</span>
              </button>
            </div>
          </div>

          {/* ================= SECTION LANGUE DE L'APPLICATION (Français, Anglais, Espagnol) ================= */}
          <div className={`p-5 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">{t('language')}</h3>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    {t('languageSubtitle')}
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-yellow-400 text-black uppercase">
                {lang}
              </span>
            </div>

            {/* 3 Selectable Buttons: Français, English, Español */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              {SUPPORTED_LANGUAGES.map((item) => {
                const isSelected = lang === item.code;
                return (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => handleSelectLanguage(item.code)}
                    className={`p-3 rounded-2xl border flex flex-col items-center justify-center gap-1 transition active:scale-95 ${
                      isSelected
                        ? 'bg-yellow-400 border-yellow-400 text-black font-extrabold shadow-md shadow-yellow-400/20 ring-2 ring-yellow-400/30'
                        : isLight 
                        ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300' 
                        : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-900/80 hover:text-white'
                    }`}
                  >
                    <span className="text-xl">{item.flag}</span>
                    <span className="text-xs font-bold">{item.name}</span>
                    {isSelected && (
                      <span className="text-[9px] bg-black text-yellow-400 px-1.5 py-0.2 rounded-full font-black flex items-center gap-0.5">
                        <Check className="w-2.5 h-2.5" /> {t('active')}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Vehicle Information Card */}
          <div className={`p-5 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Car className="w-4 h-4 text-yellow-500" />
                <span>{t('driverRegisteredVehicle')}</span>
              </h3>
              <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-500 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                {t('driverApproved')}
              </span>
            </div>

            <div className={`p-3.5 rounded-2xl border flex items-center justify-between ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
            }`}>
              <div>
                <p className="font-bold text-sm">
                  {driver.vehicle.brand} {driver.vehicle.model}
                </p>
                <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {driver.vehicle.color} · {driver.vehicle.year || 2019}
                </p>
              </div>

              <div className="text-right">
                <span className="font-mono font-black text-sm bg-yellow-400 text-black px-2.5 py-1 rounded-lg border border-black/20 shadow-sm">
                  {driver.vehicle.plate}
                </span>
                <p className={`text-[10px] font-bold uppercase mt-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {driver.vehicle.category}
                </p>
              </div>
            </div>

            {/* Service types chips */}
            {driver.serviceTypes && driver.serviceTypes.length > 0 && (
              <div className="pt-2">
                <p className={`text-[11px] font-semibold mb-2 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Services :
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {driver.serviceTypes.map((type) => (
                    <span 
                      key={type}
                      className={`text-[11px] px-2.5 py-1 rounded-lg font-medium border ${
                        isLight 
                          ? 'bg-slate-100 border-slate-300 text-slate-700' 
                          : 'bg-neutral-900 border-neutral-800 text-neutral-300'
                      }`}
                    >
                      ✓ {type}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Quick Access Menu Cards */}
          <div className={`rounded-3xl border divide-y overflow-hidden ${
            isLight 
              ? 'bg-white border-slate-200 divide-slate-100' 
              : 'bg-neutral-950 border-neutral-800 divide-neutral-900'
          }`}>
            {/* Earnings & Wallet */}
            <button
              onClick={onOpenEarnings}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-500 flex items-center justify-center">
                  <Wallet className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-sm">{t('driverEarnings')}</p>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Solde : <strong className="text-emerald-500 font-bold">{formatEuro(driver.driverWalletBalance || 0)}</strong>
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            {/* Trip Activity */}
            <button
              onClick={onOpenActivity}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-500 flex items-center justify-center">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-sm">{t('driverActivity')}</p>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    {t('drawerActivity')}
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            {/* Switch mode */}
            <button
              onClick={() => {
                onClose();
                onSwitchMode?.();
              }}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Repeat className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-sm">{t('switchInterface')}</p>
                    <span className="text-[10px] font-bold bg-yellow-400 text-black px-1.5 py-0.2 rounded uppercase">
                      {t('active')}
                    </span>
                  </div>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Passager, Chauffeur, Business
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 group-hover:translate-x-0.5 transition-transform ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>
          </div>

          {/* VTC Legal Documents Status */}
          <div className={`p-5 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <h3 className="font-bold text-sm flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>{t('driverCompliance')}</span>
            </h3>

            <div className="space-y-2">
              {[
                { title: 'Carte Professionnelle VTC', date: '2030', status: 'OK' },
                { title: 'Assurance Circulation VTC', date: 'Allianz Pro', status: 'OK' },
                { title: 'Extrait REVTC', date: 'Préfecture', status: 'OK' },
                { title: 'Contrôle Technique', date: '< 1 an', status: 'OK' },
                { title: 'Permis B', date: '12 pts', status: 'OK' },
              ].map((doc) => (
                <div 
                  key={doc.title}
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                    isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/40 border-neutral-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                    <div>
                      <p className="font-semibold">{doc.title}</p>
                      <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{doc.date}</p>
                    </div>
                  </div>
                  <span className="font-bold text-emerald-500 text-[11px] bg-emerald-500/10 px-2 py-0.5 rounded">
                    {doc.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
