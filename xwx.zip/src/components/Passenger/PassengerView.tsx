import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Navigation, 
  CreditCard, 
  Shield, 
  Phone, 
  MessageSquare, 
  Clock, 
  Car, 
  Sparkles, 
  ChevronRight,
  AlertTriangle,
  History,
  X,
  Plus,
  Calendar,
  Share2,
  Download,
  Search,
  Loader2,
  Trash2,
  PanelLeftClose,
  PanelLeftOpen,
  Maximize2,
  Minimize2,
  Eye,
  EyeOff,
  Check,
  Copy
} from 'lucide-react';
import { LocationPoint, PaymentMethod, RideCategory, Ride } from '../../types/vtc';
import { 
  CATEGORIES_CONFIG, 
  PRESET_LOCATIONS, 
  calculateDistanceKm, 
  calculateFare, 
  estimateDurationMinutes, 
  formatEuro, 
  searchRealAddresses 
} from '../../utils/geo';
import { vtcStore } from '../../services/vtcStore';
import { soundEffects } from '../../utils/audio';
import { VtcMap } from '../Map/VtcMap';
import { ChatModal } from '../Modals/ChatModal';
import { CallModal } from '../Modals/CallModal';
import { ReceiptModal } from '../Modals/ReceiptModal';
import { RideDetailModal } from '../Modals/RideDetailModal';
import { ShareSafetyModal } from '../Modals/ShareSafetyModal';
import { generateInvoicePDF } from '../../utils/invoice';
import { useTranslation } from '../../utils/i18n';

export const PassengerView: React.FC = () => {
  const { lang, t } = useTranslation();
  const passenger = vtcStore.getPassenger();
  const allDrivers = vtcStore.getAllDrivers();
  const activeRide = vtcStore.getActiveRideForPassenger();
  const allRides = vtcStore.getAllRides().filter((r) => r.passengerId === passenger.id);
  const scheduledRides = vtcStore.getScheduledRides().filter((r) => r.passengerId === passenger.id);
  const surgeMultiplier = vtcStore.getSurgeMultiplier();

  // Booking state
  const [pickup, setPickup] = useState<LocationPoint>(PRESET_LOCATIONS[0]); // Tour Eiffel
  const [destination, setDestination] = useState<LocationPoint>(PRESET_LOCATIONS[1]); // Champs-Élysées
  const [intermediateStops, setIntermediateStops] = useState<LocationPoint[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<RideCategory>('CONFORT');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CARD');
  const [showHistory, setShowHistory] = useState(false);
  const [showScheduledTab, setShowScheduledTab] = useState(false);
  const [isPanelCollapsed, setIsPanelCollapsed] = useState(false);

  // Scheduling state
  const [isScheduling, setIsScheduling] = useState(false);
  const [scheduledDateTime, setScheduledDateTime] = useState(() => {
    const d = new Date(Date.now() + 3600 * 1000 * 2); // 2 hours in future
    return d.toISOString().slice(0, 16);
  });

  // Search Modal state
  const [showSearchModal, setShowSearchModal] = useState<'PICKUP' | 'DESTINATION' | 'STOP' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LocationPoint[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Modals state
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isCallOpen, setIsCallOpen] = useState(false);
  const [isSafetyOpen, setIsSafetyOpen] = useState(false);
  const [showReceiptForRide, setShowReceiptForRide] = useState<Ride | null>(null);
  const [selectedDetailRide, setSelectedDetailRide] = useState<Ride | null>(null);
  const [codeShared, setCodeShared] = useState(false);

  const handleShareCode = (rideId: string) => {
    vtcStore.shareVerificationCodeWithDriver(rideId);
    setCodeShared(true);
    soundEffects.playSuccessSound();
    setTimeout(() => setCodeShared(false), 5000);
  };

  const handleCopyCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      soundEffects.playClick();
      setCodeShared(true);
      setTimeout(() => setCodeShared(false), 3000);
    } catch {}
  };

  // Debounced real address searching
  useEffect(() => {
    if (!searchQuery || searchQuery.trim().length < 2) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const timer = setTimeout(async () => {
      const results = await searchRealAddresses(searchQuery);
      setSearchResults(results);
      setIsSearching(false);
    }, 350);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const distanceKm = calculateDistanceKm(pickup.lat, pickup.lng, destination.lat, destination.lng);
  const durationMin = estimateDurationMinutes(distanceKm, intermediateStops.length);

  const handleBookRide = () => {
    const scheduledTimestamp = isScheduling ? new Date(scheduledDateTime).getTime() : undefined;
    vtcStore.requestRide({
      pickup,
      destination,
      stops: intermediateStops,
      category: selectedCategory,
      paymentMethod,
      scheduledFor: scheduledTimestamp,
    });
    if (isScheduling) {
      setShowScheduledTab(true);
    }
  };

  const handleCancelActiveRide = () => {
    if (activeRide) {
      vtcStore.cancelRide(activeRide.id);
    }
  };

  const handleAddStop = (loc: LocationPoint) => {
    if (intermediateStops.length < 2) {
      setIntermediateStops([...intermediateStops, loc]);
    }
  };

  const handleRemoveStop = (idx: number) => {
    setIntermediateStops(intermediateStops.filter((_, i) => i !== idx));
  };

  return (
    <div className="relative h-full w-full flex flex-col md:flex-row overflow-hidden bg-slate-950 text-slate-100">
      {/* Contact & Safety Modals */}
      {isChatOpen && activeRide && (
        <ChatModal
          isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)}
          otherPartyName={activeRide.driverName || 'Votre Chauffeur'}
          otherPartyRole="Chauffeur VTC"
          isDriverView={false}
        />
      )}

      {isCallOpen && activeRide && (
        <CallModal
          isOpen={isCallOpen}
          onClose={() => setIsCallOpen(false)}
          callerName={activeRide.driverName || 'Votre Chauffeur'}
          callerRole="Chauffeur VTC Partenaire"
        />
      )}

      {isSafetyOpen && activeRide && (
        <ShareSafetyModal
          isOpen={isSafetyOpen}
          onClose={() => setIsSafetyOpen(false)}
          ride={activeRide}
        />
      )}

      {showReceiptForRide && (
        <ReceiptModal
          ride={showReceiptForRide}
          onClose={() => setShowReceiptForRide(null)}
        />
      )}

      {/* LEFT PANEL / MOBILE BOTTOM SHEET: Controls & Status */}
      <div className={`w-full md:w-[440px] flex-shrink-0 z-20 flex flex-col h-[52%] md:h-full bg-slate-900/95 backdrop-blur-xl border-t md:border-t-0 md:border-r border-slate-800 shadow-2xl order-2 md:order-1 overflow-y-auto transition-all duration-300 ${
        isPanelCollapsed ? 'hidden' : 'flex'
      }`}>
        {/* Top Header */}
        <div className="p-3.5 border-b border-slate-800 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center font-bold text-xs flex-shrink-0">
              {passenger.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-white leading-tight truncate">{passenger.name}</p>
              <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                <span className="text-amber-400 font-semibold">⭐ {passenger.rating.toFixed(2)}</span>
                <span aria-hidden="true">·</span>
                <span className="truncate">Particulier</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 flex-shrink-0">
            <button
              onClick={() => {
                setShowScheduledTab(!showScheduledTab);
                setShowHistory(false);
              }}
              className={`flex items-center gap-1 px-2 py-1.5 text-xs rounded-xl border transition ${
                showScheduledTab
                  ? 'bg-blue-600 border-blue-500 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700/60'
              }`}
              title="Réservations planifiées"
            >
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">Planning</span> ({scheduledRides.length})
            </button>

            <button
              onClick={() => {
                setShowHistory(!showHistory);
                setShowScheduledTab(false);
              }}
              className={`flex items-center gap-1 px-2 py-1.5 text-xs rounded-xl border transition ${
                showHistory
                  ? 'bg-blue-600 border-blue-500 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700/60'
              }`}
              title="Historique des courses"
            >
              <History className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Historique</span>
            </button>

            {/* Collapse Side Panel Button (Map full screen) */}
            <button
              onClick={() => setIsPanelCollapsed(true)}
              title="Masquer le panneau pour voir la carte en entier"
              className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs border border-slate-700/70 transition shadow-sm"
            >
              <PanelLeftClose className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-medium text-[11px]">Masquer</span>
            </button>
          </div>
        </div>

        {/* Dynamic Content based on tabs or ride status */}
        {showScheduledTab ? (
          /* Scheduled Rides Tab */
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-semibold text-sm text-white">Réservations Planifiées</h3>
              <button
                onClick={() => setShowScheduledTab(false)}
                className="text-xs text-blue-400 hover:underline"
              >
                Fermer
              </button>
            </div>

            {scheduledRides.length === 0 ? (
              <div className="text-center py-10 text-slate-500 text-xs">
                Aucune course planifiée à l'avance.
              </div>
            ) : (
              scheduledRides.map((sr) => (
                <div
                  key={sr.id}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-xs space-y-2.5"
                >
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-blue-400 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      {sr.scheduledFor
                        ? new Date(sr.scheduledFor).toLocaleString('fr-FR', {
                            dateStyle: 'medium',
                            timeStyle: 'short',
                          })
                        : 'Planifié'}
                    </span>
                    <span className="font-bold text-emerald-400">{formatEuro(sr.fare)}</span>
                  </div>

                  <p className="text-slate-400 truncate">
                    <strong className="text-emerald-500">De:</strong> {sr.pickup.name || sr.pickup.address}
                  </p>
                  <p className="text-slate-400 truncate">
                    <strong className="text-rose-500">Vers:</strong> {sr.destination.name || sr.destination.address}
                  </p>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                    <button
                      onClick={() => vtcStore.activateScheduledRide(sr.id)}
                      className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-[11px] font-semibold transition"
                    >
                      Déclencher maintenant
                    </button>
                    <button
                      onClick={() => vtcStore.cancelRide(sr.id)}
                      className="text-rose-400 hover:underline text-[11px]"
                    >
                      Annuler
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : showHistory ? (
          /* History View */
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-semibold text-sm text-white">Vos courses passées</h3>
              <button
                onClick={() => setShowHistory(false)}
                className="text-xs text-blue-400 hover:underline"
              >
                Retour
              </button>
            </div>
            {allRides.length === 0 ? (
              <div className="text-center py-10 text-slate-500 text-xs">
                Aucune course enregistrée pour le moment.
              </div>
            ) : (
              allRides.map((ride) => (
                <div
                  key={ride.id}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs space-y-2 hover:border-slate-700 transition"
                >
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-white">{ride.category}</span>
                    <span className="font-bold text-emerald-400">{formatEuro(ride.fare)}</span>
                  </div>
                  <p className="text-slate-400 truncate">
                    <span className="text-emerald-500 font-semibold">De:</span> {ride.pickup.name || ride.pickup.address}
                  </p>
                  <p className="text-slate-400 truncate">
                    <span className="text-rose-500 font-semibold">Vers:</span> {ride.destination.name || ride.destination.address}
                  </p>
                  <div className="flex justify-between items-center text-[10px] text-slate-500 pt-1 border-t border-slate-800/80">
                    <span>{new Date(ride.createdAt).toLocaleDateString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => generateInvoicePDF(ride)}
                        className="text-emerald-400 hover:underline flex items-center gap-1"
                        title="Télécharger facture légale PDF"
                      >
                        <Download className="w-3 h-3" />
                        <span>Facture</span>
                      </button>
                      {ride.status === 'COMPLETED' ? (
                        <button
                          onClick={() => setSelectedDetailRide(ride)}
                          className="text-blue-400 hover:underline font-semibold"
                        >
                          Détails & Facture
                        </button>
                      ) : (
                        <span className="text-amber-500">{ride.status}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : activeRide ? (
          /* Active Ride Tracking Screen */
          <div className="p-4 space-y-4 flex-1 flex flex-col justify-between">
            {/* Status Banner */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
              {activeRide.status === 'REQUESTED' && (
                <div className="text-center py-4 space-y-3">
                  <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
                    <div className="absolute inset-0 rounded-full bg-blue-600/30 radar-ping" />
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center shadow-lg shadow-blue-500/50">
                      <Car className="w-6 h-6 text-white" />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base">Recherche d'un chauffeur...</h3>
                    <p className="text-xs text-slate-400 mt-1">Connexion avec les chauffeurs à proximité de vous</p>
                  </div>
                  <div className="flex items-center justify-center gap-1.5 text-xs text-blue-400">
                    <Clock className="w-3.5 h-3.5 animate-spin" />
                    <span>Temps d'attente estimé : &lt; 1 min</span>
                  </div>
                </div>
              )}

              {['ACCEPTED', 'ARRIVING'].includes(activeRide.status) && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
                      {activeRide.status === 'ARRIVING' ? 'Chauffeur arrivé !' : 'Chauffeur en approche'}
                    </span>
                    <span className="text-xs font-bold bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full border border-blue-500/30">
                      Arrivée dans ~2 min
                    </span>
                  </div>

                  {/* Driver Card */}
                  <div className="flex items-center gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="relative">
                      <div className="w-12 h-12 rounded-full bg-slate-800 border-2 border-emerald-500 flex items-center justify-center font-bold text-white text-lg">
                        {activeRide.driverName?.charAt(0) || 'K'}
                      </div>
                      <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-900" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-bold text-white text-sm truncate">{activeRide.driverName}</p>
                        <span className="text-xs text-amber-400 font-semibold">⭐ {activeRide.driverRating?.toFixed(2)}</span>
                      </div>
                      <p className="text-xs text-slate-300 font-medium">{activeRide.vehicleModel}</p>
                      <p className="text-[11px] text-slate-400 font-mono tracking-wider">{activeRide.vehiclePlate} · {activeRide.vehicleColor}</p>
                    </div>
                  </div>

                  {/* Action Contact & Safety buttons */}
                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <button
                      onClick={() => setIsChatOpen(true)}
                      className="flex items-center justify-center gap-1.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded-xl border border-slate-700/60 text-xs font-medium transition"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-blue-400" />
                      <span>Chat</span>
                    </button>
                    <button
                      onClick={() => setIsCallOpen(true)}
                      className="flex items-center justify-center gap-1.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded-xl border border-slate-700/60 text-xs font-medium transition"
                    >
                      <Phone className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Appel</span>
                    </button>
                    <button
                      onClick={() => setIsSafetyOpen(true)}
                      className="flex items-center justify-center gap-1.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded-xl border border-slate-700/60 text-xs font-medium transition"
                    >
                      <Shield className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Sécurité</span>
                    </button>
                  </div>

                  {/* Verification PIN Code for security & Sharing with Driver */}
                  <div className="bg-slate-900/90 border border-yellow-400/40 rounded-2xl p-3.5 space-y-2.5 shadow-lg shadow-black/40">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-200">
                        <div className="w-8 h-8 rounded-xl bg-yellow-400/20 text-yellow-400 flex items-center justify-center flex-shrink-0">
                          <Shield className="w-4 h-4 stroke-[2.5]" />
                        </div>
                        <div>
                          <p className="font-bold text-xs text-white">Code de confirmation course</p>
                          <p className="text-[10px] text-slate-400">À transmettre au chauffeur pour démarrer</p>
                        </div>
                      </div>
                      <span className="font-mono font-black text-xl text-yellow-400 tracking-widest bg-black px-3 py-1 rounded-xl border border-yellow-400/40 shadow-inner">
                        {activeRide.verificationCode || activeRide.id.slice(-4)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                      <button
                        onClick={() => handleShareCode(activeRide.id)}
                        disabled={codeShared}
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                          codeShared
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                            : 'bg-yellow-400 hover:bg-yellow-300 text-black shadow-md shadow-yellow-500/10'
                        }`}
                      >
                        {codeShared ? (
                          <>
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                            <span>Transmis au chauffeur ✓</span>
                          </>
                        ) : (
                          <>
                            <Share2 className="w-3.5 h-3.5" />
                            <span>Partager avec le chauffeur</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => handleCopyCode(activeRide.verificationCode || activeRide.id.slice(-4))}
                        className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
                        title="Copier le code"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {activeRide.status === 'IN_PROGRESS' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      Course en cours vers destination
                    </span>
                    <button
                      onClick={() => setIsSafetyOpen(true)}
                      className="text-xs font-bold text-blue-400 flex items-center gap-1 hover:underline"
                    >
                      <Share2 className="w-3 h-3" />
                      <span>Partager</span>
                    </button>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 text-xs space-y-1.5">
                    <p className="text-slate-400">
                      <strong className="text-emerald-400">Destination :</strong> {activeRide.destination.name || activeRide.destination.address}
                    </p>
                    <p className="text-slate-500 text-[11px]">
                      Temps estimé : ~{activeRide.durationMin} min · Conduite sécurisée
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Cancel Button */}
            {activeRide.status !== 'IN_PROGRESS' && (
              <button
                onClick={handleCancelActiveRide}
                className="w-full py-2.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold rounded-xl border border-rose-500/30 transition"
              >
                {t('cancelRide')}
              </button>
            )}
          </div>
        ) : (
          /* Booking / Ride Selection Screen */
          <div className="p-4 space-y-4">
            {/* Surge Banner if peak hours */}
            {surgeMultiplier > 1 && (
              <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-amber-300">
                <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>Forte demande dans votre zone (Tarif x{surgeMultiplier.toFixed(1)})</span>
              </div>
            )}

            {/* Now vs Scheduled Toggle */}
            <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setIsScheduling(false)}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
                  !isScheduling ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Partir maintenant
              </button>
              <button
                onClick={() => setIsScheduling(true)}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition flex items-center justify-center gap-1.5 ${
                  isScheduling ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Calendar className="w-3 h-3" />
                <span>Planifier plus tard</span>
              </button>
            </div>

            {/* Date-time picker if scheduling */}
            {isScheduling && (
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs space-y-1.5">
                <label className="text-slate-400 block font-medium">Date et heure de prise en charge :</label>
                <input
                  type="datetime-local"
                  value={scheduledDateTime}
                  onChange={(e) => setScheduledDateTime(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-blue-500"
                />
              </div>
            )}

            {/* Address Selection Card with Multi-stop support */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 space-y-2.5">
              {/* Pickup selection */}
              <div
                onClick={() => {
                  setSearchQuery('');
                  setShowSearchModal('PICKUP');
                }}
                className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 cursor-pointer transition"
              >
                <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Départ</p>
                  <p className="text-xs font-medium text-white truncate">{pickup.name || pickup.address}</p>
                </div>
                <Search className="w-4 h-4 text-slate-500" />
              </div>

              {/* Intermediate Stops */}
              {intermediateStops.map((stop, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-3 p-2 rounded-xl bg-slate-900/40 border border-slate-800 text-xs"
                >
                  <div className="w-3 h-3 rounded-full bg-amber-500 ring-2 ring-amber-500/20 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] text-amber-400 font-semibold uppercase">Arrêt {idx + 1}</p>
                    <p className="text-xs text-white truncate">{stop.name || stop.address}</p>
                  </div>
                  <button
                    onClick={() => handleRemoveStop(idx)}
                    className="p-1 text-slate-500 hover:text-rose-400"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}

              {/* Add Stop Button if < 2 */}
              {intermediateStops.length < 2 && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setShowSearchModal('STOP');
                  }}
                  className="w-full py-1.5 text-[11px] text-blue-400 hover:text-blue-300 font-medium flex items-center justify-center gap-1 border border-dashed border-slate-800 hover:border-slate-700 rounded-lg transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Ajouter une étape (+3,50 €)</span>
                </button>
              )}

              {/* Destination selection */}
              <div
                onClick={() => {
                  setSearchQuery('');
                  setShowSearchModal('DESTINATION');
                }}
                className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 cursor-pointer transition"
              >
                <div className="w-3.5 h-3.5 rounded-full bg-rose-500 ring-4 ring-rose-500/20 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Destination</p>
                  <p className="text-xs font-medium text-white truncate">{destination.name || destination.address}</p>
                </div>
                <Search className="w-4 h-4 text-slate-500" />
              </div>
            </div>

            {/* Ride Category Cards */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Gamme de véhicule</p>
                <span className="text-[11px] text-slate-400">{distanceKm} km · ~{durationMin} min</span>
              </div>

              <div className="space-y-2">
                {(Object.keys(CATEGORIES_CONFIG) as RideCategory[]).map((catKey) => {
                  const cat = CATEGORIES_CONFIG[catKey];
                  const fare = calculateFare(catKey, distanceKm, durationMin, surgeMultiplier, intermediateStops.length);
                  const isSelected = selectedCategory === catKey;

                  return (
                    <div
                      key={catKey}
                      onClick={() => setSelectedCategory(catKey)}
                      className={`p-3 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                        isSelected
                          ? 'bg-blue-600/10 border-blue-500 shadow-md ring-1 ring-blue-500/40'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                          isSelected ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
                        }`}>
                          <Car className="w-6 h-6" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-sm text-white">{cat.name}</h4>
                            <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                              {cat.capacity} places
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5">{cat.exampleVehicle}</p>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="font-bold text-base text-white">{formatEuro(fare)}</span>
                        <p className="text-[10px] text-emerald-400">{cat.etaMinutes} min d'attente</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <CreditCard className="w-4 h-4 text-blue-400" />
                <span className="font-medium">Moyen de paiement :</span>
              </div>
              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                <button
                  onClick={() => setPaymentMethod('CARD')}
                  className={`px-2 py-1 rounded text-[11px] font-semibold transition ${
                    paymentMethod === 'CARD' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Carte
                </button>
                <button
                  onClick={() => setPaymentMethod('APPLE_PAY')}
                  className={`px-2 py-1 rounded text-[11px] font-semibold transition ${
                    paymentMethod === 'APPLE_PAY' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Apple Pay
                </button>
                <button
                  onClick={() => setPaymentMethod('CASH')}
                  className={`px-2 py-1 rounded text-[11px] font-semibold transition ${
                    paymentMethod === 'CASH' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Espèces
                </button>
              </div>
            </div>

            {/* Order / Schedule Button */}
            <button
              onClick={handleBookRide}
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-2xl shadow-xl shadow-blue-600/30 transition active:scale-[0.98] flex items-center justify-center gap-2 text-sm"
            >
              <span>{isScheduling ? 'Planifier la réservation' : `${t('confirmRide')} (${CATEGORIES_CONFIG[selectedCategory].name})`}</span>
              <span className="text-blue-200">·</span>
              <span>{formatEuro(calculateFare(selectedCategory, distanceKm, durationMin, surgeMultiplier, intermediateStops.length))}</span>
            </button>
          </div>
        )}
      </div>

      {/* RIGHT PANEL: Live Interactive Map (Full Screen when panel collapsed) */}
      <div className={`order-1 md:order-2 relative transition-all duration-300 ${
        isPanelCollapsed ? 'w-full h-full flex-1' : 'flex-1 h-[48%] md:h-full'
      }`}>
        {/* Floating Map Controls & Quick Toggle */}
        <div className="absolute top-4 left-4 z-[990] flex items-center gap-2 pointer-events-auto">
          {isPanelCollapsed ? (
            <button
              onClick={() => setIsPanelCollapsed(false)}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-900/95 hover:bg-slate-800 text-white rounded-2xl shadow-2xl border border-slate-700/80 backdrop-blur-md transition font-semibold text-xs group active:scale-95 ring-1 ring-white/10"
            >
              <PanelLeftOpen className="w-4 h-4 text-blue-400 group-hover:scale-110 transition" />
              <span>Afficher les infos passager</span>
              {activeRide && (
                <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded-full text-[10px] font-bold">
                  {activeRide.status === 'REQUESTED'
                    ? 'Recherche...'
                    : activeRide.status === 'ACCEPTED'
                    ? 'Chauffeur assigné'
                    : activeRide.status === 'ARRIVING'
                    ? 'Chauffeur en approche'
                    : activeRide.status === 'IN_PROGRESS'
                    ? 'Course en cours'
                    : activeRide.status}
                </span>
              )}
            </button>
          ) : (
            <button
              onClick={() => setIsPanelCollapsed(true)}
              title="Voir la carte en plein écran (masquer les infos)"
              className="hidden md:flex items-center gap-1.5 px-3 py-2 bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl shadow-lg border border-slate-700/80 backdrop-blur-md transition text-xs font-semibold"
            >
              <Maximize2 className="w-3.5 h-3.5 text-blue-400" />
              <span>Carte plein écran</span>
            </button>
          )}
        </div>

        <VtcMap
          pickup={pickup}
          destination={destination}
          activeRide={activeRide}
          drivers={allDrivers}
          onMapClick={(lat, lng) => {
            setDestination({
              lat,
              lng,
              address: `Position personnalisée (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
              name: 'Point sur la carte',
            });
          }}
        />
      </div>

      {/* Real Live Address Search Modal (data.gouv.fr / Nominatim) */}
      {showSearchModal && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-5 shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-sm">
                Choisir le point {showSearchModal === 'PICKUP' ? 'de départ' : showSearchModal === 'STOP' ? 'd\'étape intermédiaire' : 'd\'arrivée'}
              </h3>
              <button
                onClick={() => setShowSearchModal(null)}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Live Search Input */}
            <div className="my-3 relative">
              <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                {isSearching ? (
                  <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />
                ) : (
                  <Search className="w-4 h-4 text-slate-500" />
                )}
              </div>
              <input
                type="text"
                autoFocus
                placeholder="Tapez n'importe quelle adresse, rue, gare en France..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Search results or default presets */}
            <div className="flex-1 overflow-y-auto space-y-1.5">
              {searchResults.length > 0 ? (
                <div>
                  <p className="text-[10px] text-blue-400 uppercase font-bold px-1 mb-1">Résultats en direct :</p>
                  {searchResults.map((res, i) => (
                    <div
                      key={i}
                      onClick={() => {
                        if (showSearchModal === 'PICKUP') setPickup(res);
                        else if (showSearchModal === 'STOP') handleAddStop(res);
                        else setDestination(res);
                        setShowSearchModal(null);
                      }}
                      className="p-3 rounded-xl bg-slate-950/60 hover:bg-blue-600/10 hover:border-blue-500/50 border border-slate-800/80 cursor-pointer transition text-xs"
                    >
                      <p className="font-semibold text-white">{res.name}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{res.address}</p>
                    </div>
                  ))}
                </div>
              ) : searchQuery.length >= 2 && !isSearching ? (
                <div className="text-center py-6 text-slate-500 text-xs">
                  Aucun résultat trouvé pour cette adresse.
                </div>
              ) : (
                <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold px-1 mb-1">Adresses suggérées :</p>
                  {PRESET_LOCATIONS.map((loc) => (
                    <div
                      key={loc.name}
                      onClick={() => {
                        if (showSearchModal === 'PICKUP') setPickup(loc);
                        else if (showSearchModal === 'STOP') handleAddStop(loc);
                        else setDestination(loc);
                        setShowSearchModal(null);
                      }}
                      className="p-2.5 rounded-xl bg-slate-950/40 hover:bg-slate-800 border border-slate-800/60 cursor-pointer transition text-xs mb-1"
                    >
                      <p className="font-semibold text-white">{loc.name}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5 truncate">{loc.address}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Detailed Ride Modal (Invoice, Sharing, Email) */}
      <RideDetailModal
        ride={selectedDetailRide}
        isOpen={!!selectedDetailRide}
        onClose={() => setSelectedDetailRide(null)}
      />
    </div>
  );
};
