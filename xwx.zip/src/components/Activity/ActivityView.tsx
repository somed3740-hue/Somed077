import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  SlidersHorizontal, 
  RotateCcw, 
  Store, 
  Car, 
  Bike, 
  CheckCircle2, 
  XCircle, 
  Calendar,
  X,
  Receipt,
  Download,
  Share2,
  Mail,
  ChevronRight,
  Search,
  ArrowUpRight,
  ArrowDownLeft,
  CreditCard,
  FileText,
  Clock,
  Check,
  Send,
  Sparkles,
  MapPin,
  ExternalLink
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { DeliveryOrder, Ride, WalletTransaction } from '../../types/vtc';
import { formatEuro } from '../../utils/geo';
import { RideDetailModal } from '../Modals/RideDetailModal';
import { generateInvoicePDF } from '../../utils/invoice';
import { soundEffects } from '../../utils/audio';

interface ActivityViewProps {
  onBack: () => void;
  onRebook: (destinationAddress: string) => void;
  onViewStore: (storeName: string) => void;
  initialTab?: 'ALL' | 'TRIPS' | 'ORDERS' | 'INVOICES' | 'TRANSACTIONS';
}

export const ActivityView: React.FC<ActivityViewProps> = ({
  onBack,
  onRebook,
  onViewStore,
  initialTab = 'ALL',
}) => {
  const [activeTab, setActiveTab] = useState<'ALL' | 'TRIPS' | 'ORDERS' | 'INVOICES' | 'TRANSACTIONS'>(initialTab);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'COMPLETED' | 'CANCELLED'>('ALL');
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Selected ride for receipt / invoice modal
  const [selectedRide, setSelectedRide] = useState<Ride | null>(null);

  // Email invoice modal state
  const [emailModalRide, setEmailModalRide] = useState<Ride | null>(null);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [emailSent, setEmailSent] = useState(false);

  // Share feedback toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();
  const deliveryOrders = vtcStore.getDeliveryOrders();
  const storedRides = vtcStore.getAllRides();

  // Sync tab with external trigger
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Comprehensive sample rides if storage is empty
  const defaultRides: Ride[] = [
    {
      id: 'ride-fac-0091',
      passengerId: passenger.id,
      passengerName: passenger.name,
      passengerPhone: passenger.phone,
      passengerRating: passenger.rating,
      driverId: 'drv-2',
      driverName: 'Alexandre Dupont',
      driverPhone: '+33 6 78 45 12 33',
      driverRating: 4.95,
      vehicleModel: 'Mercedes Classe E',
      vehiclePlate: 'GD-411-AZ',
      vehicleColor: 'Gris Anthracite',
      pickup: { lat: 48.8584, lng: 2.2945, address: 'Tour Eiffel, Champ de Mars, Paris', name: 'Tour Eiffel' },
      destination: { lat: 48.8606, lng: 2.3376, address: 'Musée du Louvre, Rue de Rivoli, Paris', name: 'Musée du Louvre' },
      category: 'CONFORT',
      distanceKm: 5.2,
      durationMin: 18,
      fare: 23.50,
      paymentMethod: 'CARD',
      status: 'COMPLETED',
      createdAt: Date.now() - 3600 * 1000 * 3,
      completedAt: Date.now() - 3600 * 1000 * 2.5,
      rating: 5,
      invoiceNumber: 'FAC-2026-0091',
    },
    {
      id: 'ride-fac-0084',
      passengerId: passenger.id,
      passengerName: passenger.name,
      passengerPhone: passenger.phone,
      passengerRating: passenger.rating,
      driverId: 'drv-1',
      driverName: 'Karim Mansouri',
      driverPhone: '+33 6 12 34 56 78',
      driverRating: 4.92,
      vehicleModel: 'Tesla Model 3',
      vehiclePlate: 'EV-882-TK',
      vehicleColor: 'Noir Métallisé',
      pickup: { lat: 48.8738, lng: 2.2950, address: 'Place de l\'Étoile, Paris', name: 'Arc de Triomphe' },
      destination: { lat: 48.8709, lng: 2.3316, address: 'Palais Garnier, Paris', name: 'Opéra Garnier' },
      category: 'STANDARD',
      distanceKm: 3.8,
      durationMin: 14,
      fare: 16.80,
      paymentMethod: 'CARD',
      status: 'COMPLETED',
      createdAt: Date.now() - 3600 * 1000 * 24 * 2,
      completedAt: Date.now() - 3600 * 1000 * 24 * 2 + 1000 * 900,
      rating: 5,
      invoiceNumber: 'FAC-2026-0084',
    },
    {
      id: 'ride-rec-0001',
      passengerId: passenger.id,
      passengerName: passenger.name,
      passengerPhone: passenger.phone,
      passengerRating: passenger.rating,
      driverId: 'drv-3',
      driverName: 'Sarah Benali',
      driverPhone: '+33 7 89 65 23 14',
      driverRating: 4.98,
      vehicleModel: 'Peugeot 508 Hybrid',
      vehiclePlate: 'EK-772-QS',
      vehicleColor: 'Bleu Nuit',
      pickup: { lat: 31.6225, lng: -8.0125, address: '18 avenue idrissides, Ménara, Marrakech', name: '18 avenue idrissides' },
      destination: { lat: 31.6300, lng: -8.0100, address: 'Dr. Morsi Barakat Jamal, Marrakech', name: 'Dr. Morsi Barakat Jamal' },
      category: 'STANDARD',
      distanceKm: 2.1,
      durationMin: 8,
      fare: 1.50,
      paymentMethod: 'CARD',
      status: 'COMPLETED',
      createdAt: Date.now() - 3600 * 1000 * 24 * 6,
      completedAt: Date.now() - 3600 * 1000 * 24 * 6 + 1000 * 500,
      rating: 4,
      invoiceNumber: 'REC-20260917-0001',
    }
  ];

  const rides: Ride[] = storedRides.length > 0 ? storedRides : defaultRides;

  // Build wallet transactions
  const walletTransactions = passenger.walletTransactions && passenger.walletTransactions.length > 0 
    ? passenger.walletTransactions 
    : [
        {
          id: 'tx-pass-1',
          type: 'TOPUP' as const,
          amount: 50.00,
          description: 'Rechargement portefeuille via Carte Visa ****4242',
          date: '19/09/2026',
        },
        ...rides.map((r) => ({
          id: `tx-ride-${r.id}`,
          type: 'PAYMENT' as const,
          amount: -r.fare,
          description: `Course VTC SOMED (${r.pickup?.name || 'Départ'} → ${r.destination?.name || 'Arrivée'})`,
          date: new Date(r.createdAt).toLocaleDateString('fr-FR'),
        })),
        {
          id: 'tx-pass-3',
          type: 'PAYMENT' as const,
          amount: -18.50,
          description: 'Commande Livraison Restaurant & Boissons',
          date: '17/09/2026',
        },
      ];

  // Consolidate Trips
  const allTrips = rides.map(r => ({
    id: r.id,
    type: 'TRIP' as const,
    title: r.destination?.name || r.destination?.address || 'Destination',
    subtitle: `${r.pickup?.name || r.pickup?.address || 'Prise en charge'} · ${r.distanceKm} km · ${r.durationMin} min`,
    date: new Date(r.createdAt).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }),
    time: new Date(r.createdAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
    total: r.fare,
    status: r.status === 'COMPLETED' ? ('Completed' as const) : ('Cancelled' as const),
    invoiceNumber: r.invoiceNumber || `FAC-${new Date(r.createdAt).getFullYear()}-${r.id.slice(-6).toUpperCase()}`,
    driverName: r.driverName || 'Alexandre Dupont',
    vehicleModel: r.vehicleModel || 'Mercedes Classe E',
    rawRide: r,
  }));

  // Consolidate Orders
  const allOrders = deliveryOrders.map(o => ({
    id: o.id,
    type: 'ORDER' as const,
    title: o.storeName,
    subtitle: `${o.itemsCount} article${o.itemsCount > 1 ? 's' : ''} · ${o.category}`,
    date: o.date,
    time: o.time,
    total: o.total,
    status: o.status,
    invoiceNumber: `CMD-${o.id.toUpperCase()}`,
    storeName: o.storeName,
  }));

  // Consolidate Invoices
  const allInvoices = rides.map(r => ({
    id: r.invoiceNumber || `FAC-${new Date(r.createdAt).getFullYear()}-${r.id.slice(-6).toUpperCase()}`,
    type: 'INVOICE' as const,
    title: `Facture transport #${r.invoiceNumber || r.id.slice(-6).toUpperCase()}`,
    subtitle: `${r.pickup?.name || r.pickup?.address || 'Prise en charge'} → ${r.destination?.name || r.destination?.address || 'Destination'}`,
    date: new Date(r.createdAt).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }),
    time: new Date(r.createdAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
    total: r.fare,
    status: 'Completed' as const,
    rawRide: r,
  }));

  // Consolidate Transactions
  const allTxItems = walletTransactions.map(tx => ({
    id: tx.id,
    type: 'TRANSACTION' as const,
    title: tx.description,
    subtitle: tx.type === 'TOPUP' ? 'Crédit solde portefeuille' : 'Débit prestation mobilité',
    date: tx.date,
    time: '12:00',
    total: Math.abs(tx.amount),
    isPositive: tx.amount > 0,
    status: 'Completed' as const,
  }));

  // Download Invoice PDF directly
  const handleDownloadInvoice = (ride: Ride) => {
    soundEffects.playClick();
    const success = generateInvoicePDF(ride);
    if (success) {
      showToast(`Facture ${ride.invoiceNumber || 'PDF'} téléchargée !`);
      vtcStore.sendPushNotification({
        title: 'Facture téléchargée',
        body: `Le fichier PDF de votre course (${formatEuro(ride.fare)}) a été généré avec succès.`,
        category: 'PAYMENT',
        badge: 'Facture'
      });
    } else {
      showToast('Génération de la facture en cours...');
    }
  };

  // Share Invoice info
  const handleShareInvoice = async (ride: Ride) => {
    soundEffects.playClick();
    const invNum = ride.invoiceNumber || `FAC-${ride.id.slice(-6).toUpperCase()}`;
    const text = `Facture SOMED VTC #${invNum}\nItinéraire : ${ride.pickup?.name || ride.pickup?.address || 'Départ'} → ${ride.destination?.name || ride.destination?.address || 'Arrivée'}\nMontant : ${formatEuro(ride.fare)}\nChauffeur : ${ride.driverName || 'VTC'}\nDate : ${new Date(ride.createdAt).toLocaleDateString('fr-FR')}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `Facture SOMED #${invNum}`,
          text: text,
          url: window.location.href,
        });
        showToast('Facture partagée avec succès !');
        return;
      } catch {
        // User dismissed
      }
    }

    try {
      await navigator.clipboard.writeText(text);
      showToast('Détails de facture copiés !');
    } catch {
      showToast('Facture prête au partage.');
    }
  };

  // Open Email Invoice Dialog
  const handleOpenEmailDialog = (ride: Ride) => {
    soundEffects.playClick();
    setEmailModalRide(ride);
    setRecipientEmail(passenger.email || 'contact@somed.biz');
    setEmailSent(false);
  };

  const handleSendEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailModalRide) return;
    
    soundEffects.playSuccessSound();
    setEmailSent(true);
    const invNum = emailModalRide.invoiceNumber || `FAC-${emailModalRide.id.slice(-6).toUpperCase()}`;

    vtcStore.sendPushNotification({
      title: 'Facture envoyée par email',
      body: `La facture ${invNum} a été transmise avec succès à ${recipientEmail}.`,
      category: 'PAYMENT',
      badge: 'Email'
    });

    setTimeout(() => {
      setEmailSent(false);
      setEmailModalRide(null);
      showToast(`Facture transmise à ${recipientEmail}`);
    }, 1500);
  };

  // Filter items based on activeTab
  let itemsToDisplay: Array<any> = [];
  if (activeTab === 'ALL') {
    itemsToDisplay = [...allTrips, ...allOrders, ...allTxItems];
  } else if (activeTab === 'TRIPS') {
    itemsToDisplay = allTrips;
  } else if (activeTab === 'ORDERS') {
    itemsToDisplay = allOrders;
  } else if (activeTab === 'INVOICES') {
    itemsToDisplay = allInvoices;
  } else if (activeTab === 'TRANSACTIONS') {
    itemsToDisplay = allTxItems;
  }

  // Filter by status if requested
  if (statusFilter !== 'ALL') {
    itemsToDisplay = itemsToDisplay.filter(it => it.status === statusFilter);
  }

  // Filter by search query
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    itemsToDisplay = itemsToDisplay.filter(it => 
      it.title.toLowerCase().includes(q) ||
      it.subtitle?.toLowerCase().includes(q) ||
      it.id.toLowerCase().includes(q) ||
      it.invoiceNumber?.toLowerCase().includes(q)
    );
  }

  // Calculate summary stats
  const totalSpent = rides.reduce((acc, r) => acc + (r.fare || 0), 0) + deliveryOrders.reduce((acc, o) => acc + (o.total || 0), 0);

  return (
    <div className={`h-full w-full flex flex-col overflow-hidden select-none transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
    }`}>
      {/* Top Header */}
      <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 sticky top-0 z-20 transition-colors ${
        isLight ? 'bg-white border-slate-200' : 'bg-black border-neutral-900'
      }`}>
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
            title="Retour"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="font-extrabold text-base leading-tight">Historique & Factures</h2>
            <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Trajets, commandes, transactions & reçus
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowFilterModal(true)}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
            statusFilter !== 'ALL' 
              ? 'bg-yellow-400 text-black shadow-md shadow-yellow-400/20' 
              : isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
          }`}
          title="Filtrer"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>
      </header>

      {/* Overview Stats Cards */}
      <div className={`px-4 py-3 border-b flex-shrink-0 grid grid-cols-3 gap-2 text-center text-xs ${
        isLight ? 'bg-slate-100/70 border-slate-200' : 'bg-neutral-950 border-neutral-900'
      }`}>
        <div className={`p-2.5 rounded-xl border ${isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'}`}>
          <p className="font-extrabold text-sm text-yellow-500">{formatEuro(totalSpent)}</p>
          <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>Total dépensé</p>
        </div>
        <div className={`p-2.5 rounded-xl border ${isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'}`}>
          <p className="font-extrabold text-sm">{rides.length}</p>
          <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>Courses VTC</p>
        </div>
        <div className={`p-2.5 rounded-xl border ${isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'}`}>
          <p className="font-extrabold text-sm text-emerald-400">{allInvoices.length}</p>
          <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>Factures PDF</p>
        </div>
      </div>

      {/* Search Input */}
      <div className={`p-3 border-b flex-shrink-0 ${isLight ? 'bg-white border-slate-200' : 'bg-black border-neutral-900'}`}>
        <div className="relative">
          <Search className={`w-4 h-4 absolute left-3.5 top-3 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
          <input
            type="text"
            placeholder="Rechercher par adresse, boutique, N° de facture..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-10 pr-9 py-2 rounded-xl text-xs font-medium border focus:outline-none transition ${
              isLight 
                ? 'bg-slate-50 border-slate-200 text-slate-900 focus:border-yellow-500' 
                : 'bg-neutral-900 border-neutral-800 text-white focus:border-yellow-400'
            }`}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className={`flex border-b overflow-x-auto flex-shrink-0 scrollbar-none px-2 ${
        isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
      }`}>
        {[
          { id: 'ALL', label: 'Tous' },
          { id: 'TRIPS', label: 'Trajets VTC' },
          { id: 'ORDERS', label: 'Commandes' },
          { id: 'INVOICES', label: 'Factures & Reçus' },
          { id: 'TRANSACTIONS', label: 'Transactions' },
        ].map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                soundEffects.playClick();
              }}
              className={`py-3 px-3.5 text-xs font-bold whitespace-nowrap border-b-2 transition ${
                isActive 
                  ? 'border-yellow-400 text-yellow-500' 
                  : isLight 
                    ? 'border-transparent text-slate-500 hover:text-slate-900' 
                    : 'border-transparent text-neutral-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Main Items Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {itemsToDisplay.length === 0 ? (
          <div className="text-center py-20 space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center mx-auto text-neutral-500">
              <Receipt className="w-6 h-6 stroke-[1.5]" />
            </div>
            <p className="text-sm font-bold">Aucune activité trouvée</p>
            <p className={`text-xs ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
              Vos futurs trajets, commandes et factures s'afficheront ici.
            </p>
          </div>
        ) : (
          itemsToDisplay.map((item) => {
            const isCompleted = item.status === 'Completed';
            const ride = item.rawRide as Ride | undefined;

            return (
              <div
                key={`${item.type}-${item.id}`}
                onClick={() => {
                  if (ride) setSelectedRide(ride);
                }}
                className={`rounded-2xl border p-4 transition shadow-sm space-y-3 group ${
                  isLight 
                    ? 'bg-white border-slate-200 hover:border-slate-300' 
                    : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
                }`}
              >
                {/* Top Row: Icon, Title, Subtitle, Status, Price */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Icon by type */}
                    {item.type === 'TRIP' && (
                      <div className="w-11 h-11 rounded-xl bg-yellow-400 text-black flex items-center justify-center flex-shrink-0 shadow-md shadow-yellow-400/10">
                        <Car className="w-5 h-5 stroke-[2.5]" />
                      </div>
                    )}
                    {item.type === 'ORDER' && (
                      <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 text-black flex items-center justify-center flex-shrink-0 shadow-md">
                        <Bike className="w-5 h-5 stroke-[2.5]" />
                      </div>
                    )}
                    {item.type === 'INVOICE' && (
                      <div className="w-11 h-11 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center justify-center flex-shrink-0">
                        <Receipt className="w-5 h-5 stroke-[2]" />
                      </div>
                    )}
                    {item.type === 'TRANSACTION' && (
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${
                        item.isPositive 
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                          : 'bg-neutral-900 text-neutral-400 border border-neutral-800'
                      }`}>
                        {item.isPositive ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                      </div>
                    )}

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm truncate group-hover:text-yellow-500 transition leading-tight">
                          {item.title}
                        </h4>
                        {item.invoiceNumber && (
                          <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-yellow-400/20 text-yellow-500 border border-yellow-400/30 flex-shrink-0">
                            #{item.invoiceNumber.slice(-8)}
                          </span>
                        )}
                      </div>
                      <p className={`text-xs mt-0.5 truncate ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                        {item.subtitle}
                      </p>
                      <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                        {item.date} {item.time ? `· ${item.time}` : ''}
                      </p>
                    </div>
                  </div>

                  {/* Status & Amount */}
                  <div className="text-right flex-shrink-0">
                    <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-md mb-1 ${
                      isCompleted 
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
                        : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                    }`}>
                      {item.status}
                    </span>
                    <p className={`font-black text-sm ${item.isPositive ? 'text-emerald-400' : ''}`}>
                      {item.isPositive ? '+' : ''}{formatEuro(item.total)}
                    </p>
                  </div>
                </div>

                {/* Bottom Action Bar with Direct Invoice / Receipt Controls */}
                <div className={`pt-2.5 border-t flex flex-wrap items-center justify-between gap-2 text-xs ${
                  isLight ? 'border-slate-100' : 'border-neutral-900'
                }`}>
                  {/* Left: View Details / Reçu */}
                  <div className="flex items-center gap-2">
                    {ride ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedRide(ride);
                        }}
                        className="flex items-center gap-1.5 font-bold text-blue-400 hover:text-blue-300 transition py-1 px-2 rounded-lg hover:bg-blue-500/10"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        <span>Voir reçu détaillé</span>
                      </button>
                    ) : item.type === 'ORDER' ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onViewStore(item.storeName || '');
                        }}
                        className="flex items-center gap-1.5 font-bold text-amber-400 hover:text-amber-300 transition py-1 px-2 rounded-lg hover:bg-amber-500/10"
                      >
                        <Store className="w-3.5 h-3.5" />
                        <span>Voir la boutique</span>
                      </button>
                    ) : null}
                  </div>

                  {/* Right: Download, Share, Send Email Actions for Invoices */}
                  <div className="flex items-center gap-1.5">
                    {ride && (
                      <>
                        {/* Download Facture PDF Button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownloadInvoice(ride);
                          }}
                          className={`flex items-center gap-1 py-1.5 px-2.5 rounded-xl font-bold transition active:scale-95 ${
                            isLight 
                              ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                              : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-200 hover:text-white'
                          }`}
                          title="Télécharger la facture PDF acquittée"
                        >
                          <Download className="w-3.5 h-3.5 text-yellow-500" />
                          <span className="text-[11px]">Télécharger</span>
                        </button>

                        {/* Share Facture Button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleShareInvoice(ride);
                          }}
                          className={`p-1.5 rounded-xl font-bold transition active:scale-95 ${
                            isLight 
                              ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                              : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                          }`}
                          title="Partager les détails de la facture"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                        </button>

                        {/* Send Email Facture Button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenEmailDialog(ride);
                          }}
                          className={`p-1.5 rounded-xl font-bold transition active:scale-95 ${
                            isLight 
                              ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                              : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                          }`}
                          title="Envoyer la facture par email"
                        >
                          <Mail className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}

                    {/* Rebook action for trips */}
                    {item.type === 'TRIP' && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onRebook(item.title);
                        }}
                        className="flex items-center gap-1.5 py-1.5 px-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-[11px] transition active:scale-95 shadow-sm"
                      >
                        <RotateCcw className="w-3 h-3 stroke-[2.5]" />
                        <span>Recommander</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Filter Modal */}
      {showFilterModal && (
        <div className="fixed inset-0 z-[1500] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className={`rounded-3xl w-full max-w-xs p-5 shadow-2xl space-y-4 border ${
            isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
          }`}>
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800/40">
              <h3 className="font-bold text-sm">Filtrer par statut</h3>
              <button
                onClick={() => setShowFilterModal(false)}
                className="w-7 h-7 rounded-lg text-neutral-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <button
                onClick={() => { setStatusFilter('ALL'); setShowFilterModal(false); }}
                className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold transition text-left flex items-center justify-between ${
                  statusFilter === 'ALL' ? 'bg-yellow-400 text-black' : isLight ? 'bg-slate-100 text-slate-800' : 'bg-neutral-900 text-neutral-300'
                }`}
              >
                <span>Toutes les activités</span>
                {statusFilter === 'ALL' && <CheckCircle2 className="w-4 h-4" />}
              </button>

              <button
                onClick={() => { setStatusFilter('COMPLETED'); setShowFilterModal(false); }}
                className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold transition text-left flex items-center justify-between ${
                  statusFilter === 'COMPLETED' ? 'bg-yellow-400 text-black' : isLight ? 'bg-slate-100 text-slate-800' : 'bg-neutral-900 text-neutral-300'
                }`}
              >
                <span>Terminées (Completed)</span>
                {statusFilter === 'COMPLETED' && <CheckCircle2 className="w-4 h-4" />}
              </button>

              <button
                onClick={() => { setStatusFilter('CANCELLED'); setShowFilterModal(false); }}
                className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold transition text-left flex items-center justify-between ${
                  statusFilter === 'CANCELLED' ? 'bg-yellow-400 text-black' : isLight ? 'bg-slate-100 text-slate-800' : 'bg-neutral-900 text-neutral-300'
                }`}
              >
                <span>Annulées (Cancelled)</span>
                {statusFilter === 'CANCELLED' && <CheckCircle2 className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Send Email Modal */}
      {emailModalRide && (
        <div className="fixed inset-0 z-[1500] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className={`rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-4 border ${
            isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800/40">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-yellow-400 text-black flex items-center justify-center">
                  <Mail className="w-5 h-5 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm">Envoyer la facture</h3>
                  <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Facture #{emailModalRide.invoiceNumber || emailModalRide.id.slice(-6).toUpperCase()}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setEmailModalRide(null)}
                className="w-7 h-7 rounded-full flex items-center justify-center text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
              Recevez la facture PDF acquittée de votre course VTC ({formatEuro(emailModalRide.fare)}) par email.
            </p>

            <form onSubmit={handleSendEmailSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-semibold block mb-1">Adresse email destinataire</label>
                <input
                  type="email"
                  required
                  placeholder="votre.email@exemple.com"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-medium focus:outline-none focus:border-yellow-400 ${
                    isLight ? 'bg-slate-50 border-slate-200 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setEmailModalRide(null)}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition ${
                    isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                  }`}
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={emailSent}
                  className="flex-1 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs rounded-xl shadow-md transition active:scale-95 flex items-center justify-center gap-1.5"
                >
                  {emailSent ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Envoyé !</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Transmettre</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[1600] bg-neutral-900/95 border border-yellow-400/60 text-white px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2.5 text-xs font-bold animate-in fade-in slide-in-from-bottom duration-200">
          <Sparkles className="w-4 h-4 text-yellow-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Ride Detail & Invoice Inspection Modal */}
      <RideDetailModal
        ride={selectedRide}
        isOpen={!!selectedRide}
        onClose={() => setSelectedRide(null)}
      />
    </div>
  );
};
