import React, { useState } from 'react';
import { 
  Home, 
  Clock, 
  Wallet, 
  Calendar, 
  CreditCard, 
  Heart, 
  Tag, 
  User, 
  Settings, 
  HelpCircle, 
  X, 
  RefreshCw,
  Star,
  Sun,
  Moon,
  Bell,
  LogOut,
  Globe
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { useTranslation, Language, SUPPORTED_LANGUAGES } from '../../utils/i18n';
import { LanguageModal } from '../Modals/LanguageModal';

interface LeftDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string) => void;
  onSwitchMode: () => void;
  onLogout?: () => void;
}

export const LeftDrawer: React.FC<LeftDrawerProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onSwitchMode,
  onLogout,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();
  const unreadCount = vtcStore.getUnreadNotificationsCount();
  const { lang, t, setLanguage } = useTranslation();
  const [isLangModalOpen, setIsLangModalOpen] = useState(false);

  // Lateral menu items with translations
  const menuItems = [
    { id: 'taxi', label: t('drawerBookRide'), icon: Home },
    { id: 'notifications', label: t('notifications'), icon: Bell, badge: unreadCount > 0 ? unreadCount : undefined },
    { id: 'activity', label: t('drawerActivity'), icon: Clock },
    { id: 'wallet', label: t('drawerWallet'), icon: Wallet },
    { id: 'payment', label: t('drawerPaymentMethods'), icon: CreditCard },
    { id: 'scheduled', label: t('drawerScheduledTrips'), icon: Calendar },
    { id: 'locations', label: t('drawerSavedPlaces'), icon: Heart },
    { id: 'promotions', label: t('drawerPromotions'), icon: Tag },
    { id: 'profile', label: t('tabProfile'), icon: User },
    { id: 'settings', label: t('drawerSettings'), icon: Settings },
    { id: 'help', label: t('drawerSupport'), icon: HelpCircle },
  ];

  const currentFlag = SUPPORTED_LANGUAGES.find(l => l.code === lang)?.flag || '🇫🇷';

  return (
    <div className="fixed inset-0 z-[1200] flex animate-in fade-in duration-200">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Drawer content panel */}
      <div className={`relative w-[85%] max-w-sm h-full flex flex-col z-10 shadow-2xl transition-colors duration-200 ${
        isLight ? 'bg-white text-slate-900' : 'bg-neutral-950 text-white'
      }`}>
        {/* User Profile Header (Click navigates to profile) */}
        <div className={`p-5 border-b flex items-center justify-between ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-neutral-900/60'
        }`}>
          <div 
            onClick={() => {
              onNavigate('profile');
              onClose();
            }}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative">
              <div className="w-14 h-14 rounded-full bg-neutral-900 border-2 border-yellow-400 p-0.5 overflow-hidden flex items-center justify-center">
                <img 
                  src={passenger.avatarUrl} 
                  alt={passenger.name} 
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <span className="absolute -bottom-1 -right-1 bg-yellow-400 text-black text-[9px] font-black rounded-full px-1 py-0.2 border border-black flex items-center">
                ★ {passenger.rating.toFixed(1)}
              </span>
            </div>

            <div>
              <h3 className="font-bold text-base group-hover:text-yellow-500 transition leading-tight">
                {passenger.name}
              </h3>
              <p className={`text-xs flex items-center gap-1 mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                <span>{passenger.tripsCount} {t('tripsCount')}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'hover:bg-slate-200 text-slate-500' : 'hover:bg-neutral-800 text-neutral-400 hover:text-white'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu list */}
        <div className="flex-1 overflow-y-auto py-2 px-3 space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={`w-full p-3 rounded-2xl flex items-center justify-between text-left transition active:scale-[0.98] ${
                  isLight 
                    ? 'hover:bg-slate-100 text-slate-700 hover:text-black' 
                    : 'hover:bg-neutral-900 text-neutral-300 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                    isLight ? 'bg-slate-100 text-slate-600' : 'bg-neutral-900 text-neutral-400'
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-semibold">{item.label}</span>
                </div>

                {item.badge && (
                  <span className="bg-yellow-400 text-black text-[10px] font-black px-2 py-0.5 rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Quick Language + Theme Toggle & Switch mode button & footer */}
        <div className={`p-4 border-t space-y-2.5 ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-neutral-950'
        }`}>
          {/* Language Selector + Theme Toggle row */}
          <div className="grid grid-cols-2 gap-2">
            {/* Language button */}
            <button
              onClick={() => setIsLangModalOpen(true)}
              className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-xs font-bold border transition ${
                isLight 
                  ? 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300 shadow-sm' 
                  : 'bg-neutral-900 hover:bg-neutral-800 text-yellow-400 border-neutral-800'
              }`}
            >
              <span className="text-sm">{currentFlag}</span>
              <span>{lang.toUpperCase()}</span>
            </button>

            {/* Quick theme toggle */}
            <button
              onClick={() => vtcStore.toggleAppearance()}
              className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-xs font-bold border transition ${
                isLight 
                  ? 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300 shadow-sm' 
                  : 'bg-neutral-900 hover:bg-neutral-800 text-yellow-400 border-neutral-800'
              }`}
            >
              {isLight ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
              <span>{isLight ? t('dark') : t('light')}</span>
            </button>
          </div>

          {/* Prominent Direct Role Switcher button */}
          <button
            onClick={() => {
              onSwitchMode();
              onClose();
            }}
            className="w-full py-3 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-sm flex items-center justify-center gap-2.5 transition active:scale-98 shadow-lg shadow-yellow-400/20"
          >
            <RefreshCw className="w-4 h-4 stroke-[2.5]" />
            <span>{t('switchInterface')}</span>
          </button>

          {/* Logout button */}
          {onLogout && (
            <button
              onClick={() => {
                onLogout();
                onClose();
              }}
              className={`w-full py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition active:scale-98 ${
                isLight 
                  ? 'border-slate-300 hover:bg-rose-50 text-rose-600' 
                  : 'border-neutral-800 hover:bg-neutral-900 text-rose-400'
              }`}
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{t('logout')}</span>
            </button>
          )}

          <p className={`text-[10px] text-center font-mono ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
            SOMED v1.0.2 (#3)
          </p>
        </div>
      </div>

      {/* Language Modal */}
      <LanguageModal
        isOpen={isLangModalOpen}
        onClose={() => setIsLangModalOpen(false)}
      />
    </div>
  );
};
