import React, { useState } from 'react';
import { 
  RotateCw, 
  Receipt, 
  Bike, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Phone,
  User,
  MapPin,
  Download,
  Share2,
  Mail,
  Send,
  Check,
  X,
  Sparkles,
  ArrowUpRight,
  ArrowDownLeft,
  Store,
  DollarSign,
  Car,
  RotateCcw,
  Search,
  SlidersHorizontal,
  FileText,
  ShoppingBag
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';
import { CourierRequest, BusinessTransaction, Ride } from '../../types/vtc';
import { generateBusinessOrderInvoicePDF, generateInvoicePDF } from '../../utils/invoice';
import { soundEffects } from '../../utils/audio';

export const BusinessOrdersView: React.FC = () => {
  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const requests = vtcStore.getCourierRequests();
  const allRides = vtcStore.getAllRides();

  const [activeTab, setActiveTab] = useState<'ALL' | 'ORDERS' | 'TRIPS' | 'INVOICES' | 'TRANSACTIONS'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPeriod, setFilterPeriod] = useState<'ALL' | 'TODAY' | 'WEEK'>('ALL');
  const [selectedOrder, setSelectedOrder] = useState<CourierRequest | null>(null);
  const [selectedRide, setSelectedRide] = useState<Ride | null>(null);

  // Email modal state
  const [emailModalOrder, setEmailModalOrder] = useState<CourierRequest | null>(null);
  const [recipientEmail, setRecipientEmail] = useState(business.email || 'comptabilite@somed.biz');
  const [emailSent, setEmailSent] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  // Sample transactions if empty
  const businessTransactions: BusinessTransaction[] = business.transactions && business.transactions.length > 0
    ? business.transactions
    : [
        {
          id: 'tx-biz-1',
          type: 'ORDER_PAYMENT',
          title: 'Encaissement commande client #CMD-8831',
          amount: 45.00,
          date: '19/09/2026',
          time: '18:15',
          status: 'Completed',
          reference: 'CMD-8831',
        },
        {
          id: 'tx-biz-2',
          type: 'COMMISSION',
          title: 'Frais de livraison coursier VTC SOMED',
          amount: -6.50,
          date: '19/09/2026',
          time: '18:35',
          status: 'Completed',
        },
        {
          id: 'tx-biz-3',
          type: 'TOP_UP',
          title: 'Crédit solde commercial boutique',
          amount: 150.00,
          date: '16/09/2026',
          time: '10:00',
          status: 'Completed',
        },
      ];

  const filteredOrders = requests.filter(r => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const cName = r.customerName?.toLowerCase() || '';
      const cAddr = r.customerAddress?.toLowerCase() || '';
      const idMatch = r.id.toLowerCase().includes(q);
      return cName.includes(q) || cAddr.includes(q) || idMatch;
    }
    return true;
  });

  const filteredRides = allRides.filter(r => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const pName = r.passengerName?.toLowerCase() || '';
      const pAddr = r.pickup?.address?.toLowerCase() || '';
      const dAddr = r.destination?.address?.toLowerCase() || '';
      return pName.includes(q) || pAddr.includes(q) || dAddr.includes(q) || r.id.toLowerCase().includes(q);
    }
    return true;
  });

  const handleDownloadInvoice = (order: CourierRequest) => {
    soundEffects.playClick();
    const success = generateBusinessOrderInvoicePDF(order, business);
    if (success) {
      showToast(`Facture commande #${order.id.slice(-6).toUpperCase()} téléchargée !`);
      vtcStore.sendPushNotification({
        title: 'Facture commande téléchargée',
        body: `La facture marchand #${order.id.slice(-6).toUpperCase()} (${formatEuro(order.orderValue)}) a été enregistrée en PDF.`,
        category: 'BUSINESS',
        badge: 'Facture Marchand'
      });
    }
  };

  const handleShareOrder = async (order: CourierRequest) => {
    soundEffects.playClick();
    const text = `Facture Commande SOMED #${order.id.slice(-6).toUpperCase()}\nBoutique : ${business.name}\nClient : ${order.customerName}\nAdresse : ${order.customerAddress}\nMontant : ${formatEuro(order.orderValue)}\nStatut : ${order.status}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `Facture Marchand #${order.id.slice(-6).toUpperCase()}`,
          text: text,
          url: window.location.href,
        });
        showToast('Facture partagée !');
        return;
      } catch {}
    }

    try {
      await navigator.clipboard.writeText(text);
      showToast('Détails copiés dans le presse-papiers !');
    } catch {
      showToast('Informations prêtes.');
    }
  };

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailModalOrder) return;

    soundEffects.playSuccessSound();
    setEmailSent(true);

    vtcStore.sendPushNotification({
      title: 'Facture envoyée par email',
      body: `La facture #${emailModalOrder.id.slice(-6).toUpperCase()} a été transmise à ${recipientEmail}.`,
      category: 'BUSINESS',
      badge: 'Email'
    });

    setTimeout(() => {
      setEmailSent(false);
      setEmailModalOrder(null);
      showToast(`Facture transmise avec succès à ${recipientEmail}`);
    }, 1500);
  };

  return (
    <div className="flex flex-col h-full overflow-hidden select-none animate-in fade-in duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[1400] bg-black/90 border border-yellow-400/50 text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-bold animate-in fade-in slide-in-from-top-4 duration-200">
          <Sparkles className="w-4 h-4 text-yellow-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Email Modal */}
      {emailModalOrder && (
        <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className={`w-full max-w-sm rounded-3xl p-6 border shadow-2xl space-y-4 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-yellow-400" />
                <h3 className="font-bold text-sm">Transmettre la facture</h3>
              </div>
              <button 
                onClick={() => setEmailModalOrder(null)}
                className="w-7 h-7 rounded-full bg-neutral-900 text-neutral-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs space-y-1">
              <p className="font-medium">
                Commande #{emailModalOrder.id.slice(-6).toUpperCase()}
              </p>
              <p className="text-neutral-400">
                Client : {emailModalOrder.customerName} · Montant : {formatEuro(emailModalOrder.orderValue)}
              </p>
            </div>

            <form onSubmit={handleSendEmail} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1 text-neutral-400">
                  Adresse email du destinataire
                </label>
                <input
                  type="email"
                  required
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  placeholder="comptabilite@somed.biz"
                  className={`w-full px-4 py-3 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                    isLight 
                      ? 'bg-slate-100 border-slate-300 text-slate-900' 
                      : 'bg-neutral-900 border-neutral-700 text-white'
                  }`}
                />
              </div>

              <button
                type="submit"
                disabled={emailSent}
                className="w-full py-3.5 px-4 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-bold text-sm flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-yellow-400/20"
              >
                {emailSent ? (
                  <>
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>Envoyé avec succès !</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Envoyer la facture PDF</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Top Header */}
      <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
        isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
      }`}>
        <div className="flex items-center gap-2">
          <Store className="w-4 h-4 text-yellow-500" />
          <h1 className="font-extrabold text-base tracking-tight">Historique & Factures Business</h1>
        </div>
        <button
          onClick={() => {
            soundEffects.playClick();
            vtcStore.notify();
            showToast('Données synchronisées !');
          }}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition active:rotate-180 ${
            isLight ? 'hover:bg-slate-100 text-slate-600' : 'hover:bg-neutral-900 text-neutral-400'
          }`}
          title="Actualiser"
        >
          <RotateCw className="w-4 h-4" />
        </button>
      </header>

      {/* Search Bar */}
      <div className={`px-4 py-2.5 border-b flex items-center gap-2 flex-shrink-0 ${
        isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
      }`}>
        <div className={`flex-1 flex items-center gap-2 px-3 py-1.5 rounded-xl border ${
          isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
        }`}>
          <Search className="w-4 h-4 text-neutral-400 flex-shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher par client, adresse, #commande..."
            className="w-full bg-transparent text-xs focus:outline-none placeholder:text-neutral-500"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="text-neutral-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* 5 Dedicated Navigation Tabs: Tous, Commandes, Trajets VTC, Factures & Reçus, Transactions */}
      <div className={`flex border-b overflow-x-auto flex-shrink-0 scrollbar-none px-2 ${
        isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
      }`}>
        {[
          { id: 'ALL', label: 'Tous', icon: Sparkles },
          { id: 'ORDERS', label: 'Commandes', icon: ShoppingBag },
          { id: 'TRIPS', label: 'Trajets VTC', icon: Car },
          { id: 'INVOICES', label: 'Factures & Reçus', icon: Receipt },
          { id: 'TRANSACTIONS', label: 'Transactions', icon: DollarSign },
        ].map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                soundEffects.playClick();
              }}
              className={`flex items-center gap-1.5 py-3 px-3.5 text-xs font-bold whitespace-nowrap border-b-2 transition ${
                isActive 
                  ? 'border-yellow-400 text-yellow-500' 
                  : isLight 
                    ? 'border-transparent text-slate-500 hover:text-slate-900' 
                    : 'border-transparent text-neutral-400 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 max-w-lg mx-auto w-full pb-24">
        {/* TRANSACTIONS TAB */}
        {activeTab === 'TRANSACTIONS' ? (
          <div className="space-y-3">
            {businessTransactions.map((tx) => (
              <div
                key={tx.id}
                className={`p-4 rounded-2xl border space-y-2 shadow-sm ${
                  isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                      tx.amount > 0 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}>
                      {tx.amount > 0 ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    </div>
                    <div>
                      <h4 className="font-bold text-xs">{tx.title}</h4>
                      <p className={`text-[11px] ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                        {tx.date} à {tx.time}
                      </p>
                    </div>
                  </div>

                  <span className={`font-black text-sm ${tx.amount > 0 ? 'text-emerald-500' : 'text-rose-400'}`}>
                    {tx.amount > 0 ? '+' : ''}{formatEuro(tx.amount)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : activeTab === 'TRIPS' ? (
          /* TRIPS VTC TAB */
          filteredRides.length === 0 ? (
            <div className={`p-8 text-center rounded-3xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <Car className="w-10 h-10 mx-auto text-neutral-500 mb-2" />
              <p className="font-bold text-sm">Aucun trajet VTC enregistré</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredRides.map((ride) => (
                <div
                  key={ride.id}
                  className={`p-4 rounded-3xl border shadow-sm space-y-3 ${
                    isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                        {ride.status}
                      </span>
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-yellow-400/20 text-yellow-500 border border-yellow-400/30">
                        #FAC-{ride.id.slice(-6).toUpperCase()}
                      </span>
                    </div>
                    <span className="font-black text-sm text-yellow-500">
                      {formatEuro(ride.fare)}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <p className="text-xs truncate flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0" />
                      <span className="truncate">{ride.pickup?.address || 'Départ'}</span>
                    </p>
                    <p className={`text-xs truncate flex items-center gap-1.5 ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                      <span className="w-2 h-2 rounded-full bg-rose-500 flex-shrink-0" />
                      <span className="truncate">{ride.destination?.address || 'Arrivée'}</span>
                    </p>
                  </div>

                  {/* Actions */}
                  <div className={`pt-2.5 border-t flex items-center justify-end gap-1.5 text-xs ${
                    isLight ? 'border-slate-100' : 'border-neutral-900'
                  }`}>
                    <button
                      onClick={() => {
                        soundEffects.playClick();
                        generateInvoicePDF(ride);
                        showToast('Facture VTC téléchargée !');
                      }}
                      className="flex items-center gap-1 py-1.5 px-2.5 rounded-xl bg-yellow-400 text-black font-bold text-xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>PDF</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : filteredOrders.length === 0 ? (
          <div className={`p-8 text-center rounded-3xl border ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <Receipt className="w-10 h-10 mx-auto text-neutral-500 mb-2" />
            <p className="font-bold text-sm">Aucune commande trouvée</p>
            <p className={`text-xs mt-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Les commandes de clients apparaîtront ici.
            </p>
          </div>
        ) : (
          filteredOrders.map((order) => {
            const facNum = `FAC-CMD-${order.id.slice(-6).toUpperCase()}`;

            return (
              <div
                key={order.id}
                className={`p-4 rounded-3xl border shadow-sm space-y-3.5 transition ${
                  isLight ? 'bg-white border-slate-200 hover:border-slate-300' : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
                }`}
              >
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      order.status === 'DELIVERED'
                        ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                        : order.status === 'CANCELLED'
                        ? 'bg-rose-500/10 text-rose-500 border border-rose-500/20'
                        : 'bg-yellow-400/10 text-yellow-500 border border-yellow-400/20'
                    }`}>
                      {order.status === 'DELIVERED' ? 'Livrée' : order.status === 'IN_TRANSIT' ? 'En cours de livraison' : order.status}
                    </span>
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-yellow-400/20 text-yellow-500 border border-yellow-400/30">
                      #{facNum}
                    </span>
                  </div>

                  <span className="font-black text-sm text-yellow-500">
                    {formatEuro(order.orderValue)}
                  </span>
                </div>

                {/* Details */}
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold">
                    <User className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Client : {order.customerName}</span>
                  </div>
                  <div className={`flex items-center gap-2 text-xs ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                    <MapPin className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                    <span className="truncate">{order.customerAddress}</span>
                  </div>
                  <div className={`flex items-center gap-2 text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    <Bike className="w-3.5 h-3.5 text-blue-400" />
                    <span>Coursier : {(order as any).courierName || 'Coursier Express VTC'}</span>
                  </div>
                </div>

                {/* Direct Action Buttons: Télécharger, Partager, Envoyer, Voir reçu, Recommander */}
                <div className={`pt-2.5 border-t flex items-center justify-between text-xs ${
                  isLight ? 'border-slate-100' : 'border-neutral-900'
                }`}>
                  <button
                    onClick={() => {
                      soundEffects.playClick();
                      showToast(`Détails commande #${order.id.slice(-6).toUpperCase()}`);
                    }}
                    className={`text-[11px] font-bold flex items-center gap-1 ${
                      isLight ? 'text-blue-600 hover:underline' : 'text-blue-400 hover:underline'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Voir facture</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    {/* Télécharger PDF */}
                    <button
                      onClick={() => handleDownloadInvoice(order)}
                      className={`flex items-center gap-1 py-1.5 px-2.5 rounded-xl font-bold transition active:scale-95 ${
                        isLight 
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                          : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-200 hover:text-white'
                      }`}
                      title="Télécharger la facture PDF"
                    >
                      <Download className="w-3.5 h-3.5 text-yellow-500" />
                      <span className="text-[11px]">PDF</span>
                    </button>

                    {/* Partager */}
                    <button
                      onClick={() => handleShareOrder(order)}
                      className={`p-1.5 rounded-xl font-bold transition active:scale-95 ${
                        isLight 
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                          : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                      }`}
                      title="Partager la facture"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>

                    {/* Envoyer par email */}
                    <button
                      onClick={() => setEmailModalOrder(order)}
                      className={`p-1.5 rounded-xl font-bold transition active:scale-95 ${
                        isLight 
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                          : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                      }`}
                      title="Envoyer la facture par email"
                    >
                      <Mail className="w-3.5 h-3.5" />
                    </button>

                    {/* Recommander / Relancer */}
                    <button
                      onClick={() => {
                        soundEffects.playClick();
                        showToast(`Commande #${order.id.slice(-6).toUpperCase()} relancée !`);
                      }}
                      className={`p-1.5 rounded-xl font-bold transition active:scale-95 ${
                        isLight 
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                          : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                      }`}
                      title="Relancer / Recommander"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-emerald-500" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
