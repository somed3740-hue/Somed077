import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Check, 
  X, 
  Tag, 
  Image as ImageIcon,
  DollarSign
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { BusinessProduct } from '../../types/vtc';
import { formatEuro } from '../../utils/geo';

interface BusinessProductsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BusinessProductsModal: React.FC<BusinessProductsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const products = business.products || [];
  const categories = business.categories || [];

  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [isAddingProduct, setIsAddingProduct] = useState(false);

  // New product form state
  const [newProductName, setNewProductName] = useState('');
  const [newProductPrice, setNewProductPrice] = useState('');
  const [newProductCategory, setNewProductCategory] = useState(categories[0]?.name || 'fruits');
  const [newProductDesc, setNewProductDesc] = useState('');
  const [newProductImg, setNewProductImg] = useState('https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=200&auto=format&fit=crop&q=80');

  const filteredProducts = selectedCategory === 'ALL'
    ? products
    : products.filter(p => p.category.toLowerCase() === selectedCategory.toLowerCase());

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseFloat(newProductPrice);
    if (!newProductName.trim() || isNaN(priceNum) || priceNum <= 0) return;

    vtcStore.addBusinessProduct({
      name: newProductName.trim(),
      price: priceNum,
      category: newProductCategory,
      description: newProductDesc.trim() || undefined,
      imageUrl: newProductImg,
      isAvailable: true,
    });

    setNewProductName('');
    setNewProductPrice('');
    setNewProductDesc('');
    setIsAddingProduct(false);
  };

  return (
    <div className="fixed inset-0 z-[1300] flex flex-col select-none animate-in fade-in duration-200">
      <div className={`h-full w-full flex flex-col overflow-hidden transition-colors ${
        isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
      }`}>
        {/* Top Header (Screenshot 12) */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">Products</h2>
          <div className="w-9" />
        </header>

        {/* Categories Horizontal Filter (Screenshot 12: Todos, fruits (1)) */}
        <div className={`px-5 py-3 border-b flex items-center gap-2 overflow-x-auto no-scrollbar flex-shrink-0 ${
          isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
        }`}>
          <button
            onClick={() => setSelectedCategory('ALL')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
              selectedCategory === 'ALL'
                ? 'bg-purple-600 text-white shadow-md'
                : isLight ? 'bg-slate-100 text-slate-700' : 'bg-neutral-900 text-neutral-300 hover:text-white'
            }`}
          >
            {selectedCategory === 'ALL' && <Check className="w-3.5 h-3.5" />}
            <span>Todos</span>
          </button>

          {categories.map((cat) => {
            const count = products.filter(p => p.category.toLowerCase() === cat.name.toLowerCase()).length;
            const isSel = selectedCategory.toLowerCase() === cat.name.toLowerCase();
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.name)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                  isSel
                    ? 'bg-purple-600 text-white shadow-md'
                    : isLight ? 'bg-slate-100 text-slate-700' : 'bg-neutral-900 text-neutral-300 hover:text-white'
                }`}
              >
                <span>{cat.name} ({count})</span>
              </button>
            );
          })}
        </div>

        {/* Products List Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3 max-w-lg mx-auto w-full relative">
          {filteredProducts.length === 0 ? (
            <div className={`p-8 text-center rounded-3xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <Tag className="w-10 h-10 mx-auto text-neutral-500 mb-2" />
              <p className="font-bold text-sm">No products in this category</p>
              <p className={`text-xs mt-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Click the yellow + button below to add your first product.
              </p>
            </div>
          ) : (
            filteredProducts.map((product) => (
              <div
                key={product.id}
                className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition shadow-sm ${
                  isLight 
                    ? 'bg-white border-slate-200' 
                    : 'bg-neutral-950 border-neutral-900'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-14 h-14 rounded-xl overflow-hidden bg-neutral-800 flex-shrink-0 border border-black/10">
                    <img
                      src={product.imageUrl || 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=200&auto=format&fit=crop&q=80'}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-bold text-sm truncate">{product.name}</h3>
                    <p className="text-yellow-500 font-extrabold text-sm">{formatEuro(product.price)}</p>
                    <p className={`text-[11px] truncate capitalize ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      {product.category}
                    </p>
                  </div>
                </div>

                {/* Right controls: Toggle & Delete */}
                <div className="flex items-center gap-3 flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => vtcStore.toggleBusinessProductAvailable(product.id)}
                    className={`w-12 h-7 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                      product.isAvailable ? 'bg-yellow-400' : isLight ? 'bg-slate-300' : 'bg-neutral-800'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full shadow transform transition duration-200 ${
                      product.isAvailable 
                        ? 'translate-x-5 bg-emerald-600' 
                        : 'translate-x-0 bg-white'
                    }`} />
                  </button>

                  <button
                    onClick={() => {
                      if (confirm(`Delete product "${product.name}"?`)) {
                        vtcStore.deleteBusinessProduct(product.id);
                      }
                    }}
                    className="w-8 h-8 rounded-lg text-rose-500 hover:bg-rose-500/10 flex items-center justify-center transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Yellow Floating Action Button (+) (Screenshot 12) */}
        <div className="fixed bottom-6 right-6 z-30">
          <button
            onClick={() => setIsAddingProduct(true)}
            className="w-14 h-14 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black shadow-xl shadow-yellow-400/30 flex items-center justify-center transition active:scale-95"
            title="Add product"
          >
            <Plus className="w-7 h-7 stroke-[3]" />
          </button>
        </div>

        {/* Add Product Dialog Modal */}
        {isAddingProduct && (
          <div className="fixed inset-0 z-[1400] flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
            <div className={`w-full max-w-sm rounded-3xl p-6 border shadow-2xl space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
            }`}>
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800/60">
                <h3 className="font-bold text-base">New Product</h3>
                <button 
                  onClick={() => setIsAddingProduct(false)}
                  className="w-7 h-7 rounded-full flex items-center justify-center text-neutral-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCreateProduct} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold">Product Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. coco, avocado..."
                    value={newProductName}
                    onChange={(e) => setNewProductName(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold">Price (€)</label>
                    <input
                      type="number"
                      step="0.10"
                      min="0.1"
                      required
                      placeholder="8.00"
                      value={newProductPrice}
                      onChange={(e) => setNewProductPrice(e.target.value)}
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-bold ${
                        isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                      }`}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold">Category</label>
                    <select
                      value={newProductCategory}
                      onChange={(e) => setNewProductCategory(e.target.value)}
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-medium ${
                        isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                      }`}
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.name}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold">Description (optional)</label>
                  <input
                    type="text"
                    placeholder="Fresh organic fruit"
                    value={newProductDesc}
                    onChange={(e) => setNewProductDesc(e.target.value)}
                    className={`w-full px-3.5 py-2 rounded-xl border text-xs ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold">Image URL</label>
                  <input
                    type="url"
                    value={newProductImg}
                    onChange={(e) => setNewProductImg(e.target.value)}
                    className={`w-full px-3.5 py-2 rounded-xl border text-xs font-mono truncate ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingProduct(false)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold border ${
                      isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-900 border-neutral-800'
                    }`}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-xl text-xs shadow-lg"
                  >
                    Save Product
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
