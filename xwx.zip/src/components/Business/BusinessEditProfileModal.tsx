import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Camera, 
  Check, 
  X, 
  Store, 
  Mail, 
  Phone, 
  MapPin, 
  Link as LinkIcon, 
  Image as ImageIcon,
  Sparkles,
  Upload
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';

interface BusinessEditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BusinessEditProfileModal: React.FC<BusinessEditProfileModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();

  const [name, setName] = useState(business.name);
  const [email, setEmail] = useState(business.email);
  const [phone, setPhone] = useState(business.phone);
  const [address, setAddress] = useState(business.address);
  const [publicUrl, setPublicUrl] = useState(business.publicUrl);
  const [avatarUrl, setAvatarUrl] = useState(business.avatarUrl);
  const [bannerUrl, setBannerUrl] = useState(business.bannerUrl);
  const [isSaved, setIsSaved] = useState(false);

  // Preset avatar choices
  const sampleAvatars = [
    'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=200&auto=format&fit=crop&q=80',
  ];

  // Preset banner choices
  const sampleBanners = [
    'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1514933651103-005eec06c04b?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1559339352-11d035aa65de?w=800&auto=format&fit=crop&q=80',
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'banner') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (type === 'avatar') {
        setAvatarUrl(base64);
      } else {
        setBannerUrl(base64);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    vtcStore.updateBusinessProfile({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      address: address.trim(),
      publicUrl: publicUrl.trim(),
      avatarUrl,
      bannerUrl,
    });

    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-[1450] flex flex-col bg-black/85 backdrop-blur-md text-white select-none animate-in fade-in duration-200">
      <div className={`flex flex-col h-full max-w-lg mx-auto w-full border-x shadow-2xl transition-colors ${
        isLight ? 'bg-slate-50 border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-900 text-white'
      }`}>
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-white' : 'border-neutral-900 bg-black'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-neutral-900 text-neutral-300 hover:text-white'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <h2 className="font-extrabold text-base flex items-center gap-2">
            <Store className="w-4 h-4 text-yellow-500" />
            <span>Personnaliser l'Espace Business</span>
          </h2>

          <div className="w-9" />
        </header>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
          {/* Banner Photo Preview & Customization */}
          <div className={`p-4 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-900 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-yellow-500" />
                <span>Bannière de couverture de l'établissement</span>
              </label>

              <label className="cursor-pointer text-[11px] font-bold text-yellow-500 hover:underline flex items-center gap-1">
                <Upload className="w-3 h-3" />
                <span>Importer photo</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e, 'banner')}
                  className="hidden"
                />
              </label>
            </div>

            <div className="relative h-28 rounded-2xl overflow-hidden border border-neutral-700/60 bg-neutral-800">
              <img
                src={bannerUrl}
                alt="Banner"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center pointer-events-none">
                <span className="text-[10px] bg-black/60 px-2 py-1 rounded-full text-white backdrop-blur-sm">
                  Aperçu de la bannière
                </span>
              </div>
            </div>

            {/* Presets */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
              {sampleBanners.map((url, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setBannerUrl(url)}
                  className={`w-16 h-10 rounded-xl overflow-hidden border-2 flex-shrink-0 transition ${
                    bannerUrl === url ? 'border-yellow-400 scale-105' : 'border-neutral-700 opacity-60'
                  }`}
                >
                  <img src={url} alt="preset banner" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>

            <input
              type="url"
              value={bannerUrl}
              onChange={(e) => setBannerUrl(e.target.value)}
              placeholder="Ou collez l'URL de votre bannière..."
              className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-800 border-neutral-700 text-white'
              }`}
            />
          </div>

          {/* Avatar / Logo Customization */}
          <div className={`p-4 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-900 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-yellow-500" />
                <span>Logo / Avatar du profil entreprise</span>
              </label>

              <label className="cursor-pointer text-[11px] font-bold text-yellow-500 hover:underline flex items-center gap-1">
                <Upload className="w-3 h-3" />
                <span>Importer logo</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e, 'avatar')}
                  className="hidden"
                />
              </label>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-yellow-400 border-2 border-yellow-400 p-0.5 overflow-hidden shadow-xl flex-shrink-0">
                <img
                  src={avatarUrl}
                  alt={name}
                  className="w-full h-full object-cover rounded-full"
                />
              </div>

              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2">
                  {sampleAvatars.map((url, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setAvatarUrl(url)}
                      className={`w-8 h-8 rounded-full overflow-hidden border-2 transition ${
                        avatarUrl === url ? 'border-yellow-400 scale-105' : 'border-neutral-700 opacity-60'
                      }`}
                    >
                      <img src={url} alt="preset avatar" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>

                <input
                  type="url"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  placeholder="URL du logo ou photo..."
                  className={`w-full px-3 py-1.5 rounded-xl text-xs border focus:outline-none ${
                    isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-800 border-neutral-700 text-white'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Business Details Fields */}
          <div className={`p-4 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-900 border-neutral-800'
          }`}>
            <div>
              <label className="text-xs font-semibold block mb-1">Nom de l'établissement</label>
              <div className="relative">
                <Store className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                    isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-800 border-neutral-700 text-white'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold block mb-1">Email professionnel</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                    isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-800 border-neutral-700 text-white'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold block mb-1">Téléphone de contact</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                    isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-800 border-neutral-700 text-white'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold block mb-1">Adresse de la boutique</label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                  className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                    isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-800 border-neutral-700 text-white'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold block mb-1">Lien public boutique</label>
              <div className="relative">
                <LinkIcon className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={publicUrl}
                  onChange={(e) => setPublicUrl(e.target.value)}
                  required
                  className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                    isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-800 border-neutral-700 text-white'
                  }`}
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-sm shadow-xl shadow-yellow-500/15 transition flex items-center justify-center gap-2 active:scale-98"
          >
            {isSaved ? <Check className="w-5 h-5 text-black" /> : <Sparkles className="w-4 h-4" />}
            <span>{isSaved ? 'Modifications enregistrées !' : 'Enregistrer le profil entreprise'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
