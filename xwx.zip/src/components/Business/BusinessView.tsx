import React, { useState } from 'react';
import { 
  Home, 
  Receipt, 
  Bike, 
  User, 
  RotateCw, 
  Store, 
  Lock, 
  Unlock, 
  Package, 
  Shapes, 
  Clock, 
  Wallet, 
  TrendingUp, 
  Star, 
  ShoppingBag, 
  Calendar, 
  Banknote,
  ChevronRight,
  Plus,
  Repeat,
  ChevronDown,
  Check,
  Building2,
  ExternalLink
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';
import { BusinessProductsModal } from './BusinessProductsModal';
import { BusinessCategoriesModal } from './BusinessCategoriesModal';
import { BusinessHoursModal } from './BusinessHoursModal';
import { BusinessBalanceModal } from './BusinessBalanceModal';
import { BusinessEarningsModal } from './BusinessEarningsModal';
import { BusinessEditProfileModal } from './BusinessEditProfileModal';
import { RequestCourierView } from './RequestCourierView';
import { BusinessOrdersView } from './BusinessOrdersView';
import { BusinessProfileView } from './BusinessProfileView';
import { BusinessListView } from './BusinessListView';
import { BusinessShowcaseView } from './BusinessShowcaseView';
import { NewBusinessModal } from './NewBusinessModal';
import { NoBusinessLinkedView } from './NoBusinessLinkedView';
import { useTranslation } from '../../utils/i18n';

interface BusinessViewProps {
  onSwitchMode?: () => void;
  onOpenSupport?: () => void;
}

export const BusinessView: React.FC<BusinessViewProps> = ({ onSwitchMode, onOpenSupport }) => {
  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const allBusinesses = vtcStore.getAllBusinesses();
  const courierRequests = vtcStore.getCourierRequests();
  const { lang, t } = useTranslation();

  // Active view tab:
  // 1. 'home': Tableau de bord magasin (Vue 1)
  // 2. 'businesses': Gestionnaire Multi-Commerces & Vitrines (Vue 2 avec bouton +)
  // 3. 'products': Vitrine Produit & Catalogue (Vue 3 avec bouton +)
  // 4. 'orders': Commandes
  // 5. 'request': Demande de coursier
  // 6. 'profile': Profil & réglages
  const [activeTab, setActiveTab] = useState<'home' | 'businesses' | 'products' | 'orders' | 'request' | 'profile'>('home');

  // Subview Modals
  const [isProductsModalOpen, setIsProductsModalOpen] = useState(false);
  const [isCategoriesOpen, setIsCategoriesOpen] = useState(false);
  const [isHoursOpen, setIsHoursOpen] = useState(false);
  const [isBalanceOpen, setIsBalanceOpen] = useState(false);
  const [isEarningsOpen, setIsEarningsOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isNewBusinessModalOpen, setIsNewBusinessModalOpen] = useState(false);

  // Business Switcher Dropdown in Top Bar
  const [isStoreSwitcherOpen, setIsStoreSwitcherOpen] = useState(false);

  const activeOrdersCount = courierRequests.filter(r => r.status === 'PENDING' || r.status === 'ACCEPTED' || r.status === 'IN_TRANSIT').length;
  const productsCount = business.products?.length || 0;

  // If no business linked at all, render NoBusinessLinkedView (View 4)
  if (allBusinesses.length === 0) {
    return (
      <div className="h-full w-full">
        <NoBusinessLinkedView
          onRequestNewBusiness={() => setIsNewBusinessModalOpen(true)}
          onContactSupport={() => {
            if (onOpenSupport) onOpenSupport();
            else alert('Pour toute assistance, contactez le support SOMED à contact@somed.biz');
          }}
          onSwitchToRider={() => vtcStore.setRole('PASSENGER')}
          onSwitchToDriver={() => vtcStore.setRole('DRIVER')}
          onLogout={() => {
            try {
              sessionStorage.removeItem('somed_authenticated_session');
              localStorage.removeItem('somed_authenticated');
            } catch {}
            window.location.reload();
          }}
        />

        <NewBusinessModal
          isOpen={isNewBusinessModalOpen}
          onClose={() => setIsNewBusinessModalOpen(false)}
          onCreated={() => {
            setIsNewBusinessModalOpen(false);
            setActiveTab('home');
          }}
        />
      </div>
    );
  }

  return (
    <div className={`relative h-full w-full flex flex-col overflow-hidden select-none transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
    }`}>
      {/* Subview Modals */}
      <BusinessProductsModal
        isOpen={isProductsModalOpen}
        onClose={() => setIsProductsModalOpen(false)}
      />

      <BusinessCategoriesModal
        isOpen={isCategoriesOpen}
        onClose={() => setIsCategoriesOpen(false)}
      />

      <BusinessHoursModal
        isOpen={isHoursOpen}
        onClose={() => setIsHoursOpen(false)}
      />

      <BusinessBalanceModal
        isOpen={isBalanceOpen}
        onClose={() => setIsBalanceOpen(false)}
      />

      <BusinessEarningsModal
        isOpen={isEarningsOpen}
        onClose={() => setIsEarningsOpen(false)}
      />

      <BusinessEditProfileModal
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
      />

      <NewBusinessModal
        isOpen={isNewBusinessModalOpen}
        onClose={() => setIsNewBusinessModalOpen(false)}
        onCreated={(newBizId) => {
          setIsNewBusinessModalOpen(false);
          vtcStore.setActiveBusiness(newBizId);
          setActiveTab('home');
        }}
      />

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 overflow-y-auto">
        {/* ================= VUE 1 : ACCUEIL / TABLEAU DE BORD (Home) ================= */}
        {activeTab === 'home' && (
          <div className="flex flex-col h-full overflow-y-auto">
            {/* Top Store Header with Interactive Business Switcher & Switch Mode */}
            <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-30 ${
              isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
            }`}>
              {/* Left: Active Business name with clickable Dropdown to switch or add (+) */}
              <div className="relative">
                <button
                  onClick={() => setIsStoreSwitcherOpen(!isStoreSwitcherOpen)}
                  className="flex items-center gap-2 hover:opacity-80 transition group text-left"
                  title="Sélectionner ou ajouter un commerce"
                >
                  <div className="w-8 h-8 rounded-xl bg-yellow-400/20 border border-yellow-400/50 flex items-center justify-center text-yellow-500 flex-shrink-0">
                    <Store className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h1 className="font-extrabold text-base tracking-tight truncate max-w-[140px] sm:max-w-[180px]">
                        {business.name}
                      </h1>
                      <ChevronDown className="w-4 h-4 text-neutral-400 group-hover:text-yellow-400 transition" />
                    </div>
                    <p className={`text-[10px] font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      {allBusinesses.length} commerce{allBusinesses.length > 1 ? 's' : ''} • {productsCount} produit{productsCount > 1 ? 's' : ''}
                    </p>
                  </div>
                </button>

                {/* Dropdown Menu of all businesses + Add Business button */}
                {isStoreSwitcherOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setIsStoreSwitcherOpen(false)} 
                    />
                    <div className={`absolute top-full left-0 mt-2 w-72 rounded-2xl border shadow-2xl z-50 p-2 space-y-1 animate-in fade-in zoom-in-95 duration-150 ${
                      isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
                    }`}>
                      <p className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                        Mes établissements ({allBusinesses.length})
                      </p>

                      <div className="max-h-56 overflow-y-auto space-y-1">
                        {allBusinesses.map((b) => {
                          const isSel = b.id === business.id;
                          return (
                            <button
                              key={b.id}
                              onClick={() => {
                                vtcStore.setActiveBusiness(b.id);
                                setIsStoreSwitcherOpen(false);
                              }}
                              className={`w-full p-2.5 rounded-xl flex items-center justify-between text-left text-xs font-bold transition ${
                                isSel
                                  ? 'bg-yellow-400 text-black shadow-sm'
                                  : isLight ? 'hover:bg-slate-100 text-slate-700' : 'hover:bg-neutral-900 text-neutral-300'
                              }`}
                            >
                              <div className="flex items-center gap-2 truncate">
                                <Store className="w-3.5 h-3.5 flex-shrink-0" />
                                <div className="truncate">
                                  <p className="truncate">{b.name}</p>
                                  <p className={`text-[9px] font-normal ${isSel ? 'text-black/80' : 'text-neutral-400'}`}>
                                    {b.products?.length || 0} produit(s) en vitrine
                                  </p>
                                </div>
                              </div>
                              {isSel && <Check className="w-3.5 h-3.5 stroke-[3] flex-shrink-0" />}
                            </button>
                          );
                        })}
                      </div>

                      {/* Add another business button inside dropdown */}
                      <div className="pt-1.5 border-t border-neutral-800">
                        <button
                          onClick={() => {
                            setIsStoreSwitcherOpen(false);
                            setIsNewBusinessModalOpen(true);
                          }}
                          className="w-full py-2.5 px-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-sm"
                        >
                          <Plus className="w-3.5 h-3.5 stroke-[3]" />
                          <span>Ajouter un nouveau commerce</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Right: Switch Mode & Actions */}
              <div className="flex items-center gap-2">
                {/* Switch Mode Button */}
                {onSwitchMode && (
                  <button
                    onClick={onSwitchMode}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 bg-yellow-400 hover:bg-yellow-300 text-black shadow-md shadow-yellow-400/20"
                    title="Changer de mode (Passager / Chauffeur / Business)"
                  >
                    <Repeat className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Switch mode</span>
                  </button>
                )}

                {/* Refresh */}
                <button
                  onClick={() => vtcStore.notify()}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition active:rotate-180 ${
                    isLight ? 'hover:bg-slate-100 text-slate-600' : 'hover:bg-neutral-900 text-neutral-400'
                  }`}
                  title="Rafraîchir"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
              </div>
            </header>

            {/* Dashboard Content */}
            <div className="p-5 space-y-4 max-w-lg mx-auto w-full pb-24">
              {/* Store Status Card with Big Red/Green Button */}
              <div className={`p-4 rounded-3xl border space-y-3.5 shadow-sm ${
                isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
              }`}>
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
                    business.isOpen ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'
                  }`}>
                    <Store className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${business.isOpen ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                      <span>{business.isOpen ? t('bizOpenStore') : t('bizClosedStore')}</span>
                    </h3>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      {business.isOpen ? t('bizOpenDesc') : t('bizClosedDesc')}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => vtcStore.toggleBusinessOpen()}
                  className={`w-full py-3.5 px-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition active:scale-98 shadow-md ${
                    business.isOpen
                      ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/20'
                      : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/20'
                  }`}
                >
                  {business.isOpen ? (
                    <>
                      <Lock className="w-4 h-4" />
                      <span>{t('bizCloseNow')}</span>
                    </>
                  ) : (
                    <>
                      <Unlock className="w-4 h-4" />
                      <span>{t('bizOpenNow')}</span>
                    </>
                  )}
                </button>
              </div>

              {/* 4 Metric Cards */}
              <div className="grid grid-cols-2 gap-3">
                {/* Active orders */}
                <div 
                  onClick={() => setActiveTab('orders')}
                  className={`p-4 rounded-2xl border transition cursor-pointer hover:border-yellow-400 ${
                    isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                  }`}
                >
                  <Receipt className="w-5 h-5 text-yellow-400 mb-2" />
                  <p className="text-2xl font-black">{activeOrdersCount}</p>
                  <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('bizActiveOrders')}</p>
                </div>

                {/* Today's orders */}
                <div 
                  onClick={() => setActiveTab('orders')}
                  className={`p-4 rounded-2xl border transition cursor-pointer hover:border-yellow-400 ${
                    isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                  }`}
                >
                  <ShoppingBag className="w-5 h-5 text-blue-400 mb-2" />
                  <p className="text-2xl font-black">{business.todayOrders || 0}</p>
                  <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('bizTodayOrders')}</p>
                </div>

                {/* Today's revenue */}
                <div 
                  onClick={() => setIsBalanceOpen(true)}
                  className={`p-4 rounded-2xl border transition cursor-pointer hover:border-yellow-400 ${
                    isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                  }`}
                >
                  <TrendingUp className="w-5 h-5 text-emerald-400 mb-2" />
                  <p className="text-2xl font-black">{formatEuro(business.balance || 0)}</p>
                  <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('bizAvailableBalance')}</p>
                </div>

                {/* Rating */}
                <div 
                  onClick={() => setIsEarningsOpen(true)}
                  className={`p-4 rounded-2xl border transition cursor-pointer hover:border-yellow-400 ${
                    isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                  }`}
                >
                  <Star className="w-5 h-5 text-amber-400 fill-amber-400 mb-2" />
                  <p className="text-2xl font-black">{business.rating ? business.rating.toFixed(1) : '5.0'}</p>
                  <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('bizStoreRating')}</p>
                </div>
              </div>

              {/* ACTION TILES: Quick jump to the 3 views and management tools */}
              <div className="space-y-2.5 pt-1">
                <div className="flex items-center justify-between px-1">
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-neutral-400">
                    {t('bizBusinessesTitle')}
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {/* TILE 1: Vitrine Produits (Vue 3 avec bouton +) */}
                  <div
                    onClick={() => setActiveTab('products')}
                    className={`p-4 rounded-2xl border transition text-left cursor-pointer group flex flex-col justify-between ${
                      isLight 
                        ? 'bg-purple-50/60 border-purple-200 hover:border-purple-400' 
                        : 'bg-purple-950/20 border-purple-900/50 hover:border-purple-500'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400">
                        <ShoppingBag className="w-5 h-5" />
                      </div>
                      <span className="w-6 h-6 rounded-lg bg-yellow-400 text-black flex items-center justify-center font-black text-xs shadow-sm">
                        +
                      </span>
                    </div>
                    <div>
                      <h4 className="font-black text-sm">{t('bizProductShowcase')}</h4>
                      <p className={`text-xs mt-0.5 ${isLight ? 'text-purple-700' : 'text-purple-300'}`}>
                        {productsCount} {t('bizProductsCount')}
                      </p>
                    </div>
                  </div>

                  {/* TILE 2: Mes Commerces (Vue 2 avec bouton +) */}
                  <div
                    onClick={() => setActiveTab('businesses')}
                    className={`p-4 rounded-2xl border transition text-left cursor-pointer group flex flex-col justify-between ${
                      isLight 
                        ? 'bg-amber-50/60 border-amber-200 hover:border-amber-400' 
                        : 'bg-yellow-950/20 border-yellow-900/50 hover:border-yellow-500'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl bg-yellow-400/20 flex items-center justify-center text-yellow-500">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <span className="w-6 h-6 rounded-lg bg-yellow-400 text-black flex items-center justify-center font-black text-xs shadow-sm">
                        +
                      </span>
                    </div>
                    <div>
                      <h4 className="font-black text-sm">{t('bizMyBusinesses')}</h4>
                      <p className={`text-xs mt-0.5 ${isLight ? 'text-amber-700' : 'text-yellow-300'}`}>
                        {allBusinesses.length} {t('bizBusinesses').toLowerCase()}
                      </p>
                    </div>
                  </div>

                  {/* TILE 3: Horaires */}
                  <button
                    onClick={() => setIsHoursOpen(true)}
                    className={`p-4 rounded-2xl border transition text-left group ${
                      isLight ? 'bg-white border-slate-200 hover:border-yellow-400' : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
                    }`}
                  >
                    <Clock className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400 mb-2 transition" />
                    <h4 className="font-bold text-sm">{t('bizHours')}</h4>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('bizHoursDesc')}</p>
                  </button>

                  {/* TILE 4: Caisse & Solde */}
                  <button
                    onClick={() => setIsBalanceOpen(true)}
                    className={`p-4 rounded-2xl border transition text-left group ${
                      isLight ? 'bg-white border-slate-200 hover:border-yellow-400' : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
                    }`}
                  >
                    <Wallet className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400 mb-2 transition" />
                    <h4 className="font-bold text-sm">{t('bizCashBalance')}</h4>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('bizCashDesc')}</p>
                  </button>

                  {/* TILE 5: Catégories */}
                  <button
                    onClick={() => setIsCategoriesOpen(true)}
                    className={`p-4 rounded-2xl border transition text-left group ${
                      isLight ? 'bg-white border-slate-200 hover:border-yellow-400' : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
                    }`}
                  >
                    <Shapes className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400 mb-2 transition" />
                    <h4 className="font-bold text-sm">{t('bizCategories')}</h4>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('bizCategoriesDesc')}</p>
                  </button>

                  {/* TILE 6: Demander un coursier */}
                  <button
                    onClick={() => setActiveTab('request')}
                    className={`p-4 rounded-2xl border transition text-left group ${
                      isLight ? 'bg-white border-slate-200 hover:border-yellow-400' : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
                    }`}
                  >
                    <Bike className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400 mb-2 transition" />
                    <h4 className="font-bold text-sm">{t('bizRequestCourier')}</h4>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('bizCourierDesc')}</p>
                  </button>
                </div>
              </div>

              {/* Recent Orders Section */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-neutral-400">{t('bizRecentOrders')}</h3>
                  <button 
                    onClick={() => setActiveTab('orders')}
                    className="text-xs font-bold text-yellow-500 hover:underline flex items-center gap-1"
                  >
                    <span>{t('seeAll')}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="space-y-2">
                  {courierRequests.slice(0, 3).map((req) => (
                    <div
                      key={req.id}
                      onClick={() => setActiveTab('orders')}
                      className={`p-3.5 rounded-2xl border transition flex items-center justify-between cursor-pointer ${
                        isLight ? 'bg-white border-slate-200 hover:border-slate-300' : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-yellow-400/10 text-yellow-500 flex items-center justify-center font-black text-xs">
                          {req.id.slice(-3)}
                        </div>
                        <div>
                          <p className="font-bold text-xs">{req.customerName}</p>
                          <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{req.customerAddress}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-black text-xs">{formatEuro(req.orderValue)}</p>
                        <span className={`inline-block text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          req.status === 'DELIVERED' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                        }`}>
                          {req.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= VUE 2 : MES COMMERCES & GESTIONNAIRE MULTI-BUSINESS (Vue 2 avec bouton +) ================= */}
        {activeTab === 'businesses' && (
          <BusinessListView
            onSelectBusiness={(businessId) => {
              vtcStore.setActiveBusiness(businessId);
            }}
            onOpenVitrine={(businessId) => {
              vtcStore.setActiveBusiness(businessId);
              setActiveTab('products');
            }}
            onOpenNewBusinessModal={() => setIsNewBusinessModalOpen(true)}
            onOpenEditProfile={(businessId) => {
              vtcStore.setActiveBusiness(businessId);
              setIsEditProfileOpen(true);
            }}
          />
        )}

        {/* ================= VUE 3 : VITRINE PRODUITS & CATALOGUE (Vue 3 avec bouton +) ================= */}
        {activeTab === 'products' && (
          <BusinessShowcaseView
            onSwitchToBusinessList={() => setActiveTab('businesses')}
            onOpenNewBusinessModal={() => setIsNewBusinessModalOpen(true)}
          />
        )}

        {/* ================= ORDERS TAB ================= */}
        {activeTab === 'orders' && (
          <BusinessOrdersView />
        )}

        {/* ================= REQUEST COURIER TAB ================= */}
        {activeTab === 'request' && (
          <RequestCourierView onSuccess={() => setActiveTab('orders')} />
        )}

        {/* ================= PROFILE TAB ================= */}
        {activeTab === 'profile' && (
          <BusinessProfileView
            onOpenProducts={() => setActiveTab('products')}
            onOpenCategories={() => setIsCategoriesOpen(true)}
            onOpenHours={() => setIsHoursOpen(true)}
            onOpenBalance={() => setIsBalanceOpen(true)}
            onOpenEarnings={() => setIsEarningsOpen(true)}
            onSwitchMode={() => {
              if (onSwitchMode) {
                onSwitchMode();
              } else {
                vtcStore.setRole('PASSENGER');
              }
            }}
          />
        )}
      </div>

      {/* BOTTOM TAB BAR FOR BUSINESS (5 TABS: Home, Commerces, Vitrine, Commandes, Profil) */}
      <nav className={`h-16 border-t px-3 flex items-center justify-around flex-shrink-0 z-30 select-none shadow-2xl transition-colors ${
        isLight ? 'bg-white border-slate-200' : 'bg-black border-neutral-900'
      }`}>
        {[
          { id: 'home', label: t('bizHome'), icon: Home },
          { id: 'businesses', label: t('bizBusinesses'), icon: Building2, badge: allBusinesses.length },
          { id: 'products', label: t('bizShowcase'), icon: ShoppingBag, badge: productsCount },
          { id: 'orders', label: t('bizOrders'), icon: Receipt, badge: activeOrdersCount > 0 ? activeOrdersCount : undefined },
          { id: 'profile', label: t('bizProfile'), icon: User },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className="flex flex-col items-center justify-center gap-1 py-1 px-2.5 relative transition active:scale-95 group flex-1"
            >
              {isActive ? (
                <div className="w-11 h-7 rounded-full bg-yellow-400 flex items-center justify-center transition-all shadow-md shadow-yellow-400/20">
                  <Icon className="w-4 h-4 text-black stroke-[2.5]" />
                </div>
              ) : (
                <div className={`w-11 h-7 flex items-center justify-center relative transition ${
                  isLight ? 'text-slate-400 group-hover:text-black' : 'text-neutral-400 group-hover:text-white'
                }`}>
                  <Icon className="w-5 h-5 stroke-[1.8]" />
                  {typeof tab.badge === 'number' && tab.badge > 0 && (
                    <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full bg-yellow-400 text-black text-[9px] font-black">
                      {tab.badge}
                    </span>
                  )}
                </div>
              )}
              <span className={`text-[10px] font-semibold transition truncate max-w-[55px] ${
                isActive 
                  ? 'text-yellow-400 font-bold' 
                  : isLight ? 'text-slate-500' : 'text-neutral-400 group-hover:text-neutral-200'
              }`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};
