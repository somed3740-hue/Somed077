import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Building, 
  CreditCard, 
  TrendingUp, 
  ShoppingBag, 
  ArrowUpRight, 
  ArrowDownLeft, 
  X,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';

interface BusinessBalanceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BusinessBalanceModal: React.FC<BusinessBalanceModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const transactions = business.transactions || [];

  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawNotice, setWithdrawNotice] = useState<string | null>(null);

  const [isTopUpOpen, setIsTopUpOpen] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState('');
  const [topUpReference, setTopUpReference] = useState('');
  const [topUpNotice, setTopUpNotice] = useState<string | null>(null);

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(withdrawAmount);
    if (isNaN(val) || val <= 0) return;

    const res = vtcStore.withdrawBusinessBalance(val);
    if (res.success) {
      setWithdrawNotice(res.message);
      setTimeout(() => {
        setIsWithdrawOpen(false);
        setWithdrawNotice(null);
        setWithdrawAmount('');
      }, 1200);
    } else {
      setWithdrawNotice(res.message);
    }
  };

  const handleTopUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(topUpAmount);
    if (isNaN(val) || val <= 0) return;

    const res = vtcStore.topUpBusinessBalance(val, topUpReference.trim() || undefined);
    if (res.success) {
      setTopUpNotice(res.message);
      setTimeout(() => {
        setIsTopUpOpen(false);
        setTopUpNotice(null);
        setTopUpAmount('');
        setTopUpReference('');
      }, 1200);
    } else {
      setTopUpNotice(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-[1300] flex flex-col select-none animate-in fade-in duration-200">
      <div className={`h-full w-full flex flex-col overflow-hidden transition-colors ${
        isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
      }`}>
        {/* Top Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">Balance</h2>
          <div className="w-9" />
        </header>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 max-w-lg mx-auto w-full">
          {/* Big Yellow Available Balance Card (Screenshot 8) */}
          <div className="bg-yellow-400 text-black rounded-3xl p-6 shadow-xl space-y-5">
            <div className="text-center">
              <p className="text-xs font-bold uppercase tracking-wider text-black/70">
                Available balance
              </p>
              <h1 className="text-4xl font-black mt-1">
                {formatEuro(business.balance)}
              </h1>
            </div>

            {/* Action buttons (Request withdrawal / Top up) */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => {
                  setWithdrawAmount(business.balance > 0 ? business.balance.toString() : '');
                  setIsWithdrawOpen(true);
                }}
                className="py-3 px-3 rounded-2xl bg-black/10 hover:bg-black/15 text-black border border-black/20 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95"
              >
                <Building className="w-4 h-4" />
                <span>Request withdrawal</span>
              </button>

              <button
                onClick={() => setIsTopUpOpen(true)}
                className="py-3 px-3 rounded-2xl bg-black/10 hover:bg-black/15 text-black border border-black/20 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95"
              >
                <CreditCard className="w-4 h-4" />
                <span>Top up</span>
              </button>
            </div>
          </div>

          {/* Metric cards (Week & Orders) */}
          <div className="grid grid-cols-2 gap-3">
            <div className={`p-4 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <div className="flex items-center gap-2 text-emerald-500 mb-1">
                <TrendingUp className="w-4 h-4" />
              </div>
              <p className="text-lg font-bold">{formatEuro(business.todaySales)}</p>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>Week</p>
            </div>

            <div className={`p-4 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <div className="flex items-center gap-2 text-sky-400 mb-1">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <p className="text-lg font-bold">{business.todayOrders}</p>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>Orders</p>
            </div>
          </div>

          {/* Total Sales Breakdown (Screenshot 8) */}
          <div className={`p-5 rounded-2xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
          }`}>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Total sales
            </h3>

            <div className="flex justify-between items-center text-sm">
              <span className={isLight ? 'text-slate-600' : 'text-neutral-300'}>My earnings</span>
              <span className="font-bold text-emerald-500">{formatEuro(business.balance)}</span>
            </div>

            <div className="flex justify-between items-center text-sm">
              <span className={isLight ? 'text-slate-600' : 'text-neutral-300'}>Commissions</span>
              <span className="font-bold text-rose-500">-{formatEuro(business.commissions || 0)}</span>
            </div>

            <div className="flex justify-between items-center text-sm">
              <span className={isLight ? 'text-slate-600' : 'text-neutral-300'}>Withdrawals</span>
              <span className="font-bold">-{formatEuro(business.withdrawals || 0)}</span>
            </div>
          </div>

          {/* Transactions List (Screenshot 8: Pago de pedido +€6.40 17/09/2026 17:24) */}
          <div className={`p-5 rounded-2xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
          }`}>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Transactions
            </h3>

            <div className="divide-y divide-neutral-900 dark:divide-neutral-900">
              {transactions.length === 0 ? (
                <p className={`text-xs py-3 text-center ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                  No transactions yet
                </p>
              ) : (
                transactions.map((tx) => (
                  <div key={tx.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                        tx.amount > 0 
                          ? 'bg-emerald-500/20 text-emerald-500' 
                          : 'bg-rose-500/20 text-rose-500'
                      }`}>
                        {tx.amount > 0 ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="font-bold text-xs">{tx.title}</p>
                        <p className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                          {tx.date} {tx.time}
                        </p>
                      </div>
                    </div>

                    <span className={`font-bold text-sm ${
                      tx.amount > 0 ? 'text-emerald-500' : 'text-slate-800 dark:text-neutral-200'
                    }`}>
                      {tx.amount > 0 ? `+${formatEuro(tx.amount)}` : formatEuro(tx.amount)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Withdrawal Modal (Screenshot 9) */}
        {isWithdrawOpen && (
          <div className="fixed inset-0 z-[1400] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md">
            <div className={`w-full max-w-sm rounded-t-3xl sm:rounded-3xl p-6 border shadow-2xl space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
            }`}>
              <div className="w-12 h-1.5 bg-neutral-700 rounded-full mx-auto sm:hidden mb-2" />
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base">Request withdrawal</h3>
                <button onClick={() => setIsWithdrawOpen(false)} className="text-neutral-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                Available balance: <strong className="text-yellow-500">{formatEuro(business.balance)}</strong>
              </p>

              <form onSubmit={handleWithdrawSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold">Amount to withdraw</label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="1"
                      max={business.balance}
                      required
                      placeholder="0.00"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      className={`w-full px-4 py-3 rounded-2xl border text-xl font-black ${
                        isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-yellow-400 text-white'
                      }`}
                    />
                    <span className="absolute right-4 top-3.5 font-bold text-neutral-400">EUR</span>
                  </div>
                </div>

                {/* Quick Presets */}
                <div className="grid grid-cols-4 gap-2">
                  {['100', '500', '1000', '5000'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setWithdrawAmount(preset)}
                      className={`py-2 rounded-xl text-xs font-bold border transition ${
                        isLight ? 'bg-slate-100 border-slate-200 hover:bg-slate-200' : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      €{preset}
                    </button>
                  ))}
                </div>

                {withdrawNotice && (
                  <p className="text-xs text-emerald-500 font-semibold text-center">{withdrawNotice}</p>
                )}

                <button
                  type="submit"
                  className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold rounded-2xl text-sm shadow-lg transition active:scale-95"
                >
                  Confirm withdrawal
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Top Up Modal (Screenshot 9) */}
        {isTopUpOpen && (
          <div className="fixed inset-0 z-[1400] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md">
            <div className={`w-full max-w-sm rounded-t-3xl sm:rounded-3xl p-6 border shadow-2xl space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
            }`}>
              <div className="w-12 h-1.5 bg-neutral-700 rounded-full mx-auto sm:hidden mb-2" />
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base">Top up</h3>
                <button onClick={() => setIsTopUpOpen(false)} className="text-neutral-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleTopUpSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold">Amount to deposit</label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="1"
                      required
                      placeholder="0.00"
                      value={topUpAmount}
                      onChange={(e) => setTopUpAmount(e.target.value)}
                      className={`w-full px-4 py-3 rounded-2xl border text-xl font-black ${
                        isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-yellow-400 text-white'
                      }`}
                    />
                    <span className="absolute right-4 top-3.5 font-bold text-neutral-400">EUR</span>
                  </div>
                </div>

                {/* Quick Presets */}
                <div className="grid grid-cols-4 gap-2">
                  {['100', '500', '1000', '5000'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setTopUpAmount(preset)}
                      className={`py-2 rounded-xl text-xs font-bold border transition ${
                        isLight ? 'bg-slate-100 border-slate-200 hover:bg-slate-200' : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      €{preset}
                    </button>
                  ))}
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold">Deposit reference (optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. Bank transfer ref #1234"
                    value={topUpReference}
                    onChange={(e) => setTopUpReference(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-medium ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                {topUpNotice && (
                  <p className="text-xs text-emerald-500 font-semibold text-center">{topUpNotice}</p>
                )}

                <button
                  type="submit"
                  className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold rounded-2xl text-sm shadow-lg transition active:scale-95"
                >
                  Request top-up
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
