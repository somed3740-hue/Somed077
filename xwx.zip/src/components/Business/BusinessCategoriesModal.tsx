import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Edit2, 
  Shapes, 
  X 
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { BusinessCategory } from '../../types/vtc';

interface BusinessCategoriesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BusinessCategoriesModal: React.FC<BusinessCategoriesModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const categories = business.categories || [];

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<BusinessCategory | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const handleOpenAdd = () => {
    setEditingCategory(null);
    setName('');
    setDescription('');
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (cat: BusinessCategory) => {
    setEditingCategory(cat);
    setName(cat.name);
    setDescription(cat.description);
    setIsDialogOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingCategory) {
      vtcStore.updateBusinessCategory(editingCategory.id, {
        name: name.trim(),
        description: description.trim(),
      });
    } else {
      vtcStore.addBusinessCategory({
        name: name.trim(),
        description: description.trim(),
      });
    }
    setIsDialogOpen(false);
  };

  return (
    <div className="fixed inset-0 z-[1300] flex flex-col select-none animate-in fade-in duration-200">
      <div className={`h-full w-full flex flex-col overflow-hidden transition-colors ${
        isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
      }`}>
        {/* Top Header (Screenshot 11) */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">Categories</h2>
          <div className="w-9" />
        </header>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3 max-w-lg mx-auto w-full relative">
          {categories.length === 0 ? (
            <div className={`p-8 text-center rounded-3xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <Shapes className="w-10 h-10 mx-auto text-neutral-500 mb-2" />
              <p className="font-bold text-sm">No categories yet</p>
              <p className={`text-xs mt-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Create categories to organize your store products.
              </p>
            </div>
          ) : (
            categories.map((cat) => (
              <div
                key={cat.id}
                className={`p-4 rounded-2xl border flex items-center justify-between gap-3 shadow-sm transition ${
                  isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-xl bg-yellow-400/20 text-yellow-400 border border-yellow-400/40 flex items-center justify-center font-bold flex-shrink-0">
                    <Shapes className="w-6 h-6 text-yellow-500" />
                  </div>
                  <div>
                    <h3 className="font-bold text-base leading-tight">{cat.name}</h3>
                    <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      {cat.description || 'fresh'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleOpenEdit(cat)}
                    className={`w-9 h-9 rounded-xl flex items-center justify-center transition ${
                      isLight ? 'hover:bg-slate-100 text-slate-600' : 'hover:bg-neutral-900 text-neutral-300'
                    }`}
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Delete category "${cat.name}"?`)) {
                        vtcStore.deleteBusinessCategory(cat.id);
                      }
                    }}
                    className="w-9 h-9 rounded-xl text-rose-500 hover:bg-rose-500/10 flex items-center justify-center transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Yellow Floating Action Button (+) (Screenshot 11) */}
        <div className="fixed bottom-6 right-6 z-30">
          <button
            onClick={handleOpenAdd}
            className="w-14 h-14 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black shadow-xl shadow-yellow-400/30 flex items-center justify-center transition active:scale-95"
            title="Add category"
          >
            <Plus className="w-7 h-7 stroke-[3]" />
          </button>
        </div>

        {/* Add/Edit Category Dialog */}
        {isDialogOpen && (
          <div className="fixed inset-0 z-[1400] flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
            <div className={`w-full max-w-sm rounded-3xl p-6 border shadow-2xl space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
            }`}>
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800/60">
                <h3 className="font-bold text-base">
                  {editingCategory ? 'Edit Category' : 'New Category'}
                </h3>
                <button 
                  onClick={() => setIsDialogOpen(false)}
                  className="w-7 h-7 rounded-full flex items-center justify-center text-neutral-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold">Category Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. fruits, bakery, drinks"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold">Description</label>
                  <input
                    type="text"
                    placeholder="e.g. fresh, organic..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium ${
                      isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsDialogOpen(false)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold border ${
                      isLight ? 'bg-slate-100 border-slate-300' : 'bg-neutral-900 border-neutral-800'
                    }`}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-xl text-xs shadow-lg"
                  >
                    Save Category
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
