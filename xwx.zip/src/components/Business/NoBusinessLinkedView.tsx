import React from 'react';
import { Store, Mail, Headphones, User, Car, LogOut, Plus } from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { useTranslation } from '../../utils/i18n';

interface NoBusinessLinkedViewProps {
  onRequestNewBusiness: () => void;
  onContactSupport: () => void;
  onSwitchToRider: () => void;
  onSwitchToDriver: () => void;
  onLogout: () => void;
}

export const NoBusinessLinkedView: React.FC<NoBusinessLinkedViewProps> = ({
  onRequestNewBusiness,
  onContactSupport,
  onSwitchToRider,
  onSwitchToDriver,
  onLogout,
}) => {
  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();
  const userEmail = passenger.email || 'chanvre450@gmail.com';
  const { lang, t } = useTranslation();

  return (
    <div className={`h-full w-full flex flex-col justify-between items-center p-6 select-none overflow-y-auto animate-in fade-in duration-300 transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
    }`}>
      {/* Top spacing */}
      <div className="w-full max-w-md pt-4" />

      {/* Main Center Content (Matches View 4) */}
      <div className="w-full max-w-md my-auto flex flex-col items-center text-center space-y-6">
        {/* SOMED Logo */}
        <div className="flex flex-col items-center">
          <div className="w-20 h-20 rounded-2xl bg-yellow-400/20 border-2 border-yellow-400 p-1 flex items-center justify-center shadow-xl shadow-yellow-500/20 mb-3">
            <img 
              src="/somed-logo.png" 
              alt="SOMED" 
              className="w-full h-full object-cover rounded-xl"
            />
          </div>
          <h2 className="text-xl font-black text-yellow-400 tracking-wider">
            {t('appName')}
          </h2>
        </div>

        {/* Big Store Icon */}
        <div className={`w-20 h-20 rounded-2xl border flex items-center justify-center shadow-md ${
          isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-neutral-900 border-neutral-800 text-white'
        }`}>
          <Store className="w-10 h-10 stroke-[1.8]" />
        </div>

        {/* Headings */}
        <div className="space-y-2">
          <h1 className="text-xl font-black tracking-tight">
            {t('bizNoBusinessLinked')}
          </h1>
          <p className={`text-xs sm:text-sm max-w-xs mx-auto leading-relaxed ${
            isLight ? 'text-slate-500' : 'text-neutral-400'
          }`}>
            {t('bizNoBusinessDesc')}
          </p>
        </div>

        {/* User Email Pill */}
        <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl border text-xs font-semibold shadow-inner ${
          isLight ? 'bg-white border-slate-200 text-slate-700' : 'bg-neutral-900/90 border-neutral-800 text-neutral-200'
        }`}>
          <Mail className="w-3.5 h-3.5 text-neutral-400" />
          <span className="font-mono">{userEmail}</span>
        </div>

        {/* Action Buttons Stack */}
        <div className="w-full space-y-3 pt-4">
          {/* 1. Request new business with + Button */}
          <button
            onClick={onRequestNewBusiness}
            className="w-full py-4 px-6 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-sm flex items-center justify-center gap-2.5 transition active:scale-[0.98] shadow-lg shadow-yellow-400/20 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <Store className="w-4 h-4 stroke-[2.5]" />
            <span>{t('bizRequestNewBusiness')}</span>
          </button>

          {/* 2. Contact support */}
          <button
            onClick={onContactSupport}
            className={`w-full py-3.5 px-6 rounded-2xl border text-yellow-400 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition active:scale-[0.98] cursor-pointer ${
              isLight ? 'bg-white border-slate-200 hover:bg-slate-100' : 'bg-neutral-950 hover:bg-neutral-900 border-neutral-800'
            }`}
          >
            <Headphones className="w-4 h-4 text-yellow-400" />
            <span>{t('support')}</span>
          </button>

          {/* 3. Grid: Switch to Rider & Switch to Driver */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              onClick={onSwitchToRider}
              className={`py-3 px-3 rounded-2xl border text-yellow-400 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-[0.98] cursor-pointer ${
                isLight ? 'bg-white border-slate-200 hover:bg-slate-100' : 'bg-neutral-950 hover:bg-neutral-900 border-neutral-800'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>{t('tabTaxi')} (Passager)</span>
            </button>

            <button
              onClick={onSwitchToDriver}
              className={`py-3 px-3 rounded-2xl border text-yellow-400 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-[0.98] cursor-pointer ${
                isLight ? 'bg-white border-slate-200 hover:bg-slate-100' : 'bg-neutral-950 hover:bg-neutral-900 border-neutral-800'
              }`}
            >
              <Car className="w-3.5 h-3.5" />
              <span>{t('driverCockpit')} (Chauffeur)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Log out link */}
      <div className="w-full max-w-md text-center pt-6 pb-2">
        <button
          onClick={onLogout}
          className="text-xs font-bold text-rose-500 hover:text-rose-400 flex items-center justify-center gap-1.5 mx-auto transition active:scale-95 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>{t('logout')}</span>
        </button>
      </div>
    </div>
  );
};
