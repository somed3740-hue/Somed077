import React, { useState } from 'react';
import { 
  Edit3, 
  Mail, 
  Phone, 
  MapPin, 
  Link, 
  Package, 
  Shapes, 
  Clock, 
  Wallet, 
  TrendingUp, 
  Building2, 
  Globe, 
  Sun, 
  Moon, 
  Smartphone, 
  Repeat, 
  LogOut, 
  ChevronRight,
  Star,
  Check,
  Copy,
  Camera
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';
import { BusinessEditProfileModal } from './BusinessEditProfileModal';
import { LanguageModal } from '../Modals/LanguageModal';
import { useTranslation, SUPPORTED_LANGUAGES, Language } from '../../utils/i18n';
import { soundEffects } from '../../utils/audio';

interface BusinessProfileViewProps {
  onOpenProducts: () => void;
  onOpenCategories: () => void;
  onOpenHours: () => void;
  onOpenBalance: () => void;
  onOpenEarnings: () => void;
  onSwitchMode: () => void;
}

export const BusinessProfileView: React.FC<BusinessProfileViewProps> = ({
  onOpenProducts,
  onOpenCategories,
  onOpenHours,
  onOpenBalance,
  onOpenEarnings,
  onSwitchMode,
}) => {
  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const passenger = vtcStore.getPassenger();
  const { lang, t, setLanguage } = useTranslation();
  const [isLangModalOpen, setIsLangModalOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isEditingInfo, setIsEditingInfo] = useState(false);
  const [editName, setEditName] = useState(business.name);
  const [editEmail, setEditEmail] = useState(business.email);
  const [editPhone, setEditPhone] = useState(business.phone);
  const [editAddress, setEditAddress] = useState(business.address);

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(window.location.origin + business.publicUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSelectLanguage = (code: Language) => {
    soundEffects.playClick();
    setLanguage(code);

    const labels: Record<Language, string> = {
      fr: 'Français activé pour toute l’application',
      en: 'English activated across all interfaces',
      es: 'Español activado en todas las interfaces',
    };

    vtcStore.sendPushNotification({
      title: t('language'),
      body: labels[code],
      category: 'SYSTEM',
      badge: code.toUpperCase(),
    });
  };

  return (
    <div className={`h-full w-full flex flex-col select-none overflow-y-auto transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
    }`}>
      {/* Top Header */}
      <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 sticky top-0 backdrop-blur-md z-20 ${
        isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
      }`}>
        <div className="w-8" />
        <h2 className="font-bold text-base">{t('bizProfile')}</h2>
        <button
          onClick={() => setIsEditingInfo(true)}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition ${
            isLight ? 'hover:bg-slate-100 text-slate-700' : 'hover:bg-neutral-900 text-neutral-300'
          }`}
          title={t('edit')}
        >
          <Edit3 className="w-4 h-4" />
        </button>
      </header>

      {/* Main Profile Content */}
      <div className="flex-1 max-w-lg mx-auto w-full p-5 space-y-4 pb-28">
        {/* Banner with Birds & Avatar */}
        <div className={`rounded-3xl border overflow-hidden shadow-lg ${
          isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
        }`}>
          {/* Banner Graphic Header with Customization */}
          <div className="h-32 bg-neutral-900 relative overflow-hidden group">
            {business.bannerUrl ? (
              <img
                src={business.bannerUrl}
                alt="Banner"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-slate-800" />
            )}
            <button
              onClick={() => setIsEditingInfo(true)}
              className="absolute top-3 right-3 px-2.5 py-1 rounded-xl bg-black/70 hover:bg-black/90 text-white text-[10px] font-bold backdrop-blur-md border border-white/20 flex items-center gap-1 transition shadow-lg active:scale-95"
              title={t('bizCoverPhoto')}
            >
              <Camera className="w-3 h-3 text-yellow-400" />
              <span>{t('bizCoverPhoto')}</span>
            </button>
          </div>

          {/* Business Info Header with Customizable Avatar */}
          <div className="p-5 pt-0 relative flex items-end gap-3.5 -mt-7">
            <div 
              onClick={() => setIsEditingInfo(true)}
              className="relative w-16 h-16 rounded-full bg-yellow-400 border-4 border-black p-0.5 overflow-hidden shadow-2xl flex-shrink-0 cursor-pointer group"
              title={t('bizProfilePhoto')}
            >
              <img
                src={business.avatarUrl}
                alt={business.name}
                className="w-full h-full object-cover rounded-full"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-full">
                <Camera className="w-4 h-4 text-white" />
              </div>
            </div>

            <div className="flex-1 min-w-0 pb-1">
              <div className="flex items-center gap-1.5">
                <h1 className="font-extrabold text-lg leading-tight truncate">{business.name}</h1>
                <span className="text-[10px] font-bold bg-yellow-400 text-black px-1.5 py-0.2 rounded font-mono">
                  ★ {business.rating.toFixed(1)}
                </span>
              </div>
              <p className={`text-xs truncate font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                {business.categories.join(', ')}
              </p>
            </div>
          </div>

          {/* Business Details Rows */}
          <div className={`p-5 pt-0 space-y-2 text-xs border-t ${
            isLight ? 'border-slate-100 text-slate-600' : 'border-neutral-900 text-neutral-400'
          }`}>
            <div className="flex items-center gap-2 pt-3">
              <MapPin className="w-3.5 h-3.5 text-yellow-500 flex-shrink-0" />
              <span className="truncate">{business.address}</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-yellow-500 flex-shrink-0" />
              <span>{business.phone}</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-yellow-500 flex-shrink-0" />
              <span>{business.email}</span>
            </div>

            {/* Public Storefront Link with One-click Copy */}
            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={handleCopyLink}
                className={`flex-1 py-2 px-3 rounded-xl border flex items-center justify-center gap-1.5 font-bold transition active:scale-95 ${
                  copiedLink
                    ? 'bg-emerald-500 text-white border-emerald-500 shadow-md'
                    : isLight 
                    ? 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-800' 
                    : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-white'
                }`}
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Lien copié ✓' : 'Partager la vitrine'}</span>
              </button>

              <button
                onClick={() => setIsEditingInfo(true)}
                className="py-2 px-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs transition active:scale-95"
              >
                {t('edit')}
              </button>
            </div>
          </div>
        </div>

        {/* Business Settings Menu Items */}
        <div className={`rounded-3xl border divide-y overflow-hidden ${
          isLight ? 'bg-white border-slate-200 divide-slate-100' : 'bg-neutral-950 border-neutral-900 divide-neutral-900'
        }`}>
          <button
            onClick={onOpenProducts}
            className={`w-full p-4 flex items-center justify-between transition group text-left ${
              isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <Package className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400" />
              <div>
                <span className="font-bold text-sm">{t('bizProductShowcase')}</span>
                <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {business.products.length} {t('bizProductsCount')}
                </p>
              </div>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
          </button>

          <button
            onClick={onOpenCategories}
            className={`w-full p-4 flex items-center justify-between transition group text-left ${
              isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <Shapes className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400" />
              <div>
                <span className="font-bold text-sm">{t('bizCategories')}</span>
                <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {business.categories.length} {t('bizCategories')}
                </p>
              </div>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
          </button>

          <button
            onClick={onOpenHours}
            className={`w-full p-4 flex items-center justify-between transition group text-left ${
              isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <Clock className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400" />
              <div>
                <span className="font-bold text-sm">{t('bizHours')}</span>
                <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {t('bizHoursDesc')}
                </p>
              </div>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
          </button>

          <button
            onClick={onOpenBalance}
            className={`w-full p-4 flex items-center justify-between transition group text-left ${
              isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <Wallet className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400" />
              <div>
                <span className="font-bold text-sm">{t('bizCashBalance')}</span>
                <p className="text-[11px] font-extrabold text-yellow-500">{formatEuro(business.balance)}</p>
              </div>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
          </button>

          <button
            onClick={onOpenEarnings}
            className={`w-full p-4 flex items-center justify-between transition group text-left ${
              isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <TrendingUp className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400" />
              <span className="font-bold text-sm">{t('driverTodayEarnings')}</span>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
          </button>
        </div>

        {/* ================= SECTION LANGUE DE L'APPLICATION (Français, Anglais, Espagnol) ================= */}
        <div className={`p-5 rounded-3xl border space-y-3 ${
          isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center">
                <Globe className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm">{t('language')}</h3>
                <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {t('languageSubtitle')}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsLangModalOpen(true)}
              className="text-[10px] font-black px-2 py-0.5 rounded-full bg-yellow-400 text-black uppercase cursor-pointer"
            >
              {lang}
            </button>
          </div>

          {/* 3 Selectable Buttons: Français, English, Español */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            {SUPPORTED_LANGUAGES.map((item) => {
              const isSelected = lang === item.code;
              return (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => handleSelectLanguage(item.code)}
                  className={`p-3 rounded-2xl border flex flex-col items-center justify-center gap-1 transition active:scale-95 ${
                    isSelected
                      ? 'bg-yellow-400 border-yellow-400 text-black font-extrabold shadow-md shadow-yellow-400/20 ring-2 ring-yellow-400/30'
                      : isLight 
                      ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300' 
                      : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-900/80 hover:text-white'
                  }`}
                >
                  <span className="text-xl">{item.flag}</span>
                  <span className="text-xs font-bold">{item.name}</span>
                  {isSelected && (
                    <span className="text-[9px] bg-black text-yellow-400 px-1.5 py-0.2 rounded-full font-black flex items-center gap-0.5">
                      <Check className="w-2.5 h-2.5" /> {t('active')}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Appearance Section */}
        <div className="space-y-2">
          <p className={`text-xs font-semibold px-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
            {t('appearance')}
          </p>
          <div className={`grid grid-cols-3 gap-2 p-1.5 rounded-2xl border ${
            isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900 border-neutral-800'
          }`}>
            <button
              onClick={() => vtcStore.setAppearance('light')}
              className={`py-3 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 transition ${
                passenger.appearance === 'light'
                  ? 'bg-yellow-400 text-black shadow-md'
                  : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Sun className="w-4 h-4" />
              <span>{t('light')}</span>
            </button>

            <button
              onClick={() => vtcStore.setAppearance('dark')}
              className={`py-3 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 transition ${
                passenger.appearance === 'dark'
                  ? 'bg-yellow-400 text-black shadow-md'
                  : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Moon className="w-4 h-4" />
              <span>{t('dark')}</span>
            </button>

            <button
              onClick={() => vtcStore.setAppearance('auto')}
              className={`py-3 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 transition ${
                passenger.appearance === 'auto'
                  ? 'bg-yellow-400 text-black shadow-md'
                  : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>{t('auto')}</span>
            </button>
          </div>
        </div>

        {/* Switch Mode & Log Out */}
        <div className={`rounded-3xl border divide-y overflow-hidden ${
          isLight ? 'bg-white border-slate-200 divide-slate-100' : 'bg-neutral-950 border-neutral-900 divide-neutral-900'
        }`}>
          <button
            onClick={onSwitchMode}
            className={`w-full p-4 flex items-center justify-between transition group text-left ${
              isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Repeat className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm">{t('switchInterface')}</span>
                  <span className="text-[10px] font-bold bg-yellow-400 text-black px-1.5 py-0.2 rounded uppercase">
                    {t('active')}
                  </span>
                </div>
                <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Passager, Chauffeur, Business
                </p>
              </div>
            </div>
            <ChevronRight className={`w-4 h-4 group-hover:translate-x-0.5 transition-transform ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
          </button>

          <button
            onClick={() => {
              if (confirm('Voulez-vous quitter l’espace Business ?')) {
                vtcStore.setRole('PASSENGER');
              }
            }}
            className={`w-full p-4 flex items-center gap-3.5 text-left text-rose-500 font-bold text-sm transition ${
              isLight ? 'hover:bg-rose-50' : 'hover:bg-rose-950/20'
            }`}
          >
            <LogOut className="w-5 h-5" />
            <span>{t('logout')}</span>
          </button>
        </div>
      </div>

      {/* Business Edit Profile Modal */}
      <BusinessEditProfileModal
        isOpen={isEditingInfo}
        onClose={() => setIsEditingInfo(false)}
      />

      {/* Language Selection Modal */}
      <LanguageModal
        isOpen={isLangModalOpen}
        onClose={() => setIsLangModalOpen(false)}
      />
    </div>
  );
};
