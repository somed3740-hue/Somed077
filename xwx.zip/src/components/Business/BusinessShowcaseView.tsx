import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Plus, 
  Trash2, 
  Check, 
  Tag, 
  Store, 
  Image as ImageIcon,
  DollarSign,
  Eye,
  EyeOff,
  Sparkles,
  ChevronRight,
  Layers
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { BusinessProduct } from '../../types/vtc';
import { formatEuro } from '../../utils/geo';
import { useTranslation } from '../../utils/i18n';

interface BusinessShowcaseViewProps {
  onSwitchToBusinessList?: () => void;
  onOpenNewBusinessModal?: () => void;
}

const PRESET_PRODUCT_IMAGES = [
  { label: '🥐 Boulangerie & Viennoiserie', url: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&auto=format&fit=crop&q=80', cat: 'Boulangerie' },
  { label: '🍔 Burger Gourmet & Frites', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&auto=format&fit=crop&q=80', cat: 'Restauration' },
  { label: '🍕 Pizza Artisanale', url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&auto=format&fit=crop&q=80', cat: 'Restauration' },
  { label: '🍣 Plateaux Sushi & Maki', url: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=400&auto=format&fit=crop&q=80', cat: 'Restauration' },
  { label: '🍹 Smoothies & Cocktails', url: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=400&auto=format&fit=crop&q=80', cat: 'Boissons' },
  { label: '☕ Café & Boissons Chaudes', url: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&auto=format&fit=crop&q=80', cat: 'Boissons' },
  { label: '🍎 Fruits & Légumes Bio', url: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=400&auto=format&fit=crop&q=80', cat: 'Fruits & Légumes' },
  { label: '🍫 Chocolaterie & Épicerie Fine', url: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=400&auto=format&fit=crop&q=80', cat: 'Épicerie' },
  { label: '💐 Fleurs & Compositions', url: 'https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=400&auto=format&fit=crop&q=80', cat: 'Fleurs' },
  { label: '📱 Accessoires High-Tech', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&auto=format&fit=crop&q=80', cat: 'High-Tech' },
  { label: '💎 Parfumerie & Luxe', url: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?w=400&auto=format&fit=crop&q=80', cat: 'Mode & Luxe' },
];

export const BusinessShowcaseView: React.FC<BusinessShowcaseViewProps> = ({
  onSwitchToBusinessList,
  onOpenNewBusinessModal,
}) => {
  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const { lang, t } = useTranslation();
  const products = business.products || [];
  const categories = business.categories || [];

  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New product form state
  const [productName, setProductName] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productCategory, setProductCategory] = useState(categories[0]?.name || 'Plats');
  const [customCategory, setCustomCategory] = useState('');
  const [productDesc, setProductDesc] = useState('');
  const [productImg, setProductImg] = useState(PRESET_PRODUCT_IMAGES[0].url);
  const [customImgUrl, setCustomImgUrl] = useState('');

  const filteredProducts = selectedCategory === 'ALL'
    ? products
    : products.filter(p => p.category.toLowerCase() === selectedCategory.toLowerCase());

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseFloat(productPrice);
    if (!productName.trim() || isNaN(priceNum) || priceNum <= 0) return;

    const finalCategory = customCategory.trim() || productCategory;
    const finalImage = customImgUrl.trim() || productImg;

    vtcStore.addBusinessProduct({
      name: productName.trim(),
      price: priceNum,
      category: finalCategory,
      description: productDesc.trim() || undefined,
      imageUrl: finalImage,
      isAvailable: true,
    });

    // Reset form
    setProductName('');
    setProductPrice('');
    setProductDesc('');
    setCustomCategory('');
    setCustomImgUrl('');
    setIsAddModalOpen(false);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto select-none relative">
      {/* Top Header */}
      <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
        isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
      }`}>
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
            <ShoppingBag className="w-4 h-4" />
          </div>
          <div>
            <h1 className="font-extrabold text-base tracking-tight">{t('bizShowcaseTitle')}</h1>
            <p className={`text-[11px] flex items-center gap-1 font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              <Store className="w-3 h-3 text-yellow-500 inline" />
              <span>{business.name}</span>
              <span>• {products.length} {t('bizProductsCount')}</span>
            </p>
          </div>
        </div>

        {/* Primary + Button to add product to vitrine */}
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs transition active:scale-95 shadow-md shadow-yellow-400/20"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>{t('bizAddProduct')}</span>
        </button>
      </header>

      {/* Categories Horizontal Filter */}
      <div className={`px-5 py-3 border-b flex items-center gap-2 overflow-x-auto no-scrollbar flex-shrink-0 ${
        isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
      }`}>
        <button
          onClick={() => setSelectedCategory('ALL')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
            selectedCategory === 'ALL'
              ? 'bg-yellow-400 text-black shadow-sm'
              : isLight ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' : 'bg-neutral-900 text-neutral-300 hover:text-white'
          }`}
        >
          {selectedCategory === 'ALL' && <Check className="w-3 h-3 stroke-[3]" />}
          <span>{t('bizAllCategories')} ({products.length})</span>
        </button>

        {/* All distinct categories in products */}
        {Array.from(new Set(products.map(p => p.category).filter(Boolean))).map((cat) => {
          const count = products.filter(p => p.category.toLowerCase() === cat.toLowerCase()).length;
          const isSel = selectedCategory.toLowerCase() === cat.toLowerCase();
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                isSel
                  ? 'bg-yellow-400 text-black shadow-sm'
                  : isLight ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' : 'bg-neutral-900 text-neutral-300 hover:text-white'
              }`}
            >
              <span>{cat} ({count})</span>
            </button>
          );
        })}
      </div>

      {/* Main Content Showcase */}
      <div className="p-5 space-y-4 max-w-lg mx-auto w-full pb-28">
        {/* Banner with quick business switch link */}
        {onSwitchToBusinessList && (
          <div 
            onClick={onSwitchToBusinessList}
            className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition ${
              isLight ? 'bg-slate-50 border-slate-200 hover:border-yellow-400' : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Store className="w-4 h-4 text-yellow-500" />
              <span className="text-xs font-semibold">
                Vitrine active de : <strong className="text-yellow-400">{business.name}</strong>
              </span>
            </div>
            <div className="flex items-center gap-1 text-xs font-bold text-yellow-500">
              <span>Changer de commerce</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        )}

        {/* Product Cards List */}
        {filteredProducts.length === 0 ? (
          <div className={`p-8 rounded-3xl border text-center space-y-4 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
          }`}>
            <div className="w-16 h-16 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center mx-auto">
              <ShoppingBag className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-base">Aucun produit dans cette vitrine</h3>
              <p className={`text-xs max-w-xs mx-auto ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Ajoutez dès maintenant vos articles, plats ou produits avec photos et prix pour les afficher dans votre vitrine.
              </p>
            </div>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="py-3 px-6 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-sm inline-flex items-center gap-2 shadow-md shadow-yellow-400/20 active:scale-95 transition"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Ajouter mon premier produit</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {filteredProducts.map((p: BusinessProduct) => (
              <div
                key={p.id}
                className={`rounded-2xl border transition overflow-hidden shadow-sm flex flex-col justify-between ${
                  isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                }`}
              >
                {/* Product Photo */}
                <div className="h-36 w-full relative bg-neutral-900 overflow-hidden">
                  <img
                    src={p.imageUrl || PRESET_PRODUCT_IMAGES[0].url}
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                  <div className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded-lg bg-black/70 backdrop-blur-md text-white text-[10px] font-bold">
                    {p.category}
                  </div>

                  {/* Price Tag Badge */}
                  <div className="absolute bottom-2.5 right-2.5 px-2.5 py-1 rounded-xl bg-yellow-400 text-black text-xs font-black shadow-md">
                    {formatEuro(p.price)}
                  </div>
                </div>

                {/* Body Details */}
                <div className="p-3.5 space-y-2.5 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-black text-sm tracking-tight line-clamp-1">{p.name}</h4>
                    {p.description && (
                      <p className={`text-xs mt-1 line-clamp-2 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                        {p.description}
                      </p>
                    )}
                  </div>

                  {/* Action Bar */}
                  <div className="pt-2 border-t flex items-center justify-between border-neutral-800/40">
                    {/* Toggle Available */}
                    <button
                      onClick={() => vtcStore.updateBusinessProduct(p.id, { isAvailable: !p.isAvailable })}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition ${
                        p.isAvailable
                          ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/30'
                          : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                      }`}
                      title="Changer la disponibilité"
                    >
                      {p.isAvailable ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      <span>{p.isAvailable ? t('bizInShowcase') : t('bizHidden')}</span>
                    </button>

                    {/* Delete Product */}
                    <button
                      onClick={() => vtcStore.deleteBusinessProduct(p.id)}
                      className={`p-1.5 rounded-lg transition text-neutral-400 hover:text-rose-500 ${
                        isLight ? 'hover:bg-rose-50' : 'hover:bg-neutral-900'
                      }`}
                      title={t('delete')}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Big Yellow Add Product Banner Button */}
        <button
          onClick={() => setIsAddModalOpen(true)}
          className={`w-full p-4 rounded-3xl border-2 border-dashed transition flex items-center justify-center gap-2.5 group active:scale-[0.98] ${
            isLight
              ? 'border-yellow-400/80 bg-yellow-50/50 hover:bg-yellow-100/60 text-slate-800'
              : 'border-yellow-400/60 bg-yellow-400/5 hover:bg-yellow-400/10 text-white'
          }`}
        >
          <div className="w-8 h-8 rounded-xl bg-yellow-400 text-black flex items-center justify-center shadow-md">
            <Plus className="w-4 h-4 stroke-[3]" />
          </div>
          <span className="font-black text-sm text-yellow-500">{t('bizAddProduct')}</span>
        </button>
      </div>

      {/* ================= ADD PRODUCT MODAL ================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-[1500] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className={`w-full max-w-md rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] ${
            isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
          }`}>
            {/* Header */}
            <div className={`px-5 py-4 border-b flex items-center justify-between ${
              isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-neutral-900/60'
            }`}>
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-yellow-400" />
                <h3 className="font-extrabold text-base">Ajouter un produit</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-neutral-800 text-neutral-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            {/* Form Form */}
            <form onSubmit={handleCreateProduct} className="p-5 space-y-4 overflow-y-auto flex-1">
              {/* Product Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-400 px-1">Nom du produit *</label>
                <input
                  type="text"
                  required
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  placeholder="ex: Couscous Royal, Croissant pur beurre, Macaron..."
                  className={`w-full px-4 py-3 rounded-2xl border text-sm font-medium focus:outline-none ${
                    isLight 
                      ? 'bg-slate-50 border-slate-300 focus:border-yellow-400' 
                      : 'bg-neutral-900 border-neutral-800 text-white focus:border-yellow-400'
                  }`}
                />
              </div>

              {/* Price & Category */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-400 px-1">Prix (€) *</label>
                  <input
                    type="number"
                    step="0.10"
                    min="0"
                    required
                    value={productPrice}
                    onChange={(e) => setProductPrice(e.target.value)}
                    placeholder="9.90"
                    className={`w-full px-4 py-3 rounded-2xl border text-sm font-bold focus:outline-none font-mono ${
                      isLight 
                        ? 'bg-slate-50 border-slate-300 focus:border-yellow-400' 
                        : 'bg-neutral-900 border-neutral-800 text-white focus:border-yellow-400'
                    }`}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-400 px-1">Catégorie</label>
                  <select
                    value={productCategory}
                    onChange={(e) => setProductCategory(e.target.value)}
                    className={`w-full px-3 py-3 rounded-2xl border text-sm font-medium focus:outline-none cursor-pointer ${
                      isLight 
                        ? 'bg-slate-50 border-slate-300' 
                        : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  >
                    <option value="Restauration">Restauration</option>
                    <option value="Boulangerie">Boulangerie</option>
                    <option value="Boissons">Boissons</option>
                    <option value="Fruits & Légumes">Fruits & Légumes</option>
                    <option value="Épicerie">Épicerie</option>
                    <option value="Fleurs">Fleurs</option>
                    <option value="High-Tech">High-Tech</option>
                    <option value="Mode & Luxe">Mode & Luxe</option>
                    <option value="Autre">Autre (personnalisé)</option>
                  </select>
                </div>
              </div>

              {/* Custom Category if "Autre" selected */}
              {productCategory === 'Autre' && (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-400 px-1">Nom de la nouvelle catégorie</label>
                  <input
                    type="text"
                    value={customCategory}
                    onChange={(e) => setCustomCategory(e.target.value)}
                    placeholder="ex: Parfums d'intérieur, Chaussures..."
                    className={`w-full px-4 py-2.5 rounded-2xl border text-sm font-medium focus:outline-none ${
                      isLight 
                        ? 'bg-slate-50 border-slate-300 focus:border-yellow-400' 
                        : 'bg-neutral-900 border-neutral-800 text-white focus:border-yellow-400'
                    }`}
                  />
                </div>
              )}

              {/* Description */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-400 px-1">Description (optionnelle)</label>
                <textarea
                  rows={2}
                  value={productDesc}
                  onChange={(e) => setProductDesc(e.target.value)}
                  placeholder="Détails, ingrédients, composition..."
                  className={`w-full px-4 py-2.5 rounded-2xl border text-xs font-medium focus:outline-none ${
                    isLight 
                      ? 'bg-slate-50 border-slate-300 focus:border-yellow-400' 
                      : 'bg-neutral-900 border-neutral-800 text-white focus:border-yellow-400'
                  }`}
                />
              </div>

              {/* Preset Visual Photo Picker */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-neutral-400 px-1">Sélectionner une photo illustrative</label>
                <div className="grid grid-cols-3 gap-2 max-h-36 overflow-y-auto p-1">
                  {PRESET_PRODUCT_IMAGES.map((img) => {
                    const isSelected = productImg === img.url && !customImgUrl;
                    return (
                      <div
                        key={img.label}
                        onClick={() => {
                          setProductImg(img.url);
                          setCustomImgUrl('');
                        }}
                        className={`relative rounded-xl overflow-hidden cursor-pointer border-2 transition aspect-video group ${
                          isSelected ? 'border-yellow-400 ring-2 ring-yellow-400/40 scale-95' : 'border-transparent opacity-75 hover:opacity-100'
                        }`}
                      >
                        <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                        <span className="absolute inset-x-0 bottom-0 bg-black/80 text-[8px] text-white px-1 py-0.5 truncate text-center">
                          {img.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Or Custom Image URL */}
              <div className="space-y-1 pt-1">
                <label className="text-xs font-bold text-neutral-400 px-1">Ou URL d'image personnalisée</label>
                <input
                  type="url"
                  value={customImgUrl}
                  onChange={(e) => setCustomImgUrl(e.target.value)}
                  placeholder="https://..."
                  className={`w-full px-4 py-2.5 rounded-2xl border text-xs font-mono focus:outline-none ${
                    isLight 
                      ? 'bg-slate-50 border-slate-300 focus:border-yellow-400' 
                      : 'bg-neutral-900 border-neutral-800 text-white focus:border-yellow-400'
                  }`}
                />
              </div>

              {/* Submit Button */}
              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full py-4 px-6 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-yellow-400/20 active:scale-98 transition"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>Enregistrer dans la vitrine</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
