import React, { useState } from 'react';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth } from '../../services/firebase';
import { vtcStore } from '../../services/vtcStore';
import { soundEffects } from '../../utils/audio';
import { LegalModal } from '../Modals/LegalModal';
import { AlertCircle } from 'lucide-react';

interface AuthScreenProps {
  onAuthenticated: (method: 'google' | 'guest') => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthenticated }) => {
  const [loadingGoogle, setLoadingGoogle] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showTerms, setShowTerms] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);

  // Operational real Firebase Google Sign-In
  const handleGoogleSignIn = async () => {
    soundEffects.playClick();
    setLoadingGoogle(true);
    setErrorMessage(null);

    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      if (user) {
        soundEffects.playSuccessSound();
        try {
          localStorage.setItem('somed_authenticated', 'true');
          sessionStorage.setItem('somed_authenticated_session', 'true');
          localStorage.setItem('somed_auth_method', 'google');
        } catch {}

        vtcStore.updatePassengerProfile({
          name: user.displayName || 'Utilisateur Google',
          email: user.email || 'google@somed.app',
          avatarUrl: user.photoURL || undefined,
        });

        vtcStore.sendPushNotification({
          title: 'Connexion Google réussie',
          body: `Bienvenue ${user.displayName || ''} sur SOMED Prestige ! Votre compte Google est connecté.`,
          category: 'SYSTEM',
          badge: 'Google'
        });

        onAuthenticated('google');
      }
    } catch (err: any) {
      console.warn('Google sign-in status/error:', err);
      if (err?.code === 'auth/popup-closed-by-user') {
        setErrorMessage('La fenêtre de connexion Google a été fermée.');
      } else if (err?.code === 'auth/popup-blocked') {
        setErrorMessage('La fenêtre pop-up a été bloquée par le navigateur. Veuillez autoriser les fenêtres pop-up.');
      } else if (err?.code === 'auth/cancelled-popup-request') {
        setErrorMessage('Connexion interrompue.');
      } else if (err?.code === 'auth/unauthorized-domain') {
        setErrorMessage('Domaine non autorisé dans la console Firebase Auth.');
      } else {
        setErrorMessage(err?.message || 'Erreur lors de la connexion Google.');
      }
    } finally {
      setLoadingGoogle(false);
    }
  };

  const handleGuestSignIn = () => {
    soundEffects.playClick();
    soundEffects.playRideAccepted();
    try {
      localStorage.setItem('somed_authenticated', 'true');
      sessionStorage.setItem('somed_authenticated_session', 'true');
      localStorage.setItem('somed_auth_method', 'guest');
    } catch {}
    onAuthenticated('guest');
  };

  return (
    <div className="fixed inset-0 z-[3000] bg-black text-white flex flex-col justify-between items-center px-6 py-10 select-none overflow-y-auto animate-in fade-in duration-300">
      {/* Top subtle spacing & app version */}
      <div className="w-full flex justify-end items-center max-w-sm">
        <span className="text-[10px] font-mono text-neutral-600">v1.0.2 (#3)</span>
      </div>

      {/* Center Branding Area (Matches phone launch screen with official lemon icon) */}
      <div className="w-full max-w-sm flex flex-col items-center text-center my-auto">
        {/* App Logo with official lemon icon */}
        <div className="relative group cursor-pointer mb-7">
          <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl overflow-hidden bg-transparent p-0 flex items-center justify-center shadow-2xl shadow-yellow-400/25 ring-4 ring-yellow-400/30 transition-transform transform group-hover:scale-105 active:scale-95 duration-200">
            <img 
              src="/somed-logo.png" 
              alt="SOMED" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Brand Name Title */}
        <h1 className="text-3xl sm:text-4xl font-black text-yellow-400 tracking-tight mb-2">
          SOMED
        </h1>

        {/* Brand Tagline Subtitle */}
        <p className="text-sm sm:text-base text-neutral-400 font-medium tracking-normal mb-8">
          Ride or drive, you decide
        </p>

        {/* Error notification if Google sign-in fails or popup blocked */}
        {errorMessage && (
          <div className="w-full mb-5 p-3 rounded-2xl bg-rose-950/80 border border-rose-800 text-rose-200 text-xs flex items-center gap-2.5 text-left animate-in fade-in slide-in-from-top-2 duration-200">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
            <span className="flex-1 font-medium">{errorMessage}</span>
          </div>
        )}

        {/* Action Buttons Container */}
        <div className="w-full space-y-4">
          {/* Operational Google Sign In Button */}
          <button
            onClick={handleGoogleSignIn}
            disabled={loadingGoogle}
            className="w-full py-4 px-6 rounded-2xl bg-black border border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/60 text-white font-bold text-base flex items-center justify-center gap-3 transition active:scale-[0.98] shadow-xl group cursor-pointer"
          >
            {loadingGoogle ? (
              <div className="w-5 h-5 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin" />
            ) : (
              <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
              </svg>
            )}
            <span>{loadingGoogle ? 'Connexion Google en cours...' : 'Continue with Google'}</span>
          </button>

          {/* Continue as guest Button */}
          <button
            onClick={handleGuestSignIn}
            className="w-full py-3 text-yellow-400 hover:text-yellow-300 font-bold text-sm sm:text-base transition active:scale-95 block text-center cursor-pointer"
          >
            Continue as guest
          </button>
        </div>
      </div>

      {/* Bottom Legal & Version Footer */}
      <div className="w-full max-w-sm text-center pt-6 space-y-1">
        <p className="text-xs text-neutral-500 leading-relaxed">
          By continuing, you accept our{' '}
          <button 
            onClick={() => setShowTerms(true)}
            className="text-yellow-400 hover:text-yellow-300 underline underline-offset-2 transition"
          >
            Terms of Service
          </button>{' '}
          and{' '}
          <button 
            onClick={() => setShowPrivacy(true)}
            className="text-yellow-400 hover:text-yellow-300 underline underline-offset-2 transition"
          >
            Privacy policy
          </button>
        </p>

        <p className="text-[11px] font-mono text-neutral-600 pt-1">
          SOMED v1.0.2 (#3)
        </p>
      </div>

      {/* Legal Modals */}
      <LegalModal
        isOpen={showTerms}
        type="terms"
        onClose={() => setShowTerms(false)}
      />

      <LegalModal
        isOpen={showPrivacy}
        type="privacy"
        onClose={() => setShowPrivacy(false)}
      />
    </div>
  );
};
